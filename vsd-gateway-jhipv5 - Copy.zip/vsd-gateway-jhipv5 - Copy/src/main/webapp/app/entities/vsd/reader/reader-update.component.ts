import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { JhiAlertService } from 'ng-jhipster';

import { IReader } from 'app/shared/model/vsd/reader.model';
import { ReaderService } from './reader.service';
import { IReaderNumber } from 'app/shared/model/vsd/reader-number.model';
import { ReaderNumberService } from 'app/entities/vsd/reader-number';

@Component({
    selector: 'jhi-reader-update',
    templateUrl: './reader-update.component.html'
})
export class ReaderUpdateComponent implements OnInit {
    reader: IReader;
    isSaving: boolean;

    readernumbers: IReaderNumber[];

    constructor(
        private jhiAlertService: JhiAlertService,
        private readerService: ReaderService,
        private readerNumberService: ReaderNumberService,
        private activatedRoute: ActivatedRoute
    ) {}

    ngOnInit() {
        this.isSaving = false;
        this.activatedRoute.data.subscribe(({ reader }) => {
            this.reader = reader;
        });
        this.readerNumberService.query().subscribe(
            (res: HttpResponse<IReaderNumber[]>) => {
                this.readernumbers = res.body;
            },
            (res: HttpErrorResponse) => this.onError(res.message)
        );
    }

    previousState() {
        window.history.back();
    }

    save() {
        this.isSaving = true;
        if (this.reader.id !== undefined) {
            this.subscribeToSaveResponse(this.readerService.update(this.reader));
        } else {
            this.subscribeToSaveResponse(this.readerService.create(this.reader));
        }
    }

    private subscribeToSaveResponse(result: Observable<HttpResponse<IReader>>) {
        result.subscribe((res: HttpResponse<IReader>) => this.onSaveSuccess(), (res: HttpErrorResponse) => this.onSaveError());
    }

    private onSaveSuccess() {
        this.isSaving = false;
        this.previousState();
    }

    private onSaveError() {
        this.isSaving = false;
    }

    private onError(errorMessage: string) {
        this.jhiAlertService.error(errorMessage, null, null);
    }

    trackReaderNumberById(index: number, item: IReaderNumber) {
        return item.id;
    }

    getSelected(selectedVals: Array<any>, option: any) {
        if (selectedVals) {
            for (let i = 0; i < selectedVals.length; i++) {
                if (option.id === selectedVals[i].id) {
                    return selectedVals[i];
                }
            }
        }
        return option;
    }
}
