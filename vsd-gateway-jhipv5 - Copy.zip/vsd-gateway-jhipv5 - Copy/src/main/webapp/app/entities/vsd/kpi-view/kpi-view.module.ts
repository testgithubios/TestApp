import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { VsdGatewaySharedModule } from 'app/shared';
import {
    KpiViewComponent,
    KpiViewDetailComponent,
    KpiViewUpdateComponent,
    KpiViewDeletePopupComponent,
    KpiViewDeleteDialogComponent,
    kpiViewRoute,
    kpiViewPopupRoute
} from './';

const ENTITY_STATES = [...kpiViewRoute, ...kpiViewPopupRoute];

@NgModule({
    imports: [VsdGatewaySharedModule, RouterModule.forChild(ENTITY_STATES)],
    declarations: [
        KpiViewComponent,
        KpiViewDetailComponent,
        KpiViewUpdateComponent,
        KpiViewDeleteDialogComponent,
        KpiViewDeletePopupComponent
    ],
    entryComponents: [KpiViewComponent, KpiViewUpdateComponent, KpiViewDeleteDialogComponent, KpiViewDeletePopupComponent],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class VsdGatewayKpiViewModule {}
