import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes } from '@angular/router';
import { JhiPaginationUtil, JhiResolvePagingParams } from 'ng-jhipster';
import { UserRouteAccessService } from 'app/core';
import { Observable, of } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { ReaderNumber } from 'app/shared/model/vsd/reader-number.model';
import { ReaderNumberService } from './reader-number.service';
import { ReaderNumberComponent } from './reader-number.component';
import { ReaderNumberDetailComponent } from './reader-number-detail.component';
import { ReaderNumberUpdateComponent } from './reader-number-update.component';
import { ReaderNumberDeletePopupComponent } from './reader-number-delete-dialog.component';
import { IReaderNumber } from 'app/shared/model/vsd/reader-number.model';

@Injectable({ providedIn: 'root' })
export class ReaderNumberResolve implements Resolve<IReaderNumber> {
    constructor(private service: ReaderNumberService) {}

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<ReaderNumber> {
        const id = route.params['id'] ? route.params['id'] : null;
        if (id) {
            return this.service.find(id).pipe(
                filter((response: HttpResponse<ReaderNumber>) => response.ok),
                map((readerNumber: HttpResponse<ReaderNumber>) => readerNumber.body)
            );
        }
        return of(new ReaderNumber());
    }
}

export const readerNumberRoute: Routes = [
    {
        path: 'reader-number',
        component: ReaderNumberComponent,
        resolve: {
            pagingParams: JhiResolvePagingParams
        },
        data: {
            authorities: ['ROLE_USER'],
            defaultSort: 'id,asc',
            pageTitle: 'vsdGatewayApp.vsdReaderNumber.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'reader-number/:id/view',
        component: ReaderNumberDetailComponent,
        resolve: {
            readerNumber: ReaderNumberResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdReaderNumber.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'reader-number/new',
        component: ReaderNumberUpdateComponent,
        resolve: {
            readerNumber: ReaderNumberResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdReaderNumber.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'reader-number/:id/edit',
        component: ReaderNumberUpdateComponent,
        resolve: {
            readerNumber: ReaderNumberResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdReaderNumber.home.title'
        },
        canActivate: [UserRouteAccessService]
    }
];

export const readerNumberPopupRoute: Routes = [
    {
        path: 'reader-number/:id/delete',
        component: ReaderNumberDeletePopupComponent,
        resolve: {
            readerNumber: ReaderNumberResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdReaderNumber.home.title'
        },
        canActivate: [UserRouteAccessService],
        outlet: 'popup'
    }
];
