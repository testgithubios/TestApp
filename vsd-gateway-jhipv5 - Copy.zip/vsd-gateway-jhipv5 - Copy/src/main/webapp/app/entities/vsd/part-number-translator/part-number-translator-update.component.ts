import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

import { IPartNumberTranslator } from 'app/shared/model/vsd/part-number-translator.model';
import { PartNumberTranslatorService } from './part-number-translator.service';

@Component({
    selector: 'jhi-part-number-translator-update',
    templateUrl: './part-number-translator-update.component.html'
})
export class PartNumberTranslatorUpdateComponent implements OnInit {
    partNumberTranslator: IPartNumberTranslator;
    isSaving: boolean;

    constructor(private partNumberTranslatorService: PartNumberTranslatorService, private activatedRoute: ActivatedRoute) {}

    ngOnInit() {
        this.isSaving = false;
        this.activatedRoute.data.subscribe(({ partNumberTranslator }) => {
            this.partNumberTranslator = partNumberTranslator;
        });
    }

    previousState() {
        window.history.back();
    }

    save() {
        this.isSaving = true;
        if (this.partNumberTranslator.id !== undefined) {
            this.subscribeToSaveResponse(this.partNumberTranslatorService.update(this.partNumberTranslator));
        } else {
            this.subscribeToSaveResponse(this.partNumberTranslatorService.create(this.partNumberTranslator));
        }
    }

    private subscribeToSaveResponse(result: Observable<HttpResponse<IPartNumberTranslator>>) {
        result.subscribe(
            (res: HttpResponse<IPartNumberTranslator>) => this.onSaveSuccess(),
            (res: HttpErrorResponse) => this.onSaveError()
        );
    }

    private onSaveSuccess() {
        this.isSaving = false;
        this.previousState();
    }

    private onSaveError() {
        this.isSaving = false;
    }
}
