import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { IRtAnalysis } from 'app/shared/model/vsd/rt-analysis.model';

@Component({
    selector: 'jhi-rt-analysis-detail',
    templateUrl: './rt-analysis-detail.component.html'
})
export class RtAnalysisDetailComponent implements OnInit {
    rtAnalysis: IRtAnalysis;

    constructor(private activatedRoute: ActivatedRoute) {}

    ngOnInit() {
        this.activatedRoute.data.subscribe(({ rtAnalysis }) => {
            this.rtAnalysis = rtAnalysis;
        });
    }

    previousState() {
        window.history.back();
    }
}
