import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as moment from 'moment';
import { DATE_TIME_FORMAT } from 'app/shared/constants/input.constants';

import { IFeatureStatus } from 'app/shared/model/vsd/feature-status.model';
import { FeatureStatusService } from './feature-status.service';

@Component({
    selector: 'jhi-feature-status-update',
    templateUrl: './feature-status-update.component.html'
})
export class FeatureStatusUpdateComponent implements OnInit {
    featureStatus: IFeatureStatus;
    isSaving: boolean;
    latestStatusChange: string;

    constructor(private featureStatusService: FeatureStatusService, private activatedRoute: ActivatedRoute) {}

    ngOnInit() {
        this.isSaving = false;
        this.activatedRoute.data.subscribe(({ featureStatus }) => {
            this.featureStatus = featureStatus;
            this.latestStatusChange =
                this.featureStatus.latestStatusChange != null ? this.featureStatus.latestStatusChange.format(DATE_TIME_FORMAT) : null;
        });
    }

    previousState() {
        window.history.back();
    }

    save() {
        this.isSaving = true;
        this.featureStatus.latestStatusChange = this.latestStatusChange != null ? moment(this.latestStatusChange, DATE_TIME_FORMAT) : null;
        if (this.featureStatus.id !== undefined) {
            this.subscribeToSaveResponse(this.featureStatusService.update(this.featureStatus));
        } else {
            this.subscribeToSaveResponse(this.featureStatusService.create(this.featureStatus));
        }
    }

    private subscribeToSaveResponse(result: Observable<HttpResponse<IFeatureStatus>>) {
        result.subscribe((res: HttpResponse<IFeatureStatus>) => this.onSaveSuccess(), (res: HttpErrorResponse) => this.onSaveError());
    }

    private onSaveSuccess() {
        this.isSaving = false;
        this.previousState();
    }

    private onSaveError() {
        this.isSaving = false;
    }
}
