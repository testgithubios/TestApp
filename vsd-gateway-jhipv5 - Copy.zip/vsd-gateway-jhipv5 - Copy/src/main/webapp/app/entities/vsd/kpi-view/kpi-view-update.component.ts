import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

import { IKpiView } from 'app/shared/model/vsd/kpi-view.model';
import { KpiViewService } from './kpi-view.service';

@Component({
    selector: 'jhi-kpi-view-update',
    templateUrl: './kpi-view-update.component.html'
})
export class KpiViewUpdateComponent implements OnInit {
    kpiView: IKpiView;
    isSaving: boolean;

    constructor(private kpiViewService: KpiViewService, private activatedRoute: ActivatedRoute) {}

    ngOnInit() {
        this.isSaving = false;
        this.activatedRoute.data.subscribe(({ kpiView }) => {
            this.kpiView = kpiView;
        });
    }

    previousState() {
        window.history.back();
    }

    save() {
        this.isSaving = true;
        if (this.kpiView.id !== undefined) {
            this.subscribeToSaveResponse(this.kpiViewService.update(this.kpiView));
        } else {
            this.subscribeToSaveResponse(this.kpiViewService.create(this.kpiView));
        }
    }

    private subscribeToSaveResponse(result: Observable<HttpResponse<IKpiView>>) {
        result.subscribe((res: HttpResponse<IKpiView>) => this.onSaveSuccess(), (res: HttpErrorResponse) => this.onSaveError());
    }

    private onSaveSuccess() {
        this.isSaving = false;
        this.previousState();
    }

    private onSaveError() {
        this.isSaving = false;
    }
}
