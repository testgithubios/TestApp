import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as moment from 'moment';
import { DATE_TIME_FORMAT } from 'app/shared/constants/input.constants';

import { IMatBookingCache } from 'app/shared/model/vsd/mat-booking-cache.model';
import { MatBookingCacheService } from './mat-booking-cache.service';

@Component({
    selector: 'jhi-mat-booking-cache-update',
    templateUrl: './mat-booking-cache-update.component.html'
})
export class MatBookingCacheUpdateComponent implements OnInit {
    matBookingCache: IMatBookingCache;
    isSaving: boolean;
    startTime: string;

    constructor(private matBookingCacheService: MatBookingCacheService, private activatedRoute: ActivatedRoute) {}

    ngOnInit() {
        this.isSaving = false;
        this.activatedRoute.data.subscribe(({ matBookingCache }) => {
            this.matBookingCache = matBookingCache;
            this.startTime = this.matBookingCache.startTime != null ? this.matBookingCache.startTime.format(DATE_TIME_FORMAT) : null;
        });
    }

    previousState() {
        window.history.back();
    }

    save() {
        this.isSaving = true;
        this.matBookingCache.startTime = this.startTime != null ? moment(this.startTime, DATE_TIME_FORMAT) : null;
        if (this.matBookingCache.id !== undefined) {
            this.subscribeToSaveResponse(this.matBookingCacheService.update(this.matBookingCache));
        } else {
            this.subscribeToSaveResponse(this.matBookingCacheService.create(this.matBookingCache));
        }
    }

    private subscribeToSaveResponse(result: Observable<HttpResponse<IMatBookingCache>>) {
        result.subscribe((res: HttpResponse<IMatBookingCache>) => this.onSaveSuccess(), (res: HttpErrorResponse) => this.onSaveError());
    }

    private onSaveSuccess() {
        this.isSaving = false;
        this.previousState();
    }

    private onSaveError() {
        this.isSaving = false;
    }
}
