import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

import { SERVER_API_URL } from 'app/app.constants';
import { createRequestOption } from 'app/shared';
import { IRtAnalysis } from 'app/shared/model/vsd/rt-analysis.model';

type EntityResponseType = HttpResponse<IRtAnalysis>;
type EntityArrayResponseType = HttpResponse<IRtAnalysis[]>;

@Injectable({ providedIn: 'root' })
export class RtAnalysisService {
    public resourceUrl = SERVER_API_URL + 'vsd/api/rt-analyses';
    public resourceSearchUrl = SERVER_API_URL + 'vsd/api/_search/rt-analyses';

    constructor(private http: HttpClient) {}

    create(rtAnalysis: IRtAnalysis): Observable<EntityResponseType> {
        return this.http.post<IRtAnalysis>(this.resourceUrl, rtAnalysis, { observe: 'response' });
    }

    update(rtAnalysis: IRtAnalysis): Observable<EntityResponseType> {
        return this.http.put<IRtAnalysis>(this.resourceUrl, rtAnalysis, { observe: 'response' });
    }

    find(id: number): Observable<EntityResponseType> {
        return this.http.get<IRtAnalysis>(`${this.resourceUrl}/${id}`, { observe: 'response' });
    }

    query(req?: any): Observable<EntityArrayResponseType> {
        const options = createRequestOption(req);
        return this.http.get<IRtAnalysis[]>(this.resourceUrl, { params: options, observe: 'response' });
    }

    delete(id: number): Observable<HttpResponse<any>> {
        return this.http.delete<any>(`${this.resourceUrl}/${id}`, { observe: 'response' });
    }

    search(req?: any): Observable<EntityArrayResponseType> {
        const options = createRequestOption(req);
        return this.http.get<IRtAnalysis[]>(this.resourceSearchUrl, { params: options, observe: 'response' });
    }
}
