import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

import { ILeadTimeLink } from 'app/shared/model/vsd/lead-time-link.model';
import { LeadTimeLinkService } from './lead-time-link.service';

@Component({
    selector: 'jhi-lead-time-link-update',
    templateUrl: './lead-time-link-update.component.html'
})
export class LeadTimeLinkUpdateComponent implements OnInit {
    leadTimeLink: ILeadTimeLink;
    isSaving: boolean;

    constructor(private leadTimeLinkService: LeadTimeLinkService, private activatedRoute: ActivatedRoute) {}

    ngOnInit() {
        this.isSaving = false;
        this.activatedRoute.data.subscribe(({ leadTimeLink }) => {
            this.leadTimeLink = leadTimeLink;
        });
    }

    previousState() {
        window.history.back();
    }

    save() {
        this.isSaving = true;
        if (this.leadTimeLink.id !== undefined) {
            this.subscribeToSaveResponse(this.leadTimeLinkService.update(this.leadTimeLink));
        } else {
            this.subscribeToSaveResponse(this.leadTimeLinkService.create(this.leadTimeLink));
        }
    }

    private subscribeToSaveResponse(result: Observable<HttpResponse<ILeadTimeLink>>) {
        result.subscribe((res: HttpResponse<ILeadTimeLink>) => this.onSaveSuccess(), (res: HttpErrorResponse) => this.onSaveError());
    }

    private onSaveSuccess() {
        this.isSaving = false;
        this.previousState();
    }

    private onSaveError() {
        this.isSaving = false;
    }
}
