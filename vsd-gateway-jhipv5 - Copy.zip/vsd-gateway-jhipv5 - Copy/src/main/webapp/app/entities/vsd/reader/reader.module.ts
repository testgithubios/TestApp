import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { VsdGatewaySharedModule } from 'app/shared';
import {
    ReaderComponent,
    ReaderDetailComponent,
    ReaderUpdateComponent,
    ReaderDeletePopupComponent,
    ReaderDeleteDialogComponent,
    readerRoute,
    readerPopupRoute
} from './';

const ENTITY_STATES = [...readerRoute, ...readerPopupRoute];

@NgModule({
    imports: [VsdGatewaySharedModule, RouterModule.forChild(ENTITY_STATES)],
    declarations: [ReaderComponent, ReaderDetailComponent, ReaderUpdateComponent, ReaderDeleteDialogComponent, ReaderDeletePopupComponent],
    entryComponents: [ReaderComponent, ReaderUpdateComponent, ReaderDeleteDialogComponent, ReaderDeletePopupComponent],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class VsdGatewayReaderModule {}
