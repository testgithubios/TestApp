import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { VsdGatewaySharedModule } from 'app/shared';
import {
    ProductFamilyComponent,
    ProductFamilyDetailComponent,
    ProductFamilyUpdateComponent,
    ProductFamilyDeletePopupComponent,
    ProductFamilyDeleteDialogComponent,
    productFamilyRoute,
    productFamilyPopupRoute
} from './';

const ENTITY_STATES = [...productFamilyRoute, ...productFamilyPopupRoute];

@NgModule({
    imports: [VsdGatewaySharedModule, RouterModule.forChild(ENTITY_STATES)],
    declarations: [
        ProductFamilyComponent,
        ProductFamilyDetailComponent,
        ProductFamilyUpdateComponent,
        ProductFamilyDeleteDialogComponent,
        ProductFamilyDeletePopupComponent
    ],
    entryComponents: [
        ProductFamilyComponent,
        ProductFamilyUpdateComponent,
        ProductFamilyDeleteDialogComponent,
        ProductFamilyDeletePopupComponent
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class VsdGatewayProductFamilyModule {}
