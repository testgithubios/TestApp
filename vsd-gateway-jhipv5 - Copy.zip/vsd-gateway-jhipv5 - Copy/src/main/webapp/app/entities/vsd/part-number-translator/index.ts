export * from './part-number-translator.service';
export * from './part-number-translator-update.component';
export * from './part-number-translator-delete-dialog.component';
export * from './part-number-translator-detail.component';
export * from './part-number-translator.component';
export * from './part-number-translator.route';
