import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { NgbActiveModal, NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { JhiEventManager } from 'ng-jhipster';

import { IRtAnalysis } from 'app/shared/model/vsd/rt-analysis.model';
import { RtAnalysisService } from './rt-analysis.service';

@Component({
    selector: 'jhi-rt-analysis-delete-dialog',
    templateUrl: './rt-analysis-delete-dialog.component.html'
})
export class RtAnalysisDeleteDialogComponent {
    rtAnalysis: IRtAnalysis;

    constructor(private rtAnalysisService: RtAnalysisService, public activeModal: NgbActiveModal, private eventManager: JhiEventManager) {}

    clear() {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete(id: number) {
        this.rtAnalysisService.delete(id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'rtAnalysisListModification',
                content: 'Deleted an rtAnalysis'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'jhi-rt-analysis-delete-popup',
    template: ''
})
export class RtAnalysisDeletePopupComponent implements OnInit, OnDestroy {
    private ngbModalRef: NgbModalRef;

    constructor(private activatedRoute: ActivatedRoute, private router: Router, private modalService: NgbModal) {}

    ngOnInit() {
        this.activatedRoute.data.subscribe(({ rtAnalysis }) => {
            setTimeout(() => {
                this.ngbModalRef = this.modalService.open(RtAnalysisDeleteDialogComponent as Component, { size: 'lg', backdrop: 'static' });
                this.ngbModalRef.componentInstance.rtAnalysis = rtAnalysis;
                this.ngbModalRef.result.then(
                    result => {
                        this.router.navigate([{ outlets: { popup: null } }], { replaceUrl: true, queryParamsHandling: 'merge' });
                        this.ngbModalRef = null;
                    },
                    reason => {
                        this.router.navigate([{ outlets: { popup: null } }], { replaceUrl: true, queryParamsHandling: 'merge' });
                        this.ngbModalRef = null;
                    }
                );
            }, 0);
        });
    }

    ngOnDestroy() {
        this.ngbModalRef = null;
    }
}
