import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { NgbActiveModal, NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { JhiEventManager } from 'ng-jhipster';

import { IPartNumberTranslator } from 'app/shared/model/vsd/part-number-translator.model';
import { PartNumberTranslatorService } from './part-number-translator.service';

@Component({
    selector: 'jhi-part-number-translator-delete-dialog',
    templateUrl: './part-number-translator-delete-dialog.component.html'
})
export class PartNumberTranslatorDeleteDialogComponent {
    partNumberTranslator: IPartNumberTranslator;

    constructor(
        private partNumberTranslatorService: PartNumberTranslatorService,
        public activeModal: NgbActiveModal,
        private eventManager: JhiEventManager
    ) {}

    clear() {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete(id: number) {
        this.partNumberTranslatorService.delete(id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'partNumberTranslatorListModification',
                content: 'Deleted an partNumberTranslator'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'jhi-part-number-translator-delete-popup',
    template: ''
})
export class PartNumberTranslatorDeletePopupComponent implements OnInit, OnDestroy {
    private ngbModalRef: NgbModalRef;

    constructor(private activatedRoute: ActivatedRoute, private router: Router, private modalService: NgbModal) {}

    ngOnInit() {
        this.activatedRoute.data.subscribe(({ partNumberTranslator }) => {
            setTimeout(() => {
                this.ngbModalRef = this.modalService.open(PartNumberTranslatorDeleteDialogComponent as Component, {
                    size: 'lg',
                    backdrop: 'static'
                });
                this.ngbModalRef.componentInstance.partNumberTranslator = partNumberTranslator;
                this.ngbModalRef.result.then(
                    result => {
                        this.router.navigate([{ outlets: { popup: null } }], { replaceUrl: true, queryParamsHandling: 'merge' });
                        this.ngbModalRef = null;
                    },
                    reason => {
                        this.router.navigate([{ outlets: { popup: null } }], { replaceUrl: true, queryParamsHandling: 'merge' });
                        this.ngbModalRef = null;
                    }
                );
            }, 0);
        });
    }

    ngOnDestroy() {
        this.ngbModalRef = null;
    }
}
