import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { NgbActiveModal, NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { JhiEventManager } from 'ng-jhipster';

import { ILeadTimeLink } from 'app/shared/model/vsd/lead-time-link.model';
import { LeadTimeLinkService } from './lead-time-link.service';

@Component({
    selector: 'jhi-lead-time-link-delete-dialog',
    templateUrl: './lead-time-link-delete-dialog.component.html'
})
export class LeadTimeLinkDeleteDialogComponent {
    leadTimeLink: ILeadTimeLink;

    constructor(
        private leadTimeLinkService: LeadTimeLinkService,
        public activeModal: NgbActiveModal,
        private eventManager: JhiEventManager
    ) {}

    clear() {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete(id: number) {
        this.leadTimeLinkService.delete(id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'leadTimeLinkListModification',
                content: 'Deleted an leadTimeLink'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'jhi-lead-time-link-delete-popup',
    template: ''
})
export class LeadTimeLinkDeletePopupComponent implements OnInit, OnDestroy {
    private ngbModalRef: NgbModalRef;

    constructor(private activatedRoute: ActivatedRoute, private router: Router, private modalService: NgbModal) {}

    ngOnInit() {
        this.activatedRoute.data.subscribe(({ leadTimeLink }) => {
            setTimeout(() => {
                this.ngbModalRef = this.modalService.open(LeadTimeLinkDeleteDialogComponent as Component, {
                    size: 'lg',
                    backdrop: 'static'
                });
                this.ngbModalRef.componentInstance.leadTimeLink = leadTimeLink;
                this.ngbModalRef.result.then(
                    result => {
                        this.router.navigate([{ outlets: { popup: null } }], { replaceUrl: true, queryParamsHandling: 'merge' });
                        this.ngbModalRef = null;
                    },
                    reason => {
                        this.router.navigate([{ outlets: { popup: null } }], { replaceUrl: true, queryParamsHandling: 'merge' });
                        this.ngbModalRef = null;
                    }
                );
            }, 0);
        });
    }

    ngOnDestroy() {
        this.ngbModalRef = null;
    }
}
