import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { IKpiView } from 'app/shared/model/vsd/kpi-view.model';

@Component({
    selector: 'jhi-kpi-view-detail',
    templateUrl: './kpi-view-detail.component.html'
})
export class KpiViewDetailComponent implements OnInit {
    kpiView: IKpiView;

    constructor(private activatedRoute: ActivatedRoute) {}

    ngOnInit() {
        this.activatedRoute.data.subscribe(({ kpiView }) => {
            this.kpiView = kpiView;
        });
    }

    previousState() {
        window.history.back();
    }
}
