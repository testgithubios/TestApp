import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { VsdGatewaySharedModule } from 'app/shared';
import {
    MatBookingCacheComponent,
    MatBookingCacheDetailComponent,
    MatBookingCacheUpdateComponent,
    MatBookingCacheDeletePopupComponent,
    MatBookingCacheDeleteDialogComponent,
    matBookingCacheRoute,
    matBookingCachePopupRoute
} from './';

const ENTITY_STATES = [...matBookingCacheRoute, ...matBookingCachePopupRoute];

@NgModule({
    imports: [VsdGatewaySharedModule, RouterModule.forChild(ENTITY_STATES)],
    declarations: [
        MatBookingCacheComponent,
        MatBookingCacheDetailComponent,
        MatBookingCacheUpdateComponent,
        MatBookingCacheDeleteDialogComponent,
        MatBookingCacheDeletePopupComponent
    ],
    entryComponents: [
        MatBookingCacheComponent,
        MatBookingCacheUpdateComponent,
        MatBookingCacheDeleteDialogComponent,
        MatBookingCacheDeletePopupComponent
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class VsdGatewayMatBookingCacheModule {}
