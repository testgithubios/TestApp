import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { IReader } from 'app/shared/model/vsd/reader.model';

@Component({
    selector: 'jhi-reader-detail',
    templateUrl: './reader-detail.component.html'
})
export class ReaderDetailComponent implements OnInit {
    reader: IReader;

    constructor(private activatedRoute: ActivatedRoute) {}

    ngOnInit() {
        this.activatedRoute.data.subscribe(({ reader }) => {
            this.reader = reader;
        });
    }

    previousState() {
        window.history.back();
    }
}
