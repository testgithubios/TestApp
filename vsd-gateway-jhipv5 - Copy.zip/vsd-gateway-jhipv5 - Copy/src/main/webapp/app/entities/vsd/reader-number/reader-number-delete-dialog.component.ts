import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { NgbActiveModal, NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { JhiEventManager } from 'ng-jhipster';

import { IReaderNumber } from 'app/shared/model/vsd/reader-number.model';
import { ReaderNumberService } from './reader-number.service';

@Component({
    selector: 'jhi-reader-number-delete-dialog',
    templateUrl: './reader-number-delete-dialog.component.html'
})
export class ReaderNumberDeleteDialogComponent {
    readerNumber: IReaderNumber;

    constructor(
        private readerNumberService: ReaderNumberService,
        public activeModal: NgbActiveModal,
        private eventManager: JhiEventManager
    ) {}

    clear() {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete(id: number) {
        this.readerNumberService.delete(id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'readerNumberListModification',
                content: 'Deleted an readerNumber'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'jhi-reader-number-delete-popup',
    template: ''
})
export class ReaderNumberDeletePopupComponent implements OnInit, OnDestroy {
    private ngbModalRef: NgbModalRef;

    constructor(private activatedRoute: ActivatedRoute, private router: Router, private modalService: NgbModal) {}

    ngOnInit() {
        this.activatedRoute.data.subscribe(({ readerNumber }) => {
            setTimeout(() => {
                this.ngbModalRef = this.modalService.open(ReaderNumberDeleteDialogComponent as Component, {
                    size: 'lg',
                    backdrop: 'static'
                });
                this.ngbModalRef.componentInstance.readerNumber = readerNumber;
                this.ngbModalRef.result.then(
                    result => {
                        this.router.navigate([{ outlets: { popup: null } }], { replaceUrl: true, queryParamsHandling: 'merge' });
                        this.ngbModalRef = null;
                    },
                    reason => {
                        this.router.navigate([{ outlets: { popup: null } }], { replaceUrl: true, queryParamsHandling: 'merge' });
                        this.ngbModalRef = null;
                    }
                );
            }, 0);
        });
    }

    ngOnDestroy() {
        this.ngbModalRef = null;
    }
}
