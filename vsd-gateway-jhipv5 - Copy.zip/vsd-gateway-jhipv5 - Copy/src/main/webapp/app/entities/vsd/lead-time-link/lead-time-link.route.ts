import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes } from '@angular/router';
import { JhiPaginationUtil, JhiResolvePagingParams } from 'ng-jhipster';
import { UserRouteAccessService } from 'app/core';
import { Observable, of } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { LeadTimeLink } from 'app/shared/model/vsd/lead-time-link.model';
import { LeadTimeLinkService } from './lead-time-link.service';
import { LeadTimeLinkComponent } from './lead-time-link.component';
import { LeadTimeLinkDetailComponent } from './lead-time-link-detail.component';
import { LeadTimeLinkUpdateComponent } from './lead-time-link-update.component';
import { LeadTimeLinkDeletePopupComponent } from './lead-time-link-delete-dialog.component';
import { ILeadTimeLink } from 'app/shared/model/vsd/lead-time-link.model';

@Injectable({ providedIn: 'root' })
export class LeadTimeLinkResolve implements Resolve<ILeadTimeLink> {
    constructor(private service: LeadTimeLinkService) {}

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<LeadTimeLink> {
        const id = route.params['id'] ? route.params['id'] : null;
        if (id) {
            return this.service.find(id).pipe(
                filter((response: HttpResponse<LeadTimeLink>) => response.ok),
                map((leadTimeLink: HttpResponse<LeadTimeLink>) => leadTimeLink.body)
            );
        }
        return of(new LeadTimeLink());
    }
}

export const leadTimeLinkRoute: Routes = [
    {
        path: 'lead-time-link',
        component: LeadTimeLinkComponent,
        resolve: {
            pagingParams: JhiResolvePagingParams
        },
        data: {
            authorities: ['ROLE_USER'],
            defaultSort: 'id,asc',
            pageTitle: 'vsdGatewayApp.vsdLeadTimeLink.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'lead-time-link/:id/view',
        component: LeadTimeLinkDetailComponent,
        resolve: {
            leadTimeLink: LeadTimeLinkResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdLeadTimeLink.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'lead-time-link/new',
        component: LeadTimeLinkUpdateComponent,
        resolve: {
            leadTimeLink: LeadTimeLinkResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdLeadTimeLink.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'lead-time-link/:id/edit',
        component: LeadTimeLinkUpdateComponent,
        resolve: {
            leadTimeLink: LeadTimeLinkResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdLeadTimeLink.home.title'
        },
        canActivate: [UserRouteAccessService]
    }
];

export const leadTimeLinkPopupRoute: Routes = [
    {
        path: 'lead-time-link/:id/delete',
        component: LeadTimeLinkDeletePopupComponent,
        resolve: {
            leadTimeLink: LeadTimeLinkResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdLeadTimeLink.home.title'
        },
        canActivate: [UserRouteAccessService],
        outlet: 'popup'
    }
];
