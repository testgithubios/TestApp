import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

import { ILine } from 'app/shared/model/vsd/line.model';
import { LineService } from './line.service';

@Component({
    selector: 'jhi-line-update',
    templateUrl: './line-update.component.html'
})
export class LineUpdateComponent implements OnInit {
    line: ILine;
    isSaving: boolean;

    constructor(private lineService: LineService, private activatedRoute: ActivatedRoute) {}

    ngOnInit() {
        this.isSaving = false;
        this.activatedRoute.data.subscribe(({ line }) => {
            this.line = line;
        });
    }

    previousState() {
        window.history.back();
    }

    save() {
        this.isSaving = true;
        if (this.line.id !== undefined) {
            this.subscribeToSaveResponse(this.lineService.update(this.line));
        } else {
            this.subscribeToSaveResponse(this.lineService.create(this.line));
        }
    }

    private subscribeToSaveResponse(result: Observable<HttpResponse<ILine>>) {
        result.subscribe((res: HttpResponse<ILine>) => this.onSaveSuccess(), (res: HttpErrorResponse) => this.onSaveError());
    }

    private onSaveSuccess() {
        this.isSaving = false;
        this.previousState();
    }

    private onSaveError() {
        this.isSaving = false;
    }
}
