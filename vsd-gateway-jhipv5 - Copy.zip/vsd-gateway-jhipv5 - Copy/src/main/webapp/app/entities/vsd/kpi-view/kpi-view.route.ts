import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes } from '@angular/router';
import { JhiPaginationUtil, JhiResolvePagingParams } from 'ng-jhipster';
import { UserRouteAccessService } from 'app/core';
import { Observable, of } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { KpiView } from 'app/shared/model/vsd/kpi-view.model';
import { KpiViewService } from './kpi-view.service';
import { KpiViewComponent } from './kpi-view.component';
import { KpiViewDetailComponent } from './kpi-view-detail.component';
import { KpiViewUpdateComponent } from './kpi-view-update.component';
import { KpiViewDeletePopupComponent } from './kpi-view-delete-dialog.component';
import { IKpiView } from 'app/shared/model/vsd/kpi-view.model';

@Injectable({ providedIn: 'root' })
export class KpiViewResolve implements Resolve<IKpiView> {
    constructor(private service: KpiViewService) {}

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<KpiView> {
        const id = route.params['id'] ? route.params['id'] : null;
        if (id) {
            return this.service.find(id).pipe(
                filter((response: HttpResponse<KpiView>) => response.ok),
                map((kpiView: HttpResponse<KpiView>) => kpiView.body)
            );
        }
        return of(new KpiView());
    }
}

export const kpiViewRoute: Routes = [
    {
        path: 'kpi-view',
        component: KpiViewComponent,
        resolve: {
            pagingParams: JhiResolvePagingParams
        },
        data: {
            authorities: ['ROLE_USER'],
            defaultSort: 'id,asc',
            pageTitle: 'vsdGatewayApp.vsdKpiView.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'kpi-view/:id/view',
        component: KpiViewDetailComponent,
        resolve: {
            kpiView: KpiViewResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdKpiView.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'kpi-view/new',
        component: KpiViewUpdateComponent,
        resolve: {
            kpiView: KpiViewResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdKpiView.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'kpi-view/:id/edit',
        component: KpiViewUpdateComponent,
        resolve: {
            kpiView: KpiViewResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdKpiView.home.title'
        },
        canActivate: [UserRouteAccessService]
    }
];

export const kpiViewPopupRoute: Routes = [
    {
        path: 'kpi-view/:id/delete',
        component: KpiViewDeletePopupComponent,
        resolve: {
            kpiView: KpiViewResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdKpiView.home.title'
        },
        canActivate: [UserRouteAccessService],
        outlet: 'popup'
    }
];
