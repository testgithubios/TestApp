import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes } from '@angular/router';
import { JhiPaginationUtil, JhiResolvePagingParams } from 'ng-jhipster';
import { UserRouteAccessService } from 'app/core';
import { Observable, of } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { RtAnalysis } from 'app/shared/model/vsd/rt-analysis.model';
import { RtAnalysisService } from './rt-analysis.service';
import { RtAnalysisComponent } from './rt-analysis.component';
import { RtAnalysisDetailComponent } from './rt-analysis-detail.component';
import { RtAnalysisUpdateComponent } from './rt-analysis-update.component';
import { RtAnalysisDeletePopupComponent } from './rt-analysis-delete-dialog.component';
import { IRtAnalysis } from 'app/shared/model/vsd/rt-analysis.model';

@Injectable({ providedIn: 'root' })
export class RtAnalysisResolve implements Resolve<IRtAnalysis> {
    constructor(private service: RtAnalysisService) {}

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<RtAnalysis> {
        const id = route.params['id'] ? route.params['id'] : null;
        if (id) {
            return this.service.find(id).pipe(
                filter((response: HttpResponse<RtAnalysis>) => response.ok),
                map((rtAnalysis: HttpResponse<RtAnalysis>) => rtAnalysis.body)
            );
        }
        return of(new RtAnalysis());
    }
}

export const rtAnalysisRoute: Routes = [
    {
        path: 'rt-analysis',
        component: RtAnalysisComponent,
        resolve: {
            pagingParams: JhiResolvePagingParams
        },
        data: {
            authorities: ['ROLE_USER'],
            defaultSort: 'id,asc',
            pageTitle: 'vsdGatewayApp.vsdRtAnalysis.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'rt-analysis/:id/view',
        component: RtAnalysisDetailComponent,
        resolve: {
            rtAnalysis: RtAnalysisResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdRtAnalysis.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'rt-analysis/new',
        component: RtAnalysisUpdateComponent,
        resolve: {
            rtAnalysis: RtAnalysisResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdRtAnalysis.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'rt-analysis/:id/edit',
        component: RtAnalysisUpdateComponent,
        resolve: {
            rtAnalysis: RtAnalysisResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdRtAnalysis.home.title'
        },
        canActivate: [UserRouteAccessService]
    }
];

export const rtAnalysisPopupRoute: Routes = [
    {
        path: 'rt-analysis/:id/delete',
        component: RtAnalysisDeletePopupComponent,
        resolve: {
            rtAnalysis: RtAnalysisResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdRtAnalysis.home.title'
        },
        canActivate: [UserRouteAccessService],
        outlet: 'popup'
    }
];
