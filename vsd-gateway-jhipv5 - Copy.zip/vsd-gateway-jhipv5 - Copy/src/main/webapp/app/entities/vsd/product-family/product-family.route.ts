import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes } from '@angular/router';
import { JhiPaginationUtil, JhiResolvePagingParams } from 'ng-jhipster';
import { UserRouteAccessService } from 'app/core';
import { Observable, of } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { ProductFamily } from 'app/shared/model/vsd/product-family.model';
import { ProductFamilyService } from './product-family.service';
import { ProductFamilyComponent } from './product-family.component';
import { ProductFamilyDetailComponent } from './product-family-detail.component';
import { ProductFamilyUpdateComponent } from './product-family-update.component';
import { ProductFamilyDeletePopupComponent } from './product-family-delete-dialog.component';
import { IProductFamily } from 'app/shared/model/vsd/product-family.model';

@Injectable({ providedIn: 'root' })
export class ProductFamilyResolve implements Resolve<IProductFamily> {
    constructor(private service: ProductFamilyService) {}

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<ProductFamily> {
        const id = route.params['id'] ? route.params['id'] : null;
        if (id) {
            return this.service.find(id).pipe(
                filter((response: HttpResponse<ProductFamily>) => response.ok),
                map((productFamily: HttpResponse<ProductFamily>) => productFamily.body)
            );
        }
        return of(new ProductFamily());
    }
}

export const productFamilyRoute: Routes = [
    {
        path: 'product-family',
        component: ProductFamilyComponent,
        resolve: {
            pagingParams: JhiResolvePagingParams
        },
        data: {
            authorities: ['ROLE_USER'],
            defaultSort: 'id,asc',
            pageTitle: 'vsdGatewayApp.vsdProductFamily.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'product-family/:id/view',
        component: ProductFamilyDetailComponent,
        resolve: {
            productFamily: ProductFamilyResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdProductFamily.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'product-family/new',
        component: ProductFamilyUpdateComponent,
        resolve: {
            productFamily: ProductFamilyResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdProductFamily.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'product-family/:id/edit',
        component: ProductFamilyUpdateComponent,
        resolve: {
            productFamily: ProductFamilyResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdProductFamily.home.title'
        },
        canActivate: [UserRouteAccessService]
    }
];

export const productFamilyPopupRoute: Routes = [
    {
        path: 'product-family/:id/delete',
        component: ProductFamilyDeletePopupComponent,
        resolve: {
            productFamily: ProductFamilyResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdProductFamily.home.title'
        },
        canActivate: [UserRouteAccessService],
        outlet: 'popup'
    }
];
