import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { VsdGatewaySharedModule } from 'app/shared';
import {
    FeatureStatusComponent,
    FeatureStatusDetailComponent,
    FeatureStatusUpdateComponent,
    FeatureStatusDeletePopupComponent,
    FeatureStatusDeleteDialogComponent,
    featureStatusRoute,
    featureStatusPopupRoute
} from './';

const ENTITY_STATES = [...featureStatusRoute, ...featureStatusPopupRoute];

@NgModule({
    imports: [VsdGatewaySharedModule, RouterModule.forChild(ENTITY_STATES)],
    declarations: [
        FeatureStatusComponent,
        FeatureStatusDetailComponent,
        FeatureStatusUpdateComponent,
        FeatureStatusDeleteDialogComponent,
        FeatureStatusDeletePopupComponent
    ],
    entryComponents: [
        FeatureStatusComponent,
        FeatureStatusUpdateComponent,
        FeatureStatusDeleteDialogComponent,
        FeatureStatusDeletePopupComponent
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class VsdGatewayFeatureStatusModule {}
