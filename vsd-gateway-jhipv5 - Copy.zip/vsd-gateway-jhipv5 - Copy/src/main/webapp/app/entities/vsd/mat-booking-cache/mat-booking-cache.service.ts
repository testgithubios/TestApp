import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as moment from 'moment';
import { DATE_FORMAT } from 'app/shared/constants/input.constants';
import { map } from 'rxjs/operators';

import { SERVER_API_URL } from 'app/app.constants';
import { createRequestOption } from 'app/shared';
import { IMatBookingCache } from 'app/shared/model/vsd/mat-booking-cache.model';

type EntityResponseType = HttpResponse<IMatBookingCache>;
type EntityArrayResponseType = HttpResponse<IMatBookingCache[]>;

@Injectable({ providedIn: 'root' })
export class MatBookingCacheService {
    public resourceUrl = SERVER_API_URL + 'vsd/api/mat-booking-caches';
    public resourceSearchUrl = SERVER_API_URL + 'vsd/api/_search/mat-booking-caches';

    constructor(private http: HttpClient) {}

    create(matBookingCache: IMatBookingCache): Observable<EntityResponseType> {
        const copy = this.convertDateFromClient(matBookingCache);
        return this.http
            .post<IMatBookingCache>(this.resourceUrl, copy, { observe: 'response' })
            .pipe(map((res: EntityResponseType) => this.convertDateFromServer(res)));
    }

    update(matBookingCache: IMatBookingCache): Observable<EntityResponseType> {
        const copy = this.convertDateFromClient(matBookingCache);
        return this.http
            .put<IMatBookingCache>(this.resourceUrl, copy, { observe: 'response' })
            .pipe(map((res: EntityResponseType) => this.convertDateFromServer(res)));
    }

    find(id: number): Observable<EntityResponseType> {
        return this.http
            .get<IMatBookingCache>(`${this.resourceUrl}/${id}`, { observe: 'response' })
            .pipe(map((res: EntityResponseType) => this.convertDateFromServer(res)));
    }

    query(req?: any): Observable<EntityArrayResponseType> {
        const options = createRequestOption(req);
        return this.http
            .get<IMatBookingCache[]>(this.resourceUrl, { params: options, observe: 'response' })
            .pipe(map((res: EntityArrayResponseType) => this.convertDateArrayFromServer(res)));
    }

    delete(id: number): Observable<HttpResponse<any>> {
        return this.http.delete<any>(`${this.resourceUrl}/${id}`, { observe: 'response' });
    }

    search(req?: any): Observable<EntityArrayResponseType> {
        const options = createRequestOption(req);
        return this.http
            .get<IMatBookingCache[]>(this.resourceSearchUrl, { params: options, observe: 'response' })
            .pipe(map((res: EntityArrayResponseType) => this.convertDateArrayFromServer(res)));
    }

    protected convertDateFromClient(matBookingCache: IMatBookingCache): IMatBookingCache {
        const copy: IMatBookingCache = Object.assign({}, matBookingCache, {
            startTime: matBookingCache.startTime != null && matBookingCache.startTime.isValid() ? matBookingCache.startTime.toJSON() : null
        });
        return copy;
    }

    protected convertDateFromServer(res: EntityResponseType): EntityResponseType {
        if (res.body) {
            res.body.startTime = res.body.startTime != null ? moment(res.body.startTime) : null;
        }
        return res;
    }

    protected convertDateArrayFromServer(res: EntityArrayResponseType): EntityArrayResponseType {
        if (res.body) {
            res.body.forEach((matBookingCache: IMatBookingCache) => {
                matBookingCache.startTime = matBookingCache.startTime != null ? moment(matBookingCache.startTime) : null;
            });
        }
        return res;
    }
}
