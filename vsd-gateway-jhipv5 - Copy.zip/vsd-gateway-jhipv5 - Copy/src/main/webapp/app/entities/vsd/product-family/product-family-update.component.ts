import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

import { IProductFamily } from 'app/shared/model/vsd/product-family.model';
import { ProductFamilyService } from './product-family.service';

@Component({
    selector: 'jhi-product-family-update',
    templateUrl: './product-family-update.component.html'
})
export class ProductFamilyUpdateComponent implements OnInit {
    productFamily: IProductFamily;
    isSaving: boolean;

    constructor(private productFamilyService: ProductFamilyService, private activatedRoute: ActivatedRoute) {}

    ngOnInit() {
        this.isSaving = false;
        this.activatedRoute.data.subscribe(({ productFamily }) => {
            this.productFamily = productFamily;
        });
    }

    previousState() {
        window.history.back();
    }

    save() {
        this.isSaving = true;
        if (this.productFamily.id !== undefined) {
            this.subscribeToSaveResponse(this.productFamilyService.update(this.productFamily));
        } else {
            this.subscribeToSaveResponse(this.productFamilyService.create(this.productFamily));
        }
    }

    private subscribeToSaveResponse(result: Observable<HttpResponse<IProductFamily>>) {
        result.subscribe((res: HttpResponse<IProductFamily>) => this.onSaveSuccess(), (res: HttpErrorResponse) => this.onSaveError());
    }

    private onSaveSuccess() {
        this.isSaving = false;
        this.previousState();
    }

    private onSaveError() {
        this.isSaving = false;
    }
}
