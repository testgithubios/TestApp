import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { VsdGatewaySharedModule } from 'app/shared';
import {
    ReaderNumberComponent,
    ReaderNumberDetailComponent,
    ReaderNumberUpdateComponent,
    ReaderNumberDeletePopupComponent,
    ReaderNumberDeleteDialogComponent,
    readerNumberRoute,
    readerNumberPopupRoute
} from './';

const ENTITY_STATES = [...readerNumberRoute, ...readerNumberPopupRoute];

@NgModule({
    imports: [VsdGatewaySharedModule, RouterModule.forChild(ENTITY_STATES)],
    declarations: [
        ReaderNumberComponent,
        ReaderNumberDetailComponent,
        ReaderNumberUpdateComponent,
        ReaderNumberDeleteDialogComponent,
        ReaderNumberDeletePopupComponent
    ],
    entryComponents: [
        ReaderNumberComponent,
        ReaderNumberUpdateComponent,
        ReaderNumberDeleteDialogComponent,
        ReaderNumberDeletePopupComponent
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class VsdGatewayReaderNumberModule {}
