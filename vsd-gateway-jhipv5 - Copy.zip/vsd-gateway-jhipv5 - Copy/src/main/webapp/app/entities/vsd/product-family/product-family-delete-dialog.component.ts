import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { NgbActiveModal, NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { JhiEventManager } from 'ng-jhipster';

import { IProductFamily } from 'app/shared/model/vsd/product-family.model';
import { ProductFamilyService } from './product-family.service';

@Component({
    selector: 'jhi-product-family-delete-dialog',
    templateUrl: './product-family-delete-dialog.component.html'
})
export class ProductFamilyDeleteDialogComponent {
    productFamily: IProductFamily;

    constructor(
        private productFamilyService: ProductFamilyService,
        public activeModal: NgbActiveModal,
        private eventManager: JhiEventManager
    ) {}

    clear() {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete(id: number) {
        this.productFamilyService.delete(id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'productFamilyListModification',
                content: 'Deleted an productFamily'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'jhi-product-family-delete-popup',
    template: ''
})
export class ProductFamilyDeletePopupComponent implements OnInit, OnDestroy {
    private ngbModalRef: NgbModalRef;

    constructor(private activatedRoute: ActivatedRoute, private router: Router, private modalService: NgbModal) {}

    ngOnInit() {
        this.activatedRoute.data.subscribe(({ productFamily }) => {
            setTimeout(() => {
                this.ngbModalRef = this.modalService.open(ProductFamilyDeleteDialogComponent as Component, {
                    size: 'lg',
                    backdrop: 'static'
                });
                this.ngbModalRef.componentInstance.productFamily = productFamily;
                this.ngbModalRef.result.then(
                    result => {
                        this.router.navigate([{ outlets: { popup: null } }], { replaceUrl: true, queryParamsHandling: 'merge' });
                        this.ngbModalRef = null;
                    },
                    reason => {
                        this.router.navigate([{ outlets: { popup: null } }], { replaceUrl: true, queryParamsHandling: 'merge' });
                        this.ngbModalRef = null;
                    }
                );
            }, 0);
        });
    }

    ngOnDestroy() {
        this.ngbModalRef = null;
    }
}
