import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { IFeatureStatus } from 'app/shared/model/vsd/feature-status.model';

@Component({
    selector: 'jhi-feature-status-detail',
    templateUrl: './feature-status-detail.component.html'
})
export class FeatureStatusDetailComponent implements OnInit {
    featureStatus: IFeatureStatus;

    constructor(private activatedRoute: ActivatedRoute) {}

    ngOnInit() {
        this.activatedRoute.data.subscribe(({ featureStatus }) => {
            this.featureStatus = featureStatus;
        });
    }

    previousState() {
        window.history.back();
    }
}
