import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { IPartNumberTranslator } from 'app/shared/model/vsd/part-number-translator.model';

@Component({
    selector: 'jhi-part-number-translator-detail',
    templateUrl: './part-number-translator-detail.component.html'
})
export class PartNumberTranslatorDetailComponent implements OnInit {
    partNumberTranslator: IPartNumberTranslator;

    constructor(private activatedRoute: ActivatedRoute) {}

    ngOnInit() {
        this.activatedRoute.data.subscribe(({ partNumberTranslator }) => {
            this.partNumberTranslator = partNumberTranslator;
        });
    }

    previousState() {
        window.history.back();
    }
}
