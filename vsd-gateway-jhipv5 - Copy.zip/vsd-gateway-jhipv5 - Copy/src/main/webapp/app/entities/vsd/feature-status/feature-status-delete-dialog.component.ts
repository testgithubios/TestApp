import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { NgbActiveModal, NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { JhiEventManager } from 'ng-jhipster';

import { IFeatureStatus } from 'app/shared/model/vsd/feature-status.model';
import { FeatureStatusService } from './feature-status.service';

@Component({
    selector: 'jhi-feature-status-delete-dialog',
    templateUrl: './feature-status-delete-dialog.component.html'
})
export class FeatureStatusDeleteDialogComponent {
    featureStatus: IFeatureStatus;

    constructor(
        private featureStatusService: FeatureStatusService,
        public activeModal: NgbActiveModal,
        private eventManager: JhiEventManager
    ) {}

    clear() {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete(id: number) {
        this.featureStatusService.delete(id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'featureStatusListModification',
                content: 'Deleted an featureStatus'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'jhi-feature-status-delete-popup',
    template: ''
})
export class FeatureStatusDeletePopupComponent implements OnInit, OnDestroy {
    private ngbModalRef: NgbModalRef;

    constructor(private activatedRoute: ActivatedRoute, private router: Router, private modalService: NgbModal) {}

    ngOnInit() {
        this.activatedRoute.data.subscribe(({ featureStatus }) => {
            setTimeout(() => {
                this.ngbModalRef = this.modalService.open(FeatureStatusDeleteDialogComponent as Component, {
                    size: 'lg',
                    backdrop: 'static'
                });
                this.ngbModalRef.componentInstance.featureStatus = featureStatus;
                this.ngbModalRef.result.then(
                    result => {
                        this.router.navigate([{ outlets: { popup: null } }], { replaceUrl: true, queryParamsHandling: 'merge' });
                        this.ngbModalRef = null;
                    },
                    reason => {
                        this.router.navigate([{ outlets: { popup: null } }], { replaceUrl: true, queryParamsHandling: 'merge' });
                        this.ngbModalRef = null;
                    }
                );
            }, 0);
        });
    }

    ngOnDestroy() {
        this.ngbModalRef = null;
    }
}
