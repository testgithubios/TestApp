import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

import { SERVER_API_URL } from 'app/app.constants';
import { createRequestOption } from 'app/shared';
import { ILine } from 'app/shared/model/vsd/line.model';

type EntityResponseType = HttpResponse<ILine>;
type EntityArrayResponseType = HttpResponse<ILine[]>;

@Injectable({ providedIn: 'root' })
export class LineService {
    public resourceUrl = SERVER_API_URL + 'vsd/api/lines';
    public resourceSearchUrl = SERVER_API_URL + 'vsd/api/_search/lines';

    constructor(private http: HttpClient) {}

    create(line: ILine): Observable<EntityResponseType> {
        return this.http.post<ILine>(this.resourceUrl, line, { observe: 'response' });
    }

    update(line: ILine): Observable<EntityResponseType> {
        return this.http.put<ILine>(this.resourceUrl, line, { observe: 'response' });
    }

    find(id: number): Observable<EntityResponseType> {
        return this.http.get<ILine>(`${this.resourceUrl}/${id}`, { observe: 'response' });
    }

    query(req?: any): Observable<EntityArrayResponseType> {
        const options = createRequestOption(req);
        return this.http.get<ILine[]>(this.resourceUrl, { params: options, observe: 'response' });
    }

    delete(id: number): Observable<HttpResponse<any>> {
        return this.http.delete<any>(`${this.resourceUrl}/${id}`, { observe: 'response' });
    }

    search(req?: any): Observable<EntityArrayResponseType> {
        const options = createRequestOption(req);
        return this.http.get<ILine[]>(this.resourceSearchUrl, { params: options, observe: 'response' });
    }
}
