import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

import { SERVER_API_URL } from 'app/app.constants';
import { createRequestOption } from 'app/shared';
import { IPartNumberTranslator } from 'app/shared/model/vsd/part-number-translator.model';

type EntityResponseType = HttpResponse<IPartNumberTranslator>;
type EntityArrayResponseType = HttpResponse<IPartNumberTranslator[]>;

@Injectable({ providedIn: 'root' })
export class PartNumberTranslatorService {
    public resourceUrl = SERVER_API_URL + 'vsd/api/part-number-translators';
    public resourceSearchUrl = SERVER_API_URL + 'vsd/api/_search/part-number-translators';

    constructor(private http: HttpClient) {}

    create(partNumberTranslator: IPartNumberTranslator): Observable<EntityResponseType> {
        return this.http.post<IPartNumberTranslator>(this.resourceUrl, partNumberTranslator, { observe: 'response' });
    }

    update(partNumberTranslator: IPartNumberTranslator): Observable<EntityResponseType> {
        return this.http.put<IPartNumberTranslator>(this.resourceUrl, partNumberTranslator, { observe: 'response' });
    }

    find(id: number): Observable<EntityResponseType> {
        return this.http.get<IPartNumberTranslator>(`${this.resourceUrl}/${id}`, { observe: 'response' });
    }

    query(req?: any): Observable<EntityArrayResponseType> {
        const options = createRequestOption(req);
        return this.http.get<IPartNumberTranslator[]>(this.resourceUrl, { params: options, observe: 'response' });
    }

    delete(id: number): Observable<HttpResponse<any>> {
        return this.http.delete<any>(`${this.resourceUrl}/${id}`, { observe: 'response' });
    }

    search(req?: any): Observable<EntityArrayResponseType> {
        const options = createRequestOption(req);
        return this.http.get<IPartNumberTranslator[]>(this.resourceSearchUrl, { params: options, observe: 'response' });
    }
}
