export * from './reader-number.service';
export * from './reader-number-update.component';
export * from './reader-number-delete-dialog.component';
export * from './reader-number-detail.component';
export * from './reader-number.component';
export * from './reader-number.route';
