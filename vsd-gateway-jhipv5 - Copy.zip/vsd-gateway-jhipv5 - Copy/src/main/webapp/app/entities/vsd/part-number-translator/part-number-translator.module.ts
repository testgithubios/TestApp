import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { VsdGatewaySharedModule } from 'app/shared';
import {
    PartNumberTranslatorComponent,
    PartNumberTranslatorDetailComponent,
    PartNumberTranslatorUpdateComponent,
    PartNumberTranslatorDeletePopupComponent,
    PartNumberTranslatorDeleteDialogComponent,
    partNumberTranslatorRoute,
    partNumberTranslatorPopupRoute
} from './';

const ENTITY_STATES = [...partNumberTranslatorRoute, ...partNumberTranslatorPopupRoute];

@NgModule({
    imports: [VsdGatewaySharedModule, RouterModule.forChild(ENTITY_STATES)],
    declarations: [
        PartNumberTranslatorComponent,
        PartNumberTranslatorDetailComponent,
        PartNumberTranslatorUpdateComponent,
        PartNumberTranslatorDeleteDialogComponent,
        PartNumberTranslatorDeletePopupComponent
    ],
    entryComponents: [
        PartNumberTranslatorComponent,
        PartNumberTranslatorUpdateComponent,
        PartNumberTranslatorDeleteDialogComponent,
        PartNumberTranslatorDeletePopupComponent
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class VsdGatewayPartNumberTranslatorModule {}
