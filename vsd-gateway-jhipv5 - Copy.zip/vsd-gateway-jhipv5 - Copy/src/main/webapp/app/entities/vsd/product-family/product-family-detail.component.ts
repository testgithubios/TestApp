import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { IProductFamily } from 'app/shared/model/vsd/product-family.model';

@Component({
    selector: 'jhi-product-family-detail',
    templateUrl: './product-family-detail.component.html'
})
export class ProductFamilyDetailComponent implements OnInit {
    productFamily: IProductFamily;

    constructor(private activatedRoute: ActivatedRoute) {}

    ngOnInit() {
        this.activatedRoute.data.subscribe(({ productFamily }) => {
            this.productFamily = productFamily;
        });
    }

    previousState() {
        window.history.back();
    }
}
