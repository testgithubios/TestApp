import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { VsdGatewaySharedModule } from 'app/shared';
import {
    LeadTimeLinkComponent,
    LeadTimeLinkDetailComponent,
    LeadTimeLinkUpdateComponent,
    LeadTimeLinkDeletePopupComponent,
    LeadTimeLinkDeleteDialogComponent,
    leadTimeLinkRoute,
    leadTimeLinkPopupRoute
} from './';

const ENTITY_STATES = [...leadTimeLinkRoute, ...leadTimeLinkPopupRoute];

@NgModule({
    imports: [VsdGatewaySharedModule, RouterModule.forChild(ENTITY_STATES)],
    declarations: [
        LeadTimeLinkComponent,
        LeadTimeLinkDetailComponent,
        LeadTimeLinkUpdateComponent,
        LeadTimeLinkDeleteDialogComponent,
        LeadTimeLinkDeletePopupComponent
    ],
    entryComponents: [
        LeadTimeLinkComponent,
        LeadTimeLinkUpdateComponent,
        LeadTimeLinkDeleteDialogComponent,
        LeadTimeLinkDeletePopupComponent
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class VsdGatewayLeadTimeLinkModule {}
