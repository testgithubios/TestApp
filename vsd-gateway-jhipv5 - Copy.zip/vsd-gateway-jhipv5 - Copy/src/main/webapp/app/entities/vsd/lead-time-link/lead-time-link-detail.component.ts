import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { ILeadTimeLink } from 'app/shared/model/vsd/lead-time-link.model';

@Component({
    selector: 'jhi-lead-time-link-detail',
    templateUrl: './lead-time-link-detail.component.html'
})
export class LeadTimeLinkDetailComponent implements OnInit {
    leadTimeLink: ILeadTimeLink;

    constructor(private activatedRoute: ActivatedRoute) {}

    ngOnInit() {
        this.activatedRoute.data.subscribe(({ leadTimeLink }) => {
            this.leadTimeLink = leadTimeLink;
        });
    }

    previousState() {
        window.history.back();
    }
}
