import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { NgbActiveModal, NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { JhiEventManager } from 'ng-jhipster';

import { IMatBookingCache } from 'app/shared/model/vsd/mat-booking-cache.model';
import { MatBookingCacheService } from './mat-booking-cache.service';

@Component({
    selector: 'jhi-mat-booking-cache-delete-dialog',
    templateUrl: './mat-booking-cache-delete-dialog.component.html'
})
export class MatBookingCacheDeleteDialogComponent {
    matBookingCache: IMatBookingCache;

    constructor(
        private matBookingCacheService: MatBookingCacheService,
        public activeModal: NgbActiveModal,
        private eventManager: JhiEventManager
    ) {}

    clear() {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete(id: number) {
        this.matBookingCacheService.delete(id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'matBookingCacheListModification',
                content: 'Deleted an matBookingCache'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'jhi-mat-booking-cache-delete-popup',
    template: ''
})
export class MatBookingCacheDeletePopupComponent implements OnInit, OnDestroy {
    private ngbModalRef: NgbModalRef;

    constructor(private activatedRoute: ActivatedRoute, private router: Router, private modalService: NgbModal) {}

    ngOnInit() {
        this.activatedRoute.data.subscribe(({ matBookingCache }) => {
            setTimeout(() => {
                this.ngbModalRef = this.modalService.open(MatBookingCacheDeleteDialogComponent as Component, {
                    size: 'lg',
                    backdrop: 'static'
                });
                this.ngbModalRef.componentInstance.matBookingCache = matBookingCache;
                this.ngbModalRef.result.then(
                    result => {
                        this.router.navigate([{ outlets: { popup: null } }], { replaceUrl: true, queryParamsHandling: 'merge' });
                        this.ngbModalRef = null;
                    },
                    reason => {
                        this.router.navigate([{ outlets: { popup: null } }], { replaceUrl: true, queryParamsHandling: 'merge' });
                        this.ngbModalRef = null;
                    }
                );
            }, 0);
        });
    }

    ngOnDestroy() {
        this.ngbModalRef = null;
    }
}
