import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { JhiAlertService } from 'ng-jhipster';

import { IReaderNumber } from 'app/shared/model/vsd/reader-number.model';
import { ReaderNumberService } from './reader-number.service';
import { IReader } from 'app/shared/model/vsd/reader.model';
import { ReaderService } from 'app/entities/vsd/reader';

@Component({
    selector: 'jhi-reader-number-update',
    templateUrl: './reader-number-update.component.html'
})
export class ReaderNumberUpdateComponent implements OnInit {
    readerNumber: IReaderNumber;
    isSaving: boolean;

    readers: IReader[];

    constructor(
        private jhiAlertService: JhiAlertService,
        private readerNumberService: ReaderNumberService,
        private readerService: ReaderService,
        private activatedRoute: ActivatedRoute
    ) {}

    ngOnInit() {
        this.isSaving = false;
        this.activatedRoute.data.subscribe(({ readerNumber }) => {
            this.readerNumber = readerNumber;
        });
        this.readerService.query().subscribe(
            (res: HttpResponse<IReader[]>) => {
                this.readers = res.body;
            },
            (res: HttpErrorResponse) => this.onError(res.message)
        );
    }

    previousState() {
        window.history.back();
    }

    save() {
        this.isSaving = true;
        if (this.readerNumber.id !== undefined) {
            this.subscribeToSaveResponse(this.readerNumberService.update(this.readerNumber));
        } else {
            this.subscribeToSaveResponse(this.readerNumberService.create(this.readerNumber));
        }
    }

    private subscribeToSaveResponse(result: Observable<HttpResponse<IReaderNumber>>) {
        result.subscribe((res: HttpResponse<IReaderNumber>) => this.onSaveSuccess(), (res: HttpErrorResponse) => this.onSaveError());
    }

    private onSaveSuccess() {
        this.isSaving = false;
        this.previousState();
    }

    private onSaveError() {
        this.isSaving = false;
    }

    private onError(errorMessage: string) {
        this.jhiAlertService.error(errorMessage, null, null);
    }

    trackReaderById(index: number, item: IReader) {
        return item.id;
    }

    getSelected(selectedVals: Array<any>, option: any) {
        if (selectedVals) {
            for (let i = 0; i < selectedVals.length; i++) {
                if (option.id === selectedVals[i].id) {
                    return selectedVals[i];
                }
            }
        }
        return option;
    }
}
