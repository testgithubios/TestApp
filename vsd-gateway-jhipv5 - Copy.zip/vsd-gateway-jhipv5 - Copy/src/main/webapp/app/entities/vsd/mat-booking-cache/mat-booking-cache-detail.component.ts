import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { IMatBookingCache } from 'app/shared/model/vsd/mat-booking-cache.model';

@Component({
    selector: 'jhi-mat-booking-cache-detail',
    templateUrl: './mat-booking-cache-detail.component.html'
})
export class MatBookingCacheDetailComponent implements OnInit {
    matBookingCache: IMatBookingCache;

    constructor(private activatedRoute: ActivatedRoute) {}

    ngOnInit() {
        this.activatedRoute.data.subscribe(({ matBookingCache }) => {
            this.matBookingCache = matBookingCache;
        });
    }

    previousState() {
        window.history.back();
    }
}
