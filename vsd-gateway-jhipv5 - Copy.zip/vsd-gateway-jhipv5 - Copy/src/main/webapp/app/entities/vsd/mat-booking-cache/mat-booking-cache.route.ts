import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes } from '@angular/router';
import { JhiPaginationUtil, JhiResolvePagingParams } from 'ng-jhipster';
import { UserRouteAccessService } from 'app/core';
import { Observable, of } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { MatBookingCache } from 'app/shared/model/vsd/mat-booking-cache.model';
import { MatBookingCacheService } from './mat-booking-cache.service';
import { MatBookingCacheComponent } from './mat-booking-cache.component';
import { MatBookingCacheDetailComponent } from './mat-booking-cache-detail.component';
import { MatBookingCacheUpdateComponent } from './mat-booking-cache-update.component';
import { MatBookingCacheDeletePopupComponent } from './mat-booking-cache-delete-dialog.component';
import { IMatBookingCache } from 'app/shared/model/vsd/mat-booking-cache.model';

@Injectable({ providedIn: 'root' })
export class MatBookingCacheResolve implements Resolve<IMatBookingCache> {
    constructor(private service: MatBookingCacheService) {}

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<MatBookingCache> {
        const id = route.params['id'] ? route.params['id'] : null;
        if (id) {
            return this.service.find(id).pipe(
                filter((response: HttpResponse<MatBookingCache>) => response.ok),
                map((matBookingCache: HttpResponse<MatBookingCache>) => matBookingCache.body)
            );
        }
        return of(new MatBookingCache());
    }
}

export const matBookingCacheRoute: Routes = [
    {
        path: 'mat-booking-cache',
        component: MatBookingCacheComponent,
        resolve: {
            pagingParams: JhiResolvePagingParams
        },
        data: {
            authorities: ['ROLE_USER'],
            defaultSort: 'id,asc',
            pageTitle: 'vsdGatewayApp.vsdMatBookingCache.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'mat-booking-cache/:id/view',
        component: MatBookingCacheDetailComponent,
        resolve: {
            matBookingCache: MatBookingCacheResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdMatBookingCache.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'mat-booking-cache/new',
        component: MatBookingCacheUpdateComponent,
        resolve: {
            matBookingCache: MatBookingCacheResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdMatBookingCache.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'mat-booking-cache/:id/edit',
        component: MatBookingCacheUpdateComponent,
        resolve: {
            matBookingCache: MatBookingCacheResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdMatBookingCache.home.title'
        },
        canActivate: [UserRouteAccessService]
    }
];

export const matBookingCachePopupRoute: Routes = [
    {
        path: 'mat-booking-cache/:id/delete',
        component: MatBookingCacheDeletePopupComponent,
        resolve: {
            matBookingCache: MatBookingCacheResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdMatBookingCache.home.title'
        },
        canActivate: [UserRouteAccessService],
        outlet: 'popup'
    }
];
