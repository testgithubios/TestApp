import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

import { SERVER_API_URL } from 'app/app.constants';
import { createRequestOption } from 'app/shared';
import { IReaderNumber } from 'app/shared/model/vsd/reader-number.model';

type EntityResponseType = HttpResponse<IReaderNumber>;
type EntityArrayResponseType = HttpResponse<IReaderNumber[]>;

@Injectable({ providedIn: 'root' })
export class ReaderNumberService {
    public resourceUrl = SERVER_API_URL + 'vsd/api/reader-numbers';
    public resourceSearchUrl = SERVER_API_URL + 'vsd/api/_search/reader-numbers';

    constructor(private http: HttpClient) {}

    create(readerNumber: IReaderNumber): Observable<EntityResponseType> {
        return this.http.post<IReaderNumber>(this.resourceUrl, readerNumber, { observe: 'response' });
    }

    update(readerNumber: IReaderNumber): Observable<EntityResponseType> {
        return this.http.put<IReaderNumber>(this.resourceUrl, readerNumber, { observe: 'response' });
    }

    find(id: number): Observable<EntityResponseType> {
        return this.http.get<IReaderNumber>(`${this.resourceUrl}/${id}`, { observe: 'response' });
    }

    query(req?: any): Observable<EntityArrayResponseType> {
        const options = createRequestOption(req);
        return this.http.get<IReaderNumber[]>(this.resourceUrl, { params: options, observe: 'response' });
    }

    delete(id: number): Observable<HttpResponse<any>> {
        return this.http.delete<any>(`${this.resourceUrl}/${id}`, { observe: 'response' });
    }

    search(req?: any): Observable<EntityArrayResponseType> {
        const options = createRequestOption(req);
        return this.http.get<IReaderNumber[]>(this.resourceSearchUrl, { params: options, observe: 'response' });
    }
}
