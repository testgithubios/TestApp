import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes } from '@angular/router';
import { UserRouteAccessService } from 'app/core';
import { Observable, of } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { PartNumberTranslator } from 'app/shared/model/vsd/part-number-translator.model';
import { PartNumberTranslatorService } from './part-number-translator.service';
import { PartNumberTranslatorComponent } from './part-number-translator.component';
import { PartNumberTranslatorDetailComponent } from './part-number-translator-detail.component';
import { PartNumberTranslatorUpdateComponent } from './part-number-translator-update.component';
import { PartNumberTranslatorDeletePopupComponent } from './part-number-translator-delete-dialog.component';
import { IPartNumberTranslator } from 'app/shared/model/vsd/part-number-translator.model';

@Injectable({ providedIn: 'root' })
export class PartNumberTranslatorResolve implements Resolve<IPartNumberTranslator> {
    constructor(private service: PartNumberTranslatorService) {}

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<PartNumberTranslator> {
        const id = route.params['id'] ? route.params['id'] : null;
        if (id) {
            return this.service.find(id).pipe(
                filter((response: HttpResponse<PartNumberTranslator>) => response.ok),
                map((partNumberTranslator: HttpResponse<PartNumberTranslator>) => partNumberTranslator.body)
            );
        }
        return of(new PartNumberTranslator());
    }
}

export const partNumberTranslatorRoute: Routes = [
    {
        path: 'part-number-translator',
        component: PartNumberTranslatorComponent,
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdPartNumberTranslator.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'part-number-translator/:id/view',
        component: PartNumberTranslatorDetailComponent,
        resolve: {
            partNumberTranslator: PartNumberTranslatorResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdPartNumberTranslator.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'part-number-translator/new',
        component: PartNumberTranslatorUpdateComponent,
        resolve: {
            partNumberTranslator: PartNumberTranslatorResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdPartNumberTranslator.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'part-number-translator/:id/edit',
        component: PartNumberTranslatorUpdateComponent,
        resolve: {
            partNumberTranslator: PartNumberTranslatorResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdPartNumberTranslator.home.title'
        },
        canActivate: [UserRouteAccessService]
    }
];

export const partNumberTranslatorPopupRoute: Routes = [
    {
        path: 'part-number-translator/:id/delete',
        component: PartNumberTranslatorDeletePopupComponent,
        resolve: {
            partNumberTranslator: PartNumberTranslatorResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdPartNumberTranslator.home.title'
        },
        canActivate: [UserRouteAccessService],
        outlet: 'popup'
    }
];
