export * from './reader.service';
export * from './reader-update.component';
export * from './reader-delete-dialog.component';
export * from './reader-detail.component';
export * from './reader.component';
export * from './reader.route';
