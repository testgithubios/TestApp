import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes } from '@angular/router';
import { JhiPaginationUtil, JhiResolvePagingParams } from 'ng-jhipster';
import { UserRouteAccessService } from 'app/core';
import { Observable, of } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { FeatureStatus } from 'app/shared/model/vsd/feature-status.model';
import { FeatureStatusService } from './feature-status.service';
import { FeatureStatusComponent } from './feature-status.component';
import { FeatureStatusDetailComponent } from './feature-status-detail.component';
import { FeatureStatusUpdateComponent } from './feature-status-update.component';
import { FeatureStatusDeletePopupComponent } from './feature-status-delete-dialog.component';
import { IFeatureStatus } from 'app/shared/model/vsd/feature-status.model';

@Injectable({ providedIn: 'root' })
export class FeatureStatusResolve implements Resolve<IFeatureStatus> {
    constructor(private service: FeatureStatusService) {}

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<FeatureStatus> {
        const id = route.params['id'] ? route.params['id'] : null;
        if (id) {
            return this.service.find(id).pipe(
                filter((response: HttpResponse<FeatureStatus>) => response.ok),
                map((featureStatus: HttpResponse<FeatureStatus>) => featureStatus.body)
            );
        }
        return of(new FeatureStatus());
    }
}

export const featureStatusRoute: Routes = [
    {
        path: 'feature-status',
        component: FeatureStatusComponent,
        resolve: {
            pagingParams: JhiResolvePagingParams
        },
        data: {
            authorities: ['ROLE_USER'],
            defaultSort: 'id,asc',
            pageTitle: 'vsdGatewayApp.vsdFeatureStatus.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'feature-status/:id/view',
        component: FeatureStatusDetailComponent,
        resolve: {
            featureStatus: FeatureStatusResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdFeatureStatus.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'feature-status/new',
        component: FeatureStatusUpdateComponent,
        resolve: {
            featureStatus: FeatureStatusResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdFeatureStatus.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'feature-status/:id/edit',
        component: FeatureStatusUpdateComponent,
        resolve: {
            featureStatus: FeatureStatusResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdFeatureStatus.home.title'
        },
        canActivate: [UserRouteAccessService]
    }
];

export const featureStatusPopupRoute: Routes = [
    {
        path: 'feature-status/:id/delete',
        component: FeatureStatusDeletePopupComponent,
        resolve: {
            featureStatus: FeatureStatusResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdFeatureStatus.home.title'
        },
        canActivate: [UserRouteAccessService],
        outlet: 'popup'
    }
];
