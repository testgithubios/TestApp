import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { VsdGatewaySharedModule } from 'app/shared';
import {
    RtAnalysisComponent,
    RtAnalysisDetailComponent,
    RtAnalysisUpdateComponent,
    RtAnalysisDeletePopupComponent,
    RtAnalysisDeleteDialogComponent,
    rtAnalysisRoute,
    rtAnalysisPopupRoute
} from './';

const ENTITY_STATES = [...rtAnalysisRoute, ...rtAnalysisPopupRoute];

@NgModule({
    imports: [VsdGatewaySharedModule, RouterModule.forChild(ENTITY_STATES)],
    declarations: [
        RtAnalysisComponent,
        RtAnalysisDetailComponent,
        RtAnalysisUpdateComponent,
        RtAnalysisDeleteDialogComponent,
        RtAnalysisDeletePopupComponent
    ],
    entryComponents: [RtAnalysisComponent, RtAnalysisUpdateComponent, RtAnalysisDeleteDialogComponent, RtAnalysisDeletePopupComponent],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class VsdGatewayRtAnalysisModule {}
