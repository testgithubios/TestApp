import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes } from '@angular/router';
import { JhiPaginationUtil, JhiResolvePagingParams } from 'ng-jhipster';
import { UserRouteAccessService } from 'app/core';
import { Observable, of } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { Reader } from 'app/shared/model/vsd/reader.model';
import { ReaderService } from './reader.service';
import { ReaderComponent } from './reader.component';
import { ReaderDetailComponent } from './reader-detail.component';
import { ReaderUpdateComponent } from './reader-update.component';
import { ReaderDeletePopupComponent } from './reader-delete-dialog.component';
import { IReader } from 'app/shared/model/vsd/reader.model';

@Injectable({ providedIn: 'root' })
export class ReaderResolve implements Resolve<IReader> {
    constructor(private service: ReaderService) {}

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<Reader> {
        const id = route.params['id'] ? route.params['id'] : null;
        if (id) {
            return this.service.find(id).pipe(
                filter((response: HttpResponse<Reader>) => response.ok),
                map((reader: HttpResponse<Reader>) => reader.body)
            );
        }
        return of(new Reader());
    }
}

export const readerRoute: Routes = [
    {
        path: 'reader',
        component: ReaderComponent,
        resolve: {
            pagingParams: JhiResolvePagingParams
        },
        data: {
            authorities: ['ROLE_USER'],
            defaultSort: 'id,asc',
            pageTitle: 'vsdGatewayApp.vsdReader.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'reader/:id/view',
        component: ReaderDetailComponent,
        resolve: {
            reader: ReaderResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdReader.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'reader/new',
        component: ReaderUpdateComponent,
        resolve: {
            reader: ReaderResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdReader.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'reader/:id/edit',
        component: ReaderUpdateComponent,
        resolve: {
            reader: ReaderResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdReader.home.title'
        },
        canActivate: [UserRouteAccessService]
    }
];

export const readerPopupRoute: Routes = [
    {
        path: 'reader/:id/delete',
        component: ReaderDeletePopupComponent,
        resolve: {
            reader: ReaderResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdReader.home.title'
        },
        canActivate: [UserRouteAccessService],
        outlet: 'popup'
    }
];
