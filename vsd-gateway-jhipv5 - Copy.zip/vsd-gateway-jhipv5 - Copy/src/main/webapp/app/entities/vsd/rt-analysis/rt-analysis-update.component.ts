import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { JhiAlertService } from 'ng-jhipster';

import { IRtAnalysis } from 'app/shared/model/vsd/rt-analysis.model';
import { RtAnalysisService } from './rt-analysis.service';
import { IReaderNumber } from 'app/shared/model/vsd/reader-number.model';
import { ReaderNumberService } from 'app/entities/vsd/reader-number';

@Component({
    selector: 'jhi-rt-analysis-update',
    templateUrl: './rt-analysis-update.component.html'
})
export class RtAnalysisUpdateComponent implements OnInit {
    rtAnalysis: IRtAnalysis;
    isSaving: boolean;

    readernumbers: IReaderNumber[];

    constructor(
        private jhiAlertService: JhiAlertService,
        private rtAnalysisService: RtAnalysisService,
        private readerNumberService: ReaderNumberService,
        private activatedRoute: ActivatedRoute
    ) {}

    ngOnInit() {
        this.isSaving = false;
        this.activatedRoute.data.subscribe(({ rtAnalysis }) => {
            this.rtAnalysis = rtAnalysis;
        });
        this.readerNumberService.query().subscribe(
            (res: HttpResponse<IReaderNumber[]>) => {
                this.readernumbers = res.body;
            },
            (res: HttpErrorResponse) => this.onError(res.message)
        );
    }

    previousState() {
        window.history.back();
    }

    save() {
        this.isSaving = true;
        if (this.rtAnalysis.id !== undefined) {
            this.subscribeToSaveResponse(this.rtAnalysisService.update(this.rtAnalysis));
        } else {
            this.subscribeToSaveResponse(this.rtAnalysisService.create(this.rtAnalysis));
        }
    }

    private subscribeToSaveResponse(result: Observable<HttpResponse<IRtAnalysis>>) {
        result.subscribe((res: HttpResponse<IRtAnalysis>) => this.onSaveSuccess(), (res: HttpErrorResponse) => this.onSaveError());
    }

    private onSaveSuccess() {
        this.isSaving = false;
        this.previousState();
    }

    private onSaveError() {
        this.isSaving = false;
    }

    private onError(errorMessage: string) {
        this.jhiAlertService.error(errorMessage, null, null);
    }

    trackReaderNumberById(index: number, item: IReaderNumber) {
        return item.id;
    }
}
