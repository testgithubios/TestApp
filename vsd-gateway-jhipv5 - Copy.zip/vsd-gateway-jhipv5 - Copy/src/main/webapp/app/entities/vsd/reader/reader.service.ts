import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

import { SERVER_API_URL } from 'app/app.constants';
import { createRequestOption } from 'app/shared';
import { IReader } from 'app/shared/model/vsd/reader.model';

type EntityResponseType = HttpResponse<IReader>;
type EntityArrayResponseType = HttpResponse<IReader[]>;

@Injectable({ providedIn: 'root' })
export class ReaderService {
    public resourceUrl = SERVER_API_URL + 'vsd/api/readers';
    public resourceSearchUrl = SERVER_API_URL + 'vsd/api/_search/readers';

    constructor(private http: HttpClient) {}

    create(reader: IReader): Observable<EntityResponseType> {
        return this.http.post<IReader>(this.resourceUrl, reader, { observe: 'response' });
    }

    update(reader: IReader): Observable<EntityResponseType> {
        return this.http.put<IReader>(this.resourceUrl, reader, { observe: 'response' });
    }

    find(id: number): Observable<EntityResponseType> {
        return this.http.get<IReader>(`${this.resourceUrl}/${id}`, { observe: 'response' });
    }

    query(req?: any): Observable<EntityArrayResponseType> {
        const options = createRequestOption(req);
        return this.http.get<IReader[]>(this.resourceUrl, { params: options, observe: 'response' });
    }

    delete(id: number): Observable<HttpResponse<any>> {
        return this.http.delete<any>(`${this.resourceUrl}/${id}`, { observe: 'response' });
    }

    search(req?: any): Observable<EntityArrayResponseType> {
        const options = createRequestOption(req);
        return this.http.get<IReader[]>(this.resourceSearchUrl, { params: options, observe: 'response' });
    }
}
