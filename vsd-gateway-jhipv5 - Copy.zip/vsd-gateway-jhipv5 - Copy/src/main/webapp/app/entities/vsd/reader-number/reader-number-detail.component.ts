import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { IReaderNumber } from 'app/shared/model/vsd/reader-number.model';

@Component({
    selector: 'jhi-reader-number-detail',
    templateUrl: './reader-number-detail.component.html'
})
export class ReaderNumberDetailComponent implements OnInit {
    readerNumber: IReaderNumber;

    constructor(private activatedRoute: ActivatedRoute) {}

    ngOnInit() {
        this.activatedRoute.data.subscribe(({ readerNumber }) => {
            this.readerNumber = readerNumber;
        });
    }

    previousState() {
        window.history.back();
    }
}
