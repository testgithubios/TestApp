import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { VsdGatewayLineModule as VsdLineModule } from './vsd/line/line.module';
import { VsdGatewayKpiViewModule as VsdKpiViewModule } from './vsd/kpi-view/kpi-view.module';
import { VsdGatewayPartNumberTranslatorModule as VsdPartNumberTranslatorModule } from './vsd/part-number-translator/part-number-translator.module';
import { VsdGatewayProductFamilyModule as VsdProductFamilyModule } from './vsd/product-family/product-family.module';
import { VsdGatewayUserSettingModule as VsdUserSettingModule } from './vsd/user-setting/user-setting.module';
import { VsdGatewayPlantModule as VsdPlantModule } from './vsd/plant/plant.module';
import { VsdGatewayValueStreamModule as VsdValueStreamModule } from './vsd/value-stream/value-stream.module';
import { VsdGatewayValueStreamTagModule as VsdValueStreamTagModule } from './vsd/value-stream-tag/value-stream-tag.module';
import { VsdGatewayLeadTimeLinkModule as VsdLeadTimeLinkModule } from './vsd/lead-time-link/lead-time-link.module';
import { VsdGatewayTagFeatureModule as VsdTagFeatureModule } from './vsd/tag-feature/tag-feature.module';
import { VsdGatewayReaderModule as VsdReaderModule } from './vsd/reader/reader.module';
import { VsdGatewayEmailModule as VsdEmailModule } from './vsd/email/email.module';
import { VsdGatewayReaderNumberModule as VsdReaderNumberModule } from './vsd/reader-number/reader-number.module';
import { VsdGatewayValueStreamElementLinkModule as VsdValueStreamElementLinkModule } from './vsd/value-stream-element-link/value-stream-element-link.module';
import { VsdGatewayValueStreamElementModule as VsdValueStreamElementModule } from './vsd/value-stream-element/value-stream-element.module';
import { VsdGatewayRtAnalysisModule as VsdRtAnalysisModule } from './vsd/rt-analysis/rt-analysis.module';
import { VsdGatewayFeatureStatusModule as VsdFeatureStatusModule } from './vsd/feature-status/feature-status.module';
import { VsdGatewayMatBookingCacheModule as VsdMatBookingCacheModule } from './vsd/mat-booking-cache/mat-booking-cache.module';
/* jhipster-needle-add-entity-module-import - JHipster will add entity modules imports here */

@NgModule({
    // prettier-ignore
    imports: [
        VsdLineModule,
        VsdKpiViewModule,
        VsdPartNumberTranslatorModule,
        VsdProductFamilyModule,
        VsdUserSettingModule,
        VsdPlantModule,
        VsdValueStreamModule,
        VsdValueStreamTagModule,
        VsdLeadTimeLinkModule,
        VsdTagFeatureModule,
        VsdReaderModule,
        VsdEmailModule,
        VsdReaderNumberModule,
        VsdValueStreamElementLinkModule,
        VsdValueStreamElementModule,
        VsdRtAnalysisModule,
        VsdFeatureStatusModule,
        VsdMatBookingCacheModule,
        /* jhipster-needle-add-entity-module - JHipster will add entity modules here */
    ],
    declarations: [],
    entryComponents: [],
    providers: [],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class VsdGatewayEntityModule {}
