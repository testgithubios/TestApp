import { MatSliderModule, MatSlideToggleModule, MatTableModule, MatSortModule, MatInputModule } from '@angular/material';
import { NgModule } from '@angular/core';
import { CdkTableModule } from '@angular/cdk/table';
import { MatAutocompleteModule } from '@angular/material/autocomplete';

@NgModule({
    exports: [CdkTableModule, MatSliderModule, MatSlideToggleModule, MatTableModule, MatSortModule, MatInputModule, MatAutocompleteModule]
})
export class ReaderMonitorMaterial {}
