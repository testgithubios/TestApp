import { VsDashboardService } from './../vs-dashboard/vs-dashboard.service';
import { VsDashboardTagService } from './../vs-dashboard-tag/vs-dashboard-tag.service';
import { ChangeDetectorRef, Component, OnInit, ViewEncapsulation, Input, EventEmitter, Output } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AbstractControl, FormArray, FormBuilder, FormControl, FormGroup, ValidationErrors, ValidatorFn } from '@angular/forms';
import { JhiAlertService, JhiEventManager } from 'ng-jhipster';
import { ReaderMonitorService } from './reader-monitor.service';
import { VsDashboardTag, IVsDashboardTag } from '../vs-dashboard-tag';
import { Subscription, Observable } from 'rxjs';
import { VsTagFeature } from '../vs-tag-feature';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { IVsReader } from 'app/customized/reader-monitor/reader-monitor.model';
import { READER_FEATURE } from 'app/shared/constants/featurelink.constants';
import { ReaderNumber } from 'app/shared/model/vsd/reader-number.model';
import { Email } from 'app/shared/model/vsd/email.model';
import { debounceTime } from 'rxjs/operators';
import { NON_ELEMENTS, NON_LINKS, LOAD_FEATURES, EAGER_LOAD } from 'app/shared/constants/common.constants';
import { AccountService } from 'app/core/auth/account.service';

@Component({
    selector: 'jhi-reader-monitor',
    templateUrl: './reader-monitor.component.html',
    styleUrls: ['reader-monitor.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class ReaderMonitorComponent implements OnInit {
    valueStreamTag: VsDashboardTag;
    readerMonitorForm: FormGroup;
    private readerNrFA = 'readerNumbers'; // Reader number FormArrayName
    auto: any; // This is a fake variable to remove jhipster warning
    reader: IVsReader;
    private defaultReaderNrs = 3;
    private readerPrefix = 'urn:epc:id:sgln:4054972100004.';
    readerNrItems: any;
    private subscriptions: Subscription[] = [];
    userEmailStr: string;
    userEmail = new Email();
    untouchedSlider = true;

    @Input()
    data: any;
    isSaving: boolean;

    @Output()
    readerMonitorStatus = new EventEmitter<string>();
    constructor(
        private eventManager: JhiEventManager,
        private activatedRoute: ActivatedRoute,
        private formBuilder: FormBuilder,
        private jhiAlertService: JhiAlertService,
        private readerMonitorService: ReaderMonitorService,
        private vsDashboardService: VsDashboardService,
        private vsDashboardTagService: VsDashboardTagService,
        private cd: ChangeDetectorRef,
        private accountService: AccountService
    ) {
        this.readerMonitorForm = this.formBuilder.group({
            readerNumbers: this.formBuilder.array([]),
            emails: this.formBuilder.array([])
        });
        this.isSaving = false;
    }

    ngOnInit() {
        this.loadValueStreamTag(this.data.tagId);
    }

    loadValueStreamTag(valueStreamTagId) {
        // Fetch Features
        this.vsDashboardTagService.findOne(valueStreamTagId, NON_ELEMENTS, NON_LINKS, LOAD_FEATURES).subscribe(
            (res: HttpResponse<IVsDashboardTag>) => {
                const valueStreamTag = res.body;
                const readerFeature = valueStreamTag.tagFeatures
                    ? valueStreamTag.tagFeatures.find((f: VsTagFeature) => f.featureLink === READER_FEATURE)
                    : null;
                if (readerFeature) {
                    this.valueStreamTag = valueStreamTag;
                    this.loadReader((readerFeature as VsTagFeature).featureId);
                } else {
                    this.onErrorLoadingPage('error.url.not.found');
                }
            },
            (res: HttpErrorResponse) => {
                this.onErrorLoadingPage('error.url.not.found');
            }
        );
    }

    loadReader(readerId) {
        this.readerMonitorService.find(readerId, true).subscribe(
            (res: HttpResponse<IVsReader>) => {
                this.reader = res.body;

                this.loadReaderNumbers(this.reader.readerNumbers);
                // only process current user email
                this.accountService
                    .get()
                    .toPromise()
                    .then(response => {
                        this.userEmailStr = response.body.email;
                        const emails = this.reader.emails;
                        if (emails) {
                            let userEmailDB = emails.find(v => v.email === this.userEmailStr);
                            if (!userEmailDB) {
                                userEmailDB = new Email(null, this.userEmailStr, false, this.reader.id);
                            }
                            this.userEmail = userEmailDB;
                        } else {
                            this.userEmail = new Email(null, this.userEmailStr, false, this.reader.id);
                        }
                    });

                this.sendStatusToTagFeatureDialog(this.reader.status);
            },
            (res: HttpErrorResponse) => {
                console.log(res);
            }
        );
    }

    private sendStatusToTagFeatureDialog(status: string) {
        // Send status to the TagFeatureDialog
        this.readerMonitorStatus.emit(status);
    }

    private onErrorLoadingPage(error) {
        this.reader = null;
        this.jhiAlertService.error(error, null, null);
    }

    changeDetector() {
        // unsubscribe
        for (let i = 0; i < this.subscriptions.length; i++) {
            this.subscriptions[i].unsubscribe();
        }
        this.subscriptions = [];
        // re-subscribe
        const readerNumberCtrls = this.getFormArray(this.readerNrFA).controls;
        for (let i = 0; i < readerNumberCtrls.length; i++) {
            const subscription = readerNumberCtrls[i].valueChanges
                .pipe(
                    debounceTime(500)
                    // filter(value => value.readerNumber)
                )
                .subscribe((value: any) => {
                    if (value) {
                        this.readerMonitorService.searchMatchingReaderNr(value.trim()).subscribe(
                            (res: HttpResponse<string[]>) => {
                                this.readerNrItems[i] = res.body.map(rn => {
                                    // Prefix of readernumber is hidden from users
                                    if (rn.includes('.')) {
                                        return rn.split('.')[1];
                                    }
                                });
                            },
                            (res: HttpErrorResponse) => {
                                this.readerNrItems[i] = [];
                            }
                        );
                    }
                });
            this.subscriptions.push(subscription);
        }

        this.cd.detectChanges();
    }

    getFormArray(formArrayName) {
        return this.readerMonitorForm.get(formArrayName) as FormArray;
    }

    // Get indicies of all duplicated values
    getDuplicates(objArray: any[]) {
        const duplicates = {};
        for (let i = 0; i < objArray.length; i++) {
            if (duplicates.hasOwnProperty(objArray[i])) {
                duplicates[objArray[i]].push(i);
            } else if (objArray[i] && objArray.lastIndexOf(objArray[i]) !== i) {
                duplicates[objArray[i]] = [i];
            }
        }
        const indices = [];
        Object.keys(duplicates).map(key => {
            indices.push(...duplicates[key]);
            return key;
        });
        return indices;
    }

    validateReaderNrArray(): ValidatorFn {
        return (c: AbstractControl): ValidationErrors | null => {
            // Reset error all controls before checking
            (c as FormArray).controls.forEach(ctrol => ctrol.setErrors(null));
            const dupValuesIdx = this.getDuplicates(c.value);
            dupValuesIdx.forEach(idx => {
                (c as FormArray).controls[idx].setErrors({ readerNrExists: true });
            });
            return dupValuesIdx.length > 0 ? { readerNrExists: true } : null;
        };
    }

    loadReaderNumbers(readerNumbers) {
        if (readerNumbers && readerNumbers.length > 0) {
            readerNumbers.forEach((readerNr, index) => {
                // Prefix of readernumber is hidden from users
                if (readerNr.readerNumber && readerNr.readerNumber.includes('.')) {
                    const readerNumber = readerNr.readerNumber.split('.')[1];
                    this.getFormArray(this.readerNrFA).push(new FormControl(readerNumber));
                }
            });
            if (readerNumbers.length < this.defaultReaderNrs) {
                for (let i = 0; i < this.defaultReaderNrs - readerNumbers.length; i++) {
                    this.getFormArray(this.readerNrFA).push(new FormControl(null));
                }
            }
        } else {
            this.readerMonitorForm.controls[this.readerNrFA] = new FormArray([
                new FormControl(null),
                new FormControl(null),
                new FormControl(null)
            ]);
        }
        this.readerMonitorForm.controls[this.readerNrFA].setValidators(this.validateReaderNrArray());
        this.readerNrItems = [[], [], []];
        this.changeDetector();
    }

    saveReader(reader) {
        this.isSaving = true;
        if (reader.id !== undefined) {
            this.subscribeToSaveResponse(this.readerMonitorService.updateReaderMonitor(reader));
        } else {
            console.log('READER WAS NOT CREATED');
        }
    }

    private subscribeToSaveResponse(result: Observable<any>) {
        result.subscribe(
            (res: any) => {
                // reload reader after saving to get status after update
                this.readerMonitorService.find(this.reader.id, EAGER_LOAD).subscribe((resReader: HttpResponse<IVsReader>) => {
                    this.reader = resReader.body;
                    this.sendStatusToTagFeatureDialog(this.reader.status);
                });
                this.isSaving = false;
                // Reload value-stream detail to see status updated
                this.eventManager.broadcast({ name: 'vsDashboardDetailModification', content: 'OK' });
            },
            (res: HttpErrorResponse) => {
                this.isSaving = false;
                this.onErrorReader(res.headers.get('x-vsdapp-error'), res.headers.get('x-vsdapp-params'));
                this.readerMonitorService.find(this.reader.id, EAGER_LOAD).subscribe((resReader: HttpResponse<IVsReader>) => {
                    this.reader = resReader.body;
                });
            }
        );
    }

    private onErrorReader(error, params) {
        this.jhiAlertService.error(error, { readerNrs: params }, null);
    }

    save() {
        const readerNumberDB: ReaderNumber[] = this.reader.readerNumbers;
        const readerNumberArr: string[] = this.getFormArray(this.readerNrFA).value.filter(x => x != null && x !== '');
        const newReaderNumbers: ReaderNumber[] = [];

        readerNumberArr.forEach(readerNumberStr => {
            const readerNumber = new ReaderNumber();
            // if the readerNumber is already in reader.readerNumber list then we keep it's id
            const data = readerNumberDB
                ? readerNumberDB.find(i => i.readerNumber.toLowerCase() === this.readerPrefix + readerNumberStr.toLowerCase())
                : null;
            readerNumber.id = data && data.id ? data.id : null;
            readerNumber.readerNumber = this.readerPrefix + readerNumberStr;
            newReaderNumbers.push(readerNumber);
        });
        this.reader.readerNumbers = newReaderNumbers;

        let emails = this.reader.emails;
        if (emails) {
            const userEmailDB = emails.find(v => v.email === this.userEmailStr);
            if (!userEmailDB) {
                emails.push(this.userEmail);
            } else {
                userEmailDB.activateScheduler = this.userEmail.activateScheduler;
            }
        } else {
            emails = [];
            emails.push(this.userEmail);
        }

        this.saveReader(this.reader);
    }

    addReaderNr() {
        this.readerNrItems.push([]);
        this.getFormArray(this.readerNrFA).push(new FormControl(null));
        this.changeDetector();
    }

    deleteReaderNr() {
        const length = (this.readerMonitorForm.controls[this.readerNrFA] as FormArray).length;
        if (length > 0) {
            this.getFormArray(this.readerNrFA).removeAt(length - 1);
            this.changeDetector();
            this.readerNrItems.pop();
        }
    }

    clear() {
        const length = this.getFormArray(this.readerNrFA).controls.length;
        for (let i = length; i > this.reader.readerNumbers.length; i--) {
            if (i > this.defaultReaderNrs) {
                this.getFormArray(this.readerNrFA).removeAt(i - 1);
            } else {
                this.getFormArray(this.readerNrFA)
                    .get((i - 1).toString())
                    .setValue(null);
            }
        }
    }

    toggle() {
        this.untouchedSlider = false;
        this.userEmail.activateScheduler = !this.userEmail.activateScheduler;
        if (this.userEmail.activateScheduler) {
            this.save();
        }
    }
}
