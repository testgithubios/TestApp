import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

import { SERVER_API_URL } from 'app/app.constants';
import { createRequestOption } from 'app/shared';
import { IVsReader } from 'app/customized/reader-monitor/reader-monitor.model';
import { map } from 'rxjs/operators';

type EntityResponseType = HttpResponse<IVsReader>;
type EntityArrayResponseType = HttpResponse<IVsReader[]>;

@Injectable()
export class ReaderMonitorService {
    private resourceUrl = SERVER_API_URL + 'vsd/api/readers';
    private resourceRFID = SERVER_API_URL + 'vsd/api/readerMonitor';
    private resourceSearchUrl = SERVER_API_URL + 'vsd/api/_search/reader-number-string';

    constructor(private http: HttpClient) {}

    create(reader: IVsReader): Observable<EntityResponseType> {
        return this.http.post<IVsReader>(this.resourceUrl, reader, { observe: 'response' });
    }

    updateReaderMonitor(reader: IVsReader): Observable<any> {
        return this.http.put<any>(this.resourceRFID, reader, { observe: 'response' });
    }

    find(id: number, eagerload?: boolean): Observable<EntityResponseType> {
        const options = createRequestOption({ eagerload });
        return this.http.get<IVsReader>(`${this.resourceUrl}/${id}`, { params: options, observe: 'response' });
    }

    searchMatchingReaderNr(queryReaderNr?: any): Observable<HttpResponse<string[]>> {
        const options = createRequestOption({ queryReaderNr: [queryReaderNr.toString().toUpperCase()] });
        return this.http.get<string[]>(this.resourceSearchUrl, { params: options, observe: 'response' });
    }
}
