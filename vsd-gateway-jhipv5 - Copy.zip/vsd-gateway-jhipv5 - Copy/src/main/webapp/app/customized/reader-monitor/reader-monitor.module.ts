import { NgModule } from '@angular/core';
import { ReaderMonitorMaterial } from './reader-monitor.material.module';
import { ReaderMonitorComponent } from './reader-monitor.component';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ReaderMonitorService } from './reader-monitor.service';
import { NgSelectModule } from '@ng-select/ng-select';

@NgModule({
    imports: [ReaderMonitorMaterial, RouterModule, CommonModule, FormsModule, ReactiveFormsModule, NgSelectModule],
    declarations: [ReaderMonitorComponent],
    entryComponents: [ReaderMonitorComponent],
    providers: [ReaderMonitorService]
})
export class ReaderMonitorModule {}
