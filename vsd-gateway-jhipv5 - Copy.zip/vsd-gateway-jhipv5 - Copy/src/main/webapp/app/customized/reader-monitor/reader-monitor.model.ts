import { IEmail } from 'app/shared/model/vsd/email.model';
import { IReaderNumber } from 'app/shared/model/vsd/reader-number.model';

export interface IVsReader {
    id?: number;
    emails?: IEmail[];
    readerNumbers?: IReaderNumber[];
    status?: string;
}

export class VsReader implements IVsReader {
    constructor(public id?: number, public emails?: IEmail[], public readerNumbers?: IReaderNumber[], public status?: string) {}
}
