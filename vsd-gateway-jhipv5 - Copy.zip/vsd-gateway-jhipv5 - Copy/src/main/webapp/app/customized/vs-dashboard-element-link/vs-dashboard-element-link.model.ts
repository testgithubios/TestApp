import { IVsDashboardElement } from '../vs-dashboard-element/vs-dashboard-element.model';

export interface IValueStreamElementLink {
    id?: number;
    featureLink?: string;
    featureName?: string;
    valueStreamElements?: IVsDashboardElement[];
}

export class VsDashboardElementLink implements IValueStreamElementLink {
    constructor(
        public id?: number,
        public featureLink?: string,
        public featureName?: string,
        public valueStreamElements?: IVsDashboardElement[]
    ) {}
}
