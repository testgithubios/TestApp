import { Component, OnDestroy, OnInit, ViewEncapsulation, Output, EventEmitter, Input } from '@angular/core';
import { VsRtAnalysisService } from './vs-rt-analysis.service';
import { AbstractControl, FormArray, FormBuilder, FormGroup, ValidationErrors, ValidatorFn, Validators, FormControl } from '@angular/forms';
import { ReaderMonitorService } from '../reader-monitor/reader-monitor.service';
import { debounceTime, distinctUntilChanged, switchMap, map } from 'rxjs/operators';
import { VsRtAnalysisDetail, IVsRtAnalysis, VsRtAnalysis } from './vs-rt-analysis.model';
import { HttpResponse } from '@angular/common/http';
import { of, Subscription } from 'rxjs';
import { READER_NUMBER_PREFIX } from 'app/shared/constants/common.constants';
import { JhiEventManager } from 'ng-jhipster';
import { VsRtDataService } from 'app/customized/vs-rt-analysis/vs-rt-analysis-data-service';

@Component({
    selector: 'jhi-vs-rt-analysis',
    templateUrl: 'vs-rt-analysis.component.html',
    styleUrls: ['vs-rt-analysis.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class VsRtAnalysisComponent implements OnInit, OnDestroy {
    private eventSubscriber: Subscription;
    public rtForm: FormGroup;
    public rtRows: FormArray;
    private listOfRtAnalysis: IVsRtAnalysis[] = [];
    public rnStartOptions: String[][] = [];
    public rnEndOptions: String[][] = [];
    private stSubcriptions: Subscription[] = [];
    private edSubcriptions: Subscription[] = [];
    private readerPrefix = READER_NUMBER_PREFIX;
    public isSaving = false;
    public showFilterFlag = false;
    public showDetailFlag = false;
    public vsRtAnalysisDetailArr: VsRtAnalysisDetail[] = [];
    public vsRtAnalysisDetail: VsRtAnalysisDetail = {};
    public chosenIndex = null;

    @Output()
    viewRTDetail = new EventEmitter<VsRtAnalysisDetail[]>();

    @Input()
    data;

    private subscription: Subscription;
    constructor(
        private vsRtAnalysisService: VsRtAnalysisService,
        private readerMonitorService: ReaderMonitorService,
        private fb: FormBuilder,
        private eventManager: JhiEventManager,
        private vsRtDataService: VsRtDataService
    ) {}

    loadAllRtAnalysis() {
        this.rtRows.controls = []; // empty all controls before getting data
        // Get all rtAnalysis by tag id
        this.vsRtAnalysisService.query({ tagId: this.data.tagId }).subscribe((res: HttpResponse<IVsRtAnalysis[]>) => {
            this.listOfRtAnalysis = res.body;

            if (res.body.length > 0) {
                for (let i = 0; i < res.body.length; i++) {
                    this.addRow(res.body[i]);
                }
            } else {
                this.addRow(null);
            }
        });
    }

    ngOnInit() {
        // assign form structure
        this.rtForm = this.fb.group({
            rtRows: this.fb.array([], this.duplicatedRow())
        });

        this.rtRows = this.rtForm.get('rtRows') as FormArray;
        this.loadAllRtAnalysis();
        this.registerSaveFilterEvt();
    }

    addRow(record?: VsRtAnalysis): void {
        record = record ? record : {};
        this.rtRows.push(this.createRow(record));
        this.subscribeRow(this.rtRows.controls.length - 1);
    }

    createRow(record: VsRtAnalysis): FormGroup {
        if (record) {
            const stReader: string = record.startReaderNumberReaderNumber ? record.startReaderNumberReaderNumber : '';
            const edReader: string = record.endReaderNumberReaderNumber ? record.endReaderNumberReaderNumber : '';
            return this.fb.group(
                {
                    description: [record.description, [Validators.required]],
                    startReaderNumber: [stReader.substring(this.readerPrefix.length), [Validators.required]],
                    endReaderNumber: [edReader.substring(this.readerPrefix.length), [Validators.required]],
                    filter: [record.filter]
                },
                {
                    validator: [this.startEndTheSame()]
                }
            );
        } else {
            return this.fb.group(
                {
                    description: ['', [Validators.required]],
                    startReaderNumber: ['', [Validators.required]],
                    endReaderNumber: ['', [Validators.required]],
                    filter: [record.filter]
                },
                {
                    validator: [this.startEndTheSame()]
                }
            );
        }
    }

    addAt(i) {
        (this.rtRows as FormArray).insert(i + 1, this.createRow({}));
        this.subscribeRow(i + 1);
    }

    deleteAt(i) {
        (this.rtRows as FormArray).removeAt(i);
    }

    subscribeRow(index: number) {
        const group = this.rtRows.controls[index];
        const stReader = group.get('startReaderNumber');
        this.stSubcriptions[index] = stReader.valueChanges
            .pipe(
                distinctUntilChanged(),
                debounceTime(500),
                switchMap(term => {
                    return term && term.trim()
                        ? this.readerMonitorService.searchMatchingReaderNr(term).pipe(map(res => res.body.map(rn => rn.split('.')[1])))
                        : of([]);
                })
            )
            .subscribe(value => {
                this.rnStartOptions[index] = value;
            });

        const edReader = group.get('endReaderNumber');
        this.edSubcriptions[index] = edReader.valueChanges
            .pipe(
                distinctUntilChanged(),
                debounceTime(500),
                switchMap(term => {
                    return term && term.trim()
                        ? this.readerMonitorService.searchMatchingReaderNr(term).pipe(map(res => res.body.map(rn => rn.split('.')[1])))
                        : of([]);
                })
            )
            .subscribe(value => {
                this.rnEndOptions[index] = value;
            });
    }

    ngOnDestroy() {
        this.stSubcriptions.forEach(value => {
            if (value) {
                value.unsubscribe();
            }
        });
        this.edSubcriptions.forEach(value => {
            if (value) {
                value.unsubscribe();
            }
        });
        this.subscription.unsubscribe();
    }

    startEndTheSame(): ValidatorFn {
        return (c: AbstractControl): ValidationErrors | null => {
            if (
                !c.get('startReaderNumber').value ||
                !c
                    .get('startReaderNumber')
                    .value.toString()
                    .trim()
            ) {
                return null;
            }
            return c.get('startReaderNumber').value === c.get('endReaderNumber').value ? { sameReaderNumberError: true } : null;
        };
    }

    duplicatedRow(): ValidatorFn {
        return (c: AbstractControl): ValidationErrors | null => {
            if (!this.rtRows) {
                return null;
            }
            for (let i = 0; i < this.rtRows.controls.length - 1; i++) {
                const group1 = this.rtRows.controls[i];
                if (
                    !group1.get('startReaderNumber').value ||
                    !group1
                        .get('startReaderNumber')
                        .value.toString()
                        .trim()
                ) {
                    continue;
                }
                if (
                    !group1.get('endReaderNumber').value ||
                    !group1
                        .get('endReaderNumber')
                        .value.toString()
                        .trim()
                ) {
                    continue;
                }
                let found = false;
                for (let j = i + 1; j < this.rtRows.controls.length; j++) {
                    const group2 = this.rtRows.controls[j];
                    if (
                        !group2.get('startReaderNumber').value ||
                        !group2
                            .get('startReaderNumber')
                            .value.toString()
                            .trim()
                    ) {
                        continue;
                    }
                    if (
                        !group2.get('endReaderNumber').value ||
                        !group2
                            .get('endReaderNumber')
                            .value.toString()
                            .trim()
                    ) {
                        continue;
                    }
                    if (
                        group1.get('startReaderNumber').value === group2.get('startReaderNumber').value &&
                        group1.get('endReaderNumber').value === group2.get('endReaderNumber').value
                    ) {
                        found = true;
                        break;
                    }
                }
                if (found) {
                    return { duplicatedRowError: true };
                }
            }
            return null;
        };
    }

    save() {
        this.isSaving = true;

        // prepare data
        const arrayToSave = [];
        this.rtRows.controls.forEach(group => {
            const vsRtAnalysis = new VsRtAnalysis();

            vsRtAnalysis.description = group.get('description').value;
            vsRtAnalysis.startReaderNumberReaderNumber =
                this.readerPrefix +
                group
                    .get('startReaderNumber')
                    .value.toString()
                    .toUpperCase();
            vsRtAnalysis.endReaderNumberReaderNumber =
                this.readerPrefix +
                group
                    .get('endReaderNumber')
                    .value.toString()
                    .toUpperCase();

            arrayToSave.push(vsRtAnalysis);
        });

        this.vsRtAnalysisService.saveListByTagId(arrayToSave, this.data.tagId).subscribe(res => {
            this.isSaving = false;
        });
    }

    clear() {
        this.rtForm.reset();
        for (let i = 0; i < this.rtRows.controls.length; i++) {
            this.rnStartOptions[i] = [];
            this.rnEndOptions[i] = [];
        }
    }

    isOkToNavigate(index): boolean {
        const startVal = this.rtRows.controls[index].get('startReaderNumber').value;
        if (!startVal || !startVal.toString().trim()) {
            return false;
        }
        const endVal = this.rtRows.controls[index].get('endReaderNumber').value;
        if (!endVal || !endVal.toString().trim()) {
            return false;
        }
        if (startVal === endVal) {
            return false;
        }
        return true;
    }

    showDetail(index) {
        this.showDetailFlag = true;
        this.showFilterFlag = false;
        // Remove all the empty readerNumber before sending to detail page
        const vsRtAnalysisDetailArr: VsRtAnalysisDetail[] = this.rtRows.value.map((item: any, idx) => ({ ...item, chosen: idx === index }));
        this.vsRtAnalysisDetailArr = vsRtAnalysisDetailArr.filter(
            (i: VsRtAnalysisDetail) =>
                i.startReaderNumber && i.startReaderNumber.trim() !== '' && i.endReaderNumber && i.endReaderNumber.trim() !== ''
        );

        this.vsRtDataService.sendDataArray(this.vsRtAnalysisDetailArr);
    }

    hideDetail() {
        this.chosenIndex = null;
        this.showDetailFlag = false;
        this.showFilterFlag = false;
    }

    showFilterAt(index: number) {
        this.showFilterFlag = true;
        this.chosenIndex = index;
        this.vsRtAnalysisDetail = { ...this.rtRows.value[index] };
        this.vsRtDataService.sendData(this.vsRtAnalysisDetail);
    }

    showFilterFromRtDetail(event) {
        this.showFilterFlag = true;
        const updatedRow = this.rtRows.value.find(
            item => item.startReaderNumber === event.startReaderNumber && item.endReaderNumber === event.endReaderNumber
        );
        this.vsRtAnalysisDetail = Object.assign(
            {},
            { startReaderNumber: event.startReaderNumber, endReaderNumber: event.endReaderNumber, filter: updatedRow.filter }
        );
        this.vsRtDataService.sendData(this.vsRtAnalysisDetail);
    }

    hideFilter() {
        this.showFilterFlag = false;
    }

    registerSaveFilterEvt() {
        this.subscription = this.vsRtDataService.saveFilterStream$.subscribe((res: VsRtAnalysisDetail) => {
            const rtAnalysis = this.listOfRtAnalysis.find(
                rt =>
                    rt.startReaderNumberReaderNumber === this.readerPrefix + res.startReaderNumber &&
                    rt.endReaderNumberReaderNumber === this.readerPrefix + res.endReaderNumber
            );

            if (rtAnalysis) {
                rtAnalysis.filter = res.filter;
                this.vsRtAnalysisService.update(rtAnalysis).subscribe(rtAnalysisRes => {
                    this.loadAllRtAnalysis();
                });
            }
        });
    }
}
