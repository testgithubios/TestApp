import { IReaderNumber } from 'app/shared/model/vsd/reader-number.model';

export interface IVsRtAnalysis {
    id?: number;
    description?: string;
    startReaderNumberReaderNumber?: string;
    startReaderNumberId?: number;
    endReaderNumberReaderNumber?: string;
    endReaderNumberId?: number;
    filter?: string;
}

export class VsRtAnalysis implements IVsRtAnalysis {
    constructor(
        public id?: number,
        public description?: string,
        public startReaderNumberReaderNumber?: string,
        public startReaderNumberId?: number,
        public endReaderNumberReaderNumber?: string,
        public endReaderNumberId?: number,
        public filter?: string
    ) {}
}
export class VsRtAnalysisDetail {
    constructor(
        public description?: string,
        public startReaderNumber?: string,
        public endReaderNumber?: string,
        public chosen?: boolean,
        public filter?: string
    ) {}
}

export class VsRtData {
    constructor(
        public kanbanKey?: string,
        public startEvtTime?: number,
        public endEvtTime?: number,
        public gap?: number,
        public materialNumber?: string
    ) {}
}
