import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { VsRtAnalysisComponent, VsRtAnalysisDetailComponent, vsRtAnalysisRoute, VsRtAnalysisService } from './';
import {
    MatInputModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatAutocompleteModule,
    MatCheckboxModule,
    MatChipsModule,
    MatIconModule
} from '@angular/material';
import { VsdGatewaySharedModule } from 'app/shared';
import { VsRtAnalysisFilterComponent } from 'app/customized/vs-rt-analysis/vs-rt-analysis-filter.component';
import { VsRtDataService } from './vs-rt-analysis-data-service';
const ENTITY_STATES = [...vsRtAnalysisRoute];

@NgModule({
    imports: [
        VsdGatewaySharedModule,
        FormsModule,
        ReactiveFormsModule,
        MatSliderModule,
        MatSlideToggleModule,
        MatInputModule,
        MatAutocompleteModule,
        MatCheckboxModule,
        MatChipsModule,
        MatIconModule,
        RouterModule.forRoot(ENTITY_STATES, { useHash: true })
    ],
    declarations: [VsRtAnalysisComponent, VsRtAnalysisDetailComponent, VsRtAnalysisFilterComponent],
    exports: [],
    entryComponents: [VsRtAnalysisComponent, VsRtAnalysisDetailComponent, VsRtAnalysisFilterComponent],
    providers: [VsRtAnalysisService, VsRtDataService],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class VsdGatewayVsRtAnalysisModule {}
