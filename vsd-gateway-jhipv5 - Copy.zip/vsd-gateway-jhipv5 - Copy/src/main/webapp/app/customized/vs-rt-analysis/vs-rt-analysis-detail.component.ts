import {
    Component,
    ElementRef,
    OnInit,
    ViewEncapsulation,
    Input,
    QueryList,
    EventEmitter,
    Output,
    ViewChildren,
    ChangeDetectorRef,
    OnDestroy
} from '@angular/core';
import { VsRtAnalysisService } from './vs-rt-analysis.service';
import * as d3 from 'd3';
import { VsDashboard } from '../vs-dashboard';
import { VsDashboardTag } from '../vs-dashboard-tag';
import { VsRtData, VsRtAnalysisDetail } from './vs-rt-analysis.model';
import { READER_NUMBER_PREFIX } from 'app/shared/constants/common.constants';
import { HttpResponse } from '@angular/common/http';
import { VsRtDataService } from 'app/customized/vs-rt-analysis/vs-rt-analysis-data-service';
import { Subscription } from 'rxjs';

@Component({
    selector: 'jhi-rt-analysis-detail',
    templateUrl: './vs-rt-analysis-detail.component.html',
    styleUrls: ['./vs-rt-analysis-detail.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class VsRtAnalysisDetailComponent implements OnInit, OnDestroy {
    valueStream: VsDashboard = { valueStreamName: 'name', id: 1 };
    tag: VsDashboardTag = { tagName: 'tag name' };
    margin = { top: 10, right: 0, bottom: 5, left: 15 };
    colMinWidth = 29; // width + right padding
    colNumStandard = 30;

    @ViewChildren('chart')
    chartContainers: QueryList<ElementRef>;

    @Output()
    backToRtAnalysisEvt = new EventEmitter<boolean>();

    @Output()
    showFilterEvt = new EventEmitter<VsRtAnalysisDetail>();

    @Output()
    hideFilterEvt = new EventEmitter<boolean>();

    public rtAnalyisArr: VsRtAnalysisDetail[];

    public tableDataObj = {};
    public chartDataObj = {};

    private subscription1: Subscription;
    private subscription2: Subscription;

    constructor(
        private vsRtAnalysisService: VsRtAnalysisService,
        private changeDetector: ChangeDetectorRef, // use this to fix bug when clicking open and close one chart cause *ngIf remove ElementRef from DOM
        private vsRtDataService: VsRtDataService
    ) {
        this.subscription1 = this.vsRtDataService.vsRtDetailArrayStream$.subscribe(res => {
            this.rtAnalyisArr = res;
            const chosenData: VsRtAnalysisDetail = this.rtAnalyisArr.filter(i => i.chosen === true)[0];
            this.createTableAndChartData(this.rtAnalyisArr, chosenData.startReaderNumber, chosenData.endReaderNumber);
        });
    }

    ngOnInit() {
        this.registerSaveFilterEvt();
    }

    ngOnDestroy() {
        this.subscription1.unsubscribe();
        this.subscription2.unsubscribe();
    }

    createTableAndChartData(rtAnalyisArr: VsRtAnalysisDetail[], startReaderNumber: string, endReaderNumber: string) {
        const index = rtAnalyisArr.findIndex(
            item => item.startReaderNumber === startReaderNumber && item.endReaderNumber === endReaderNumber
        );
        if (this.tableDataObj[index]) {
            this.generateChart(index);
        } else {
            this.vsRtAnalysisService
                .getRTDataByReaderNumber(READER_NUMBER_PREFIX + startReaderNumber, READER_NUMBER_PREFIX + endReaderNumber)
                .subscribe((res: HttpResponse<VsRtData[]>) => {
                    let tableData = [];
                    if (rtAnalyisArr[index].filter) {
                        const filterArr = rtAnalyisArr[index].filter.split(',');
                        tableData = res.body.filter((item: VsRtData) => filterArr.includes(item.materialNumber));
                    } else {
                        // Incase filter is empty we get all data
                        tableData = res.body;
                    }
                    this.tableDataObj[index] = tableData;
                    this.changeDetector.detectChanges();
                    this.generateChart(index);
                });
        }
    }

    registerSaveFilterEvt() {
        this.subscription2 = this.vsRtDataService.saveFilterStream$.subscribe((res: VsRtAnalysisDetail) => {
            if (res.startReaderNumber && res.endReaderNumber) {
                const index = this.rtAnalyisArr.findIndex(
                    item => item.startReaderNumber === res.startReaderNumber && item.endReaderNumber === res.endReaderNumber
                );
                this.rtAnalyisArr[index].filter = res.filter;
                this.tableDataObj[index] = null;
                this.createTableAndChartData(this.rtAnalyisArr, res.startReaderNumber, res.endReaderNumber);
            }
        });
    }

    generateChart(index) {
        const tableData = this.tableDataObj[index];
        tableData.sort((a, b) => {
            return +b.gap - +a.gap;
        });
        this.chartDataObj[index] = this.convertTableToChart(tableData);
        if (this.chartDataObj[index].length > 0) {
            this.createChart(index);
        }
    }

    private convertTableToChart(tableData: VsRtData[]): any[] {
        if (tableData.length === 0) {
            return [];
        }
        const cloneArr: any[] = tableData.map((item: VsRtData) => ({ ...item, gap: Math.ceil(item.gap / 60) })); // Prevent reference
        const chartData = [];
        chartData.push({ rt: cloneArr[0].gap, count: 1 });
        cloneArr.shift();
        while (cloneArr.length > 0) {
            const first = cloneArr[0];
            let found = false;
            for (let i = 0; i < chartData.length; i++) {
                if (first.gap === chartData[i].rt) {
                    chartData[i].count++;
                    found = true;
                    break;
                }
            }
            if (!found) {
                chartData.push({ rt: first.gap, count: 1 });
            }
            cloneArr.shift();
        }
        // sort
        return chartData.sort((a, b) => {
            return +a.rt - +b.rt;
        });
    }

    private createChart(index: number): void {
        const currentChartId = '#chart-' + index;
        d3.select(currentChartId + ' > #svg-vs-rt').remove();
        const element = (this.chartContainers.toArray()[index] as ElementRef).nativeElement;
        const data: any[] = this.chartDataObj[index];
        let elementWidth;
        if (data.length > this.colNumStandard) {
            elementWidth = (data.length - this.colNumStandard) * this.colMinWidth + element.offsetWidth;
        } else {
            elementWidth = element.offsetWidth;
        }
        const svg = d3
            .select(element)
            .append('svg')
            .attr('id', 'svg-vs-rt')
            .attr('width', elementWidth)
            .attr('height', element.offsetHeight);

        const labelSize = 20;
        const contentWidth = elementWidth - this.margin.left - this.margin.right - labelSize;
        // for horizontal bar 20px; for lable
        const contentHeight = element.offsetHeight - this.margin.top - this.margin.bottom - 20 - labelSize;

        const x = d3
            .scaleBand()
            .rangeRound([0, contentWidth])
            .padding(0.1)
            .domain(data.map(d => d.rt));

        const y = d3
            .scaleLinear()
            .rangeRound([contentHeight, 0])
            .domain([0, d3.max(data, d => d.count)]);

        const g = svg.append('g').attr('transform', 'translate(' + (this.margin.left + labelSize) + ',' + this.margin.top + ')');

        g.append('g')
            .attr('class', 'axis axis--x')
            .attr('transform', 'translate(0,' + contentHeight + ')')
            .call(d3.axisBottom(x));

        g.append('g')
            .attr('class', 'axis axis--y')
            .call(d3.axisLeft(y));

        const barGroups = g
            .selectAll('.bar')
            .data(data)
            .enter()
            .append('g')
            .on('mouseenter', function(actual, i) {
                d3.select(this)
                    .select('text')
                    .attr('opacity', 1);
                const thisHeight = y(actual.count);
                g.append('line')
                    .attr('id', 'limit')
                    .attr('x1', 0)
                    .attr('y1', thisHeight)
                    .attr('x2', contentWidth)
                    .attr('y2', thisHeight);
            })
            .on('mouseleave', function() {
                d3.select(this)
                    .select('text')
                    .attr('opacity', 0);
                g.selectAll('#limit').remove();
            });

        barGroups
            .append('rect')
            .attr('class', 'bar')
            .attr('x', d => x(d.rt))
            .attr('y', d => y(d.count))
            .attr('width', x.bandwidth())
            .attr('height', d => contentHeight - y(d.count));

        barGroups
            .append('text')
            .text(d => d.count)
            .attr('class', 'val')
            .attr('x', d => x(d.rt) + x.bandwidth() / 2)
            .attr('y', d => y(d.count) - 10)
            .attr('text-anchor', 'middle')
            .attr('opacity', 0);

        svg.append('text')
            .attr('x', -contentHeight / 2 - this.margin.top)
            .attr('y', 10)
            .attr('transform', 'rotate(-90)')
            .attr('text-anchor', 'middle')
            .attr('class', 'label')
            .text('Number of events');

        svg.append('text')
            .attr('x', elementWidth / 2)
            .attr('y', contentHeight + this.margin.bottom + 37)
            .attr('text-anchor', 'middle')
            .attr('class', 'label')
            .text('Time (hours)');
    }

    convertEvtData(val: number): string {
        if (val < 0) {
            return '';
        } else {
            return new Date(val).toUTCString();
        }
    }

    close(index: number) {
        this.rtAnalyisArr[index].chosen = false;
    }

    open(index: number, startReaderNumber: string, endReaderNumber: string) {
        // view only one chart and hide the rest
        this.rtAnalyisArr[index].chosen = true;
        this.changeDetector.detectChanges();
        this.hideFilterEvt.emit(true);
        this.rtAnalyisArr.map((item, idx) => {
            if (idx !== index) {
                item.chosen = false;
            }
            return item;
        });
        this.createTableAndChartData(this.rtAnalyisArr, startReaderNumber, endReaderNumber);
    }

    backToRtAnalysis() {
        this.backToRtAnalysisEvt.emit(true);
    }

    showFilterByStartEnd(startReaderNumber: string, endReaderNumber: string) {
        const filterObj: VsRtAnalysisDetail = Object.assign({}, { startReaderNumber, endReaderNumber });
        this.showFilterEvt.emit(filterObj);
    }
}
