import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

import { SERVER_API_URL } from 'app/app.constants';
import { createRequestOption } from 'app/shared';
import { IVsRtAnalysis, VsRtData } from 'app/customized/vs-rt-analysis';

type EntityResponseType = HttpResponse<IVsRtAnalysis>;
type EntityArrayResponseType = HttpResponse<IVsRtAnalysis[]>;

@Injectable()
export class VsRtAnalysisService {
    public resourceUrl = SERVER_API_URL + 'vsd/api/rt-analyses';
    public resourceSearchUrl = SERVER_API_URL + 'vsd/api/_search/rt-analyses';

    constructor(private http: HttpClient) {}

    create(rtAnalysis: IVsRtAnalysis): Observable<EntityResponseType> {
        return this.http.post<IVsRtAnalysis>(this.resourceUrl, rtAnalysis, { observe: 'response' });
    }

    update(rtAnalysis: IVsRtAnalysis): Observable<EntityResponseType> {
        return this.http.put<IVsRtAnalysis>(this.resourceUrl, rtAnalysis, { observe: 'response' });
    }

    find(id: number): Observable<EntityResponseType> {
        return this.http.get<IVsRtAnalysis>(`${this.resourceUrl}/${id}`, { observe: 'response' });
    }

    saveListByTagId(arrayToSave: IVsRtAnalysis[], tagId: number): Observable<any> {
        const options = createRequestOption({ tagId });
        return this.http.put(this.resourceUrl + '-list', arrayToSave, { params: options, observe: 'response' });
    }

    getRTDataByReaderNumber(start: string, end: string): Observable<HttpResponse<VsRtData[]>> {
        const options = createRequestOption({ start: [start], end: [end] });
        return this.http.get<VsRtData[]>(this.resourceUrl + '/analyze', { params: options, observe: 'response' });
    }

    getMaterialNumberByReader(start: string, end: string): Observable<HttpResponse<string[]>> {
        const options = createRequestOption({ start: [start], end: [end] });
        return this.http.get<string[]>(this.resourceUrl + '/material-number', { params: options, observe: 'response' });
    }

    query(req?: any): Observable<EntityArrayResponseType> {
        const options = createRequestOption(req);
        return this.http.get<IVsRtAnalysis[]>(this.resourceUrl, { params: options, observe: 'response' });
    }

    delete(id: number): Observable<HttpResponse<any>> {
        return this.http.delete<any>(`${this.resourceUrl}/${id}`, { observe: 'response' });
    }

    search(req?: any): Observable<EntityArrayResponseType> {
        const options = createRequestOption(req);
        return this.http.get<IVsRtAnalysis[]>(this.resourceSearchUrl, { params: options, observe: 'response' });
    }
}
