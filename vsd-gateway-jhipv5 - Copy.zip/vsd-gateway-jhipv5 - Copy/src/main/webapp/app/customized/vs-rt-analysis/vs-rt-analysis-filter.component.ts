import { Component, ViewEncapsulation, OnInit, OnDestroy, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, FormArray, FormControl } from '@angular/forms';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { MatChipInputEvent } from '@angular/material';
import { VsRtAnalysisService } from 'app/customized/vs-rt-analysis/vs-rt-analysis.service';
import { READER_NUMBER_PREFIX } from 'app/shared/constants/common.constants';
import { VsRtDataService, VsRtAnalysisDetail } from 'app/customized/vs-rt-analysis';
import { Subscription } from 'rxjs';

@Component({
    selector: 'jhi-vs-rt-analysis-filter',
    templateUrl: 'vs-rt-analysis-filter.component.html',
    styleUrls: ['vs-rt-analysis-filter.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class VsRtAnalysisFilterComponent implements OnInit, OnDestroy {
    private readerPrefix = READER_NUMBER_PREFIX;
    public rtFilterForm: FormGroup;
    public materialData: string[];
    public materialPaste: string[] = [];
    private materialFormArr: FormArray;

    // *************Variable for chips**************
    public visible = true;
    public selectable = true;
    public removable = true;
    public addOnBlur = true;
    public readonly separatorKeysCodes: number[] = [ENTER, COMMA];
    public defaultValue = null;
    // *********************************************

    @Output()
    public hideFilterEvent = new EventEmitter<boolean>();

    public vsRtAnalysisDetail: VsRtAnalysisDetail;

    private subscription: Subscription;

    constructor(private fb: FormBuilder, private vsRtAnalysisService: VsRtAnalysisService, private vsRtDataService: VsRtDataService) {
        this.rtFilterForm = this.fb.group({
            materialBoxes: this.fb.array([]),
            pasteControl: new FormControl()
        });
        this.materialFormArr = this.rtFilterForm.get('materialBoxes') as FormArray;
    }

    setDataForMaterialBoxes(filterObj: VsRtAnalysisDetail) {
        this.vsRtAnalysisService
            .getMaterialNumberByReader(this.readerPrefix + filterObj.startReaderNumber, this.readerPrefix + filterObj.endReaderNumber)
            .subscribe(res => {
                this.materialData = res.body;
                this.materialFormArr.controls = []; // Clear FormArray
                if (this.materialData && this.materialData.length > 0) {
                    for (let i = 0; i < this.materialData.length; i++) {
                        let filterExistInMaterialData = false;
                        if (this.vsRtAnalysisDetail.filter) {
                            const filtterStrArr = this.vsRtAnalysisDetail.filter.split(',');
                            filterExistInMaterialData = filtterStrArr.findIndex(item => item === this.materialData[i]) > -1;
                        }
                        this.materialFormArr.push(new FormControl(filterExistInMaterialData));
                    }
                }
            });
    }

    ngOnInit(): void {
        this.subscription = this.vsRtDataService.vsRtDetailObjStream$.subscribe(res => {
            this.vsRtAnalysisDetail = res;
            this.setDataForMaterialBoxes(this.vsRtAnalysisDetail);
        });
        this.materialFormArr.enable();
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

    onPaste(event) {
        if (this.materialFormArr.disabled) {
            event.preventDefault();
            const inputText = event.clipboardData.getData('text');
            const textlist = inputText.trim().split(/\n|\s/);
            this.materialPaste = [...this.materialPaste, ...textlist].filter(s => s !== '');
            this.materialFormArr.disable();
        }
    }

    addChip(event: MatChipInputEvent): void {
        const input = event.input;
        const value = event.value;

        if ((value || '').trim()) {
            this.materialPaste.push(value.trim());
        }

        // Reset the input value
        if (input) {
            input.value = '';
        }
    }

    removeChip(fruit: string): void {
        const index = this.materialPaste.indexOf(fruit);

        if (index >= 0) {
            this.materialPaste.splice(index, 1);
        }
    }

    saveFilter() {
        if (this.materialFormArr.enabled) {
            const filterStrArr = this.rtFilterForm
                .get('materialBoxes')
                .value.reduce((arr, ele, i) => (ele === true && arr.push(this.materialData[i]), arr), []);
            this.vsRtAnalysisDetail.filter = filterStrArr && filterStrArr.length > 0 ? filterStrArr.join(',') : null;
        } else {
            this.vsRtAnalysisDetail.filter = this.materialPaste && this.materialPaste.length > 0 ? this.materialPaste.join(',') : null;
        }
        this.vsRtDataService.sendFilterData(this.vsRtAnalysisDetail);
    }

    resetFilter() {
        this.materialFormArr.reset(Array(this.materialData.length).fill(false));
        this.materialPaste = [];
    }

    hideFilter() {
        this.hideFilterEvent.emit(true);
    }

    switchMode() {
        if (this.materialFormArr.enabled) {
            this.materialFormArr.disable();
        } else {
            this.materialFormArr.enable();
        }
    }
}
