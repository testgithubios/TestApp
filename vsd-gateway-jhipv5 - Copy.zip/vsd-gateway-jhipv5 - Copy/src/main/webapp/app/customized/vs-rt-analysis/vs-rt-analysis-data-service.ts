import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { VsRtAnalysisDetail } from 'app/customized/vs-rt-analysis';

@Injectable()
export class VsRtDataService {
    // Observable string sources
    public vsRtDetailArrSource = new BehaviorSubject<VsRtAnalysisDetail[]>([]);

    public vsRtDetailArrayStream$ = this.vsRtDetailArrSource.asObservable();

    public vsRtDetailObjSource = new BehaviorSubject<VsRtAnalysisDetail>({});

    public vsRtDetailObjStream$ = this.vsRtDetailObjSource.asObservable();

    public savefilterSource = new BehaviorSubject<VsRtAnalysisDetail>({});

    public saveFilterStream$ = this.savefilterSource.asObservable();

    sendDataArray(data: VsRtAnalysisDetail[]) {
        this.vsRtDetailArrSource.next(data);
    }

    sendData(data: VsRtAnalysisDetail) {
        this.vsRtDetailObjSource.next(data);
    }

    sendFilterData(data: VsRtAnalysisDetail) {
        this.savefilterSource.next(data);
    }
}
