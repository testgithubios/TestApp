import { Routes } from '@angular/router';

import { VsRtAnalysisComponent } from './vs-rt-analysis.component';
import { VsRtAnalysisDetailComponent } from './vs-rt-analysis-detail.component';
import { UserRouteAccessService } from 'app/core';

export const vsRtAnalysisRoute: Routes = [
    {
        path: 'vs-rt-analysis',
        component: VsRtAnalysisComponent,
        data: {
            authorities: ['ROLE_ADMIN', 'ROLE_RT_ANALYSIS'],
            pageTitle: 'vsdGatewayApp.vsdRtAnalysis.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'vs-rt-analysis-detail',
        component: VsRtAnalysisDetailComponent,
        data: {
            authorities: ['ROLE_ADMIN', 'ROLE_RT_ANALYSIS'],
            pageTitle: 'vsdGatewayApp.vsdRtAnalysis.home.title'
        },
        canActivate: [UserRouteAccessService]
    }
];
