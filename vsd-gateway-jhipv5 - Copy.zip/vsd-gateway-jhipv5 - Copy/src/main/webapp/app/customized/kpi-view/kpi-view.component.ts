import { SharedService } from './../../shared/shared-service';
import { VsDashboardTagService } from './../vs-dashboard-tag/vs-dashboard-tag.service';
import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { IVsKpiView, VsKpiView } from './kpi-view.model';
import { VsKpiViewService } from './kpi-view.service';
import { VsTagFeature, IVsTagFeature } from '../vs-tag-feature/index';
import { VsTagFeatureService } from '../vs-tag-feature/vs-tag-feature.service';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { KPI_VIEW_FEATURE } from 'app/shared/constants/featurelink.constants';
import { JhiAlertService, JhiParseLinks } from 'ng-jhipster';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
    selector: 'jhi-kpi-view',
    templateUrl: './kpi-view.component.html',
    styleUrls: ['kpi-view.component.scss']
})
export class KpiViewComponent implements OnInit {
    public haveIssue = false;
    public link = '';
    public dashboardName = '';
    public serverLink = '';

    @Input()
    public data: any;

    // Params for loading KpiViews
    private sizePerPage = 40;
    private page: number;
    public last: number;
    public totalItems;

    private valueStreamTagId: number;
    public kpiViews: VsKpiView[] = [];
    public isSaving = false;
    public showKpiViews = false;

    @Output()
    isDisplayLinkKpiView = new EventEmitter<boolean>();

    @Output()
    chosenProcessNameKpiView = new EventEmitter<string>();

    constructor(
        private router: Router,
        private activatedRoute: ActivatedRoute,
        private vsDashboardTagService: VsDashboardTagService,
        private kpiViewService: VsKpiViewService,
        private tagFeatureService: VsTagFeatureService,
        private parseLinks: JhiParseLinks,
        private jhiAlertService: JhiAlertService,
        public sanitizer: DomSanitizer,
        private _sharedService: SharedService
    ) {
        _sharedService.changeEmitted$.subscribe(isShowLine => {
            if (isShowLine) {
                if (this.kpiViews.length === 0) {
                    this.loadKpiViews((this.page = 0));
                }
                this._sharedService.emitChange(false);
            }
        });
    }

    ngOnInit() {
        // check for the exist of kpi view
        this.valueStreamTagId = this.data.tagId;
        if (!this.valueStreamTagId) {
            this.haveIssue = true;
            return;
        }

        this.tagFeatureService.findByTagIdAndFeatureLink(this.valueStreamTagId, KPI_VIEW_FEATURE).subscribe(
            (res: HttpResponse<IVsTagFeature>) => {
                if (res.body.featureId != null) {
                    this.navigateKpiView(res.body.featureId);
                } else {
                    this.loadKpiViews((this.page = 0));
                    this.isDisplayLinkKpiView.emit(false);
                }
            },
            error => {
                this.haveIssue = true;
            }
        );
    }

    navigateKpiView(featureId) {
        // reset KpiViews after choosing a specific one
        this.kpiViews = [];
        this.showKpiViews = false;
        this.kpiViewService.find(featureId).subscribe(
            (kpiViewRes: HttpResponse<IVsKpiView>) => {
                // const node = document.createElement('script');
                // node.src = 'https://rb-ps-tableau.bosch.com/javascripts/api/viz_v1.js';
                // node.type = 'text/javascript';
                // node.async = false;
                // node.charset = 'utf-8';
                // document.getElementsByTagName('head')[0].appendChild(node);
                const kpiView = kpiViewRes.body;
                this.link = kpiView.link;

                this.dashboardName = kpiView.dashboardName;
                this.serverLink = kpiView.serverLink;
                this.chosenProcessNameKpiView.emit(kpiView.name);
                this.isDisplayLinkKpiView.emit(true);
            },
            (error: HttpErrorResponse) => {
                this.haveIssue = true;
            }
        );
    }

    // using this function when the user choose one KPI View in the list of KPI View
    chooseKpiView(kpiView) {
        this.kpiViews = [];
        this.isSaving = true;
        const tagFeature: IVsTagFeature = new VsTagFeature();
        tagFeature.featureId = kpiView.id;
        tagFeature.featureLink = KPI_VIEW_FEATURE;
        tagFeature.valueStreamTagId = this.valueStreamTagId;
        this.tagFeatureService.createNewTagFeature(tagFeature).subscribe(
            (res: HttpResponse<IVsTagFeature>) => {
                this.navigateKpiView(kpiView.id);
                this.isSaving = false;
            },
            (res: HttpErrorResponse) => {
                this.jhiAlertService.error(res.message, null, null);
                this.isSaving = false;
            }
        );
    }

    onScrollKpiView() {
        this.page = this.page + 1;
        this.loadKpiViews(this.page);
    }

    loadKpiViews(page: number) {
        this.showKpiViews = true;
        this.kpiViewService
            .query({
                page: this.page,
                size: this.sizePerPage
            })
            .subscribe(
                (res: HttpResponse<VsKpiView[]>) => {
                    for (let i = 0; i < res.body.length; i++) {
                        this.kpiViews.push(res.body[i]);
                    }
                    this.last = this.parseLinks.parse(res.headers.get('link')).last;
                    this.totalItems = res.headers.get('X-Total-Count');
                },
                (res: HttpErrorResponse) => {
                    this.jhiAlertService.error(res.message, null, null);
                }
            );
    }
}
