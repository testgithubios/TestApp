export interface IVsKpiView {
    id?: number;
    name?: string;
    link?: string;
    dashboardName?: string;
    serverLink?: string;
}

export class VsKpiView implements IVsKpiView {
    constructor(
        public id?: number,
        public name?: string,
        public link?: string,
        public dashboardName?: string,
        public serverLink?: string
    ) {}
}
