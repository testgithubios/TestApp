import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { KpiViewComponent } from './index';
import { VsKpiViewService } from './kpi-view.service';
import { VsdGatewaySharedModule } from 'app/shared';

@NgModule({
    imports: [VsdGatewaySharedModule],
    declarations: [KpiViewComponent],
    entryComponents: [],
    providers: [VsKpiViewService],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class VsdGatewayVsKpiViewModule {}
