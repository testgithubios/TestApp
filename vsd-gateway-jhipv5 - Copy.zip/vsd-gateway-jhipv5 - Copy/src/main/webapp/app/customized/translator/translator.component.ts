import { Component, OnInit, OnDestroy, ViewChild, HostListener, Input } from '@angular/core';
import { NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { JhiEventManager, JhiPaginationUtil, JhiAlertService, JhiParseLinks } from 'ng-jhipster';

import { TranslatorService } from './translator.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ScrollTableDirective } from './scroll-table.directive';
import { VsDashboardTagService } from '../vs-dashboard-tag/vs-dashboard-tag.service';

import { VsDashboardTag, IVsDashboardTag } from '../vs-dashboard-tag/vs-dashboard-tag.model';
import { VsDashboard } from '../vs-dashboard/vs-dashboard.model';
import { ClickOutsideDirective } from './click-outside.directive';
import { Subscription } from 'rxjs';
import { PartNumberTranslator, IPartNumberTranslator } from 'app/shared/model/vsd/part-number-translator.model';
import { ValueStreamElement } from 'app/shared/model/vsd/value-stream-element.model';
import { PaginationConfig } from 'app/blocks/config/uib-pagination.config';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { Principal } from 'app/core';
import { EMAIL_SNR, SUBJECT } from 'app/shared/constants/email.constants';
import { ITEMS_PER_PAGE_TRANSLATOR } from 'app/shared';

@Component({
    selector: 'jhi-translator',
    templateUrl: './translator.component.html',
    styleUrls: ['./translator.component.scss']
})
export class TranslatorComponent implements OnInit, OnDestroy {
    partNumberTranslators: PartNumberTranslator[];
    currentAccount: any;
    error: any;
    success: any;
    eventSubscriber: Subscription;
    subscription: Subscription;
    currentSearch: string;
    links: any;
    totalItems: any;
    queryCount: any;
    itemsPerPage: number;
    page: any;
    predicate: any;
    reverse: any;
    email: any;
    subject: any;
    valueStreamName: string;
    id: string;
    tagId: number;
    valueStream: VsDashboard;
    valueStreamTag: VsDashboardTag;
    valueStreamElement: ValueStreamElement;
    vsElementName: string;
    isRender = false;
    chosenSNR: PartNumberTranslator = null;

    @ViewChild(ScrollTableDirective)
    private scrollBarTableDirective: ScrollTableDirective;

    @Input()
    data: any;

    constructor(
        private translatorService: TranslatorService,
        private principal: Principal,
        private activatedRoute: ActivatedRoute,
        private router: Router,
        private parseLinks: JhiParseLinks,
        private jhiAlertService: JhiAlertService,
        private eventManager: JhiEventManager,
        private paginationUtil: JhiPaginationUtil,
        private paginationConfig: PaginationConfig,
        private valueStreamTagService: VsDashboardTagService
    ) {
        this.partNumberTranslators = [];
        this.itemsPerPage = ITEMS_PER_PAGE_TRANSLATOR;
        this.page = 0;
        this.links = {
            last: 0
        };
        this.predicate = 'id';
        this.reverse = true;
        this.currentSearch = activatedRoute.snapshot.params['search'] ? activatedRoute.snapshot.params['search'] : '';
        this.email = EMAIL_SNR;
        this.subject = SUBJECT;
    }

    isBreadcrumb() {
        if (typeof this.id !== 'undefined') {
            return true;
        } else {
            return false;
        }
    }

    loadAll() {
        if (this.currentSearch) {
            this.translatorService
                .search({
                    page: this.page,
                    query: '*' + (this.currentSearch ? this.currentSearch : '') + '*',
                    size: this.itemsPerPage,
                    sort: this.sort()
                })
                .subscribe(
                    (res: HttpResponse<IPartNumberTranslator[]>) => this.onSuccess(res.body, res.headers),
                    (res: HttpErrorResponse) => this.onError(res.message)
                );
            return;
        }
        this.translatorService
            .query({
                page: this.page,
                size: this.itemsPerPage,
                sort: this.sort()
            })
            .subscribe(
                (res: HttpResponse<IPartNumberTranslator[]>) => this.onSuccess(res.body, res.headers),
                (res: HttpErrorResponse) => this.onError(res.message)
            );
    }
    loadPage(page) {
        this.page = page;
        this.loadAll();
    }
    transition() {
        this.page = 0;
        this.partNumberTranslators = [];
        this.isRender = false;
        this.loadAll();
    }

    clear() {
        this.isRender = false;
        this.partNumberTranslators = [];
        this.links = {
            last: 0
        };
        this.page = 0;
        this.predicate = 'id';
        this.reverse = true;
        this.currentSearch = '';
        this.loadAll();
    }
    search(query) {
        if (!query) {
            return this.clear();
        }
        this.isRender = false;
        this.partNumberTranslators = [];
        this.links = {
            last: 0
        };
        this.page = 0;
        this.currentSearch = query;
        this.predicate = '_score';
        this.reverse = false;
        this.loadAll();
    }

    searchAutoComplete(query) {
        if (!query) {
            return this.clear();
        }
        if (this.currentSearch && this.currentSearch.length >= 5) {
            this.isRender = false;
            this.partNumberTranslators = [];
            this.links = {
                last: 0
            };
            this.page = 0;
            this.currentSearch = query;
            this.predicate = '_score';
            this.reverse = false;
            this.loadAll();
        }
    }

    ngOnInit() {
        this.partNumberTranslators = [];
        this.loadAll();
        this.principal.identity().then(account => {
            this.currentAccount = account;
        });

        this.tagId = this.data.tagId;
        this.valueStreamTagService.findOne(this.tagId).subscribe((res: HttpResponse<IVsDashboardTag>) => {
            this.valueStreamTag = res.body;
        });

        this.registerChangeInTranslators();
    }

    ngOnDestroy() {
        this.eventManager.destroy(this.eventSubscriber);
    }

    trackId(index: number, item: PartNumberTranslator) {
        return item.id;
    }
    registerChangeInTranslators() {
        this.eventSubscriber = this.eventManager.subscribe('partNumberTranslatorListModification', response => this.loadAll());
    }

    sort() {
        const result = [this.predicate + ',' + (this.reverse ? 'asc' : 'desc')];
        if (this.predicate !== 'id') {
            result.push('id');
        }
        return result;
    }

    private onSuccess(data, headers) {
        this.links = this.parseLinks.parse(headers.get('link'));
        this.totalItems = headers.get('X-Total-Count');
        this.queryCount = this.totalItems;
        for (let i = 0; i < data.length; i++) {
            this.partNumberTranslators.push(data[i]);
        }
        if (this.scrollBarTableDirective != null && !this.isRender) {
            this.scrollBarTableDirective.reRenderTable();
            // set the flag back to true to do not rerender table again.
            this.isRender = true;
        }
    }

    private onError(errorMessage) {
        console.log(errorMessage);
        // Hide the alerts
        // this.jhiAlertService.error(errorMessage, null, null);
    }

    showSnrDetail(partNumberTranslator) {
        this.chosenSNR = partNumberTranslator;
    }

    hideSnrDetail($event) {
        this.chosenSNR = null;
    }
}
