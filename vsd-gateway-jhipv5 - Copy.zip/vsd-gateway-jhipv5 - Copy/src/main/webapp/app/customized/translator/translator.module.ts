import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { TranslatorComponent } from './';
import { TranslatorService } from './translator.service';
import { ScrollTableDirective } from './scroll-table.directive';
import { ClickOutsideDirective } from './click-outside.directive';
import { VsdGatewaySharedModule } from 'app/shared';
import { TranslatorRibbonComponent } from 'app/layouts/profiles/translator-ribbon.component';

@NgModule({
    imports: [VsdGatewaySharedModule],
    declarations: [TranslatorComponent, ScrollTableDirective, TranslatorRibbonComponent, ClickOutsideDirective],
    entryComponents: [TranslatorComponent],
    providers: [TranslatorService],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class VsdGatewaytranslatorModule {}
