import { Directive, Output, EventEmitter, HostListener } from '@angular/core';

@Directive({
    selector: '[jhiClickOutside]'
})
export class ClickOutsideDirective {
    @Output()
    jhiClickOutside: EventEmitter<any> = new EventEmitter();

    private localEvent = null;
    constructor() {}

    /** Compare event at the Document level to a reference of the Element:click
     * This method triggers when we are on Document level  - Document was clicked or event bubbling
     * If the Document click DON'T MATCH the Event:click reference  => than the click is from outside of the Element
     */
    @HostListener('document:click', ['$event'])
    compareEvent(event: Event) {
        if (event !== this.localEvent) {
            this.jhiClickOutside.emit(event);
        }
        this.localEvent = null;
    }

    /** Track user click from inside the bound target
     *  We use this to track the click Event when it bubbles up the DOM tree
     */
    @HostListener('click', ['$event'])
    trackEvent(event: Event) {
        this.localEvent = event;
    }
}
