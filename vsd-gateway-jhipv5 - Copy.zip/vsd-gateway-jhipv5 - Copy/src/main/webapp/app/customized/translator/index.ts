export * from './translator.component';
export * from './translator.module';
