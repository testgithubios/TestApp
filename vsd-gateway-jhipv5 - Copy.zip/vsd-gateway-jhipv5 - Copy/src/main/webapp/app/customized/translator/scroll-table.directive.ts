import { Directive, ViewContainerRef, Renderer2, ViewChildren, QueryList, ElementRef, ViewChild } from '@angular/core';
import { AfterViewInit } from '@angular/core/src/metadata/lifecycle_hooks';

@Directive({
    selector: '[jhiScrollTable]'
})
export class ScrollTableDirective implements AfterViewInit {
    constructor(public ele: ElementRef, private renderer: Renderer2) {}

    ngAfterViewInit() {
        this.reRenderTable();
    }
    reRenderTable() {
        // reset display styles so column widths are correct when measured below
        this.ele.nativeElement.querySelectorAll('thead, tbody, tfoot').forEach((element, index) => {
            element.setAttribute('style', 'display: ""');
        });
        // wrap in $timeout to give table a chance to finish rendering
        setTimeout(() => {
            // set widths of columns
            const ths = this.ele.nativeElement.querySelectorAll('tr:first-child th');
            ths.forEach((thElem, index) => {
                const tdElems = this.ele.nativeElement.querySelector('tbody tr:first-child td:nth-child(' + (index + 1) + ')');
                const columnWidth = tdElems ? tdElems.offsetWidth : thElem.offsetWidth;
                if (tdElems) {
                    tdElems.style.width = columnWidth + 'px';
                }
                if (thElem) {
                    thElem.style.width = columnWidth + 'px';
                }
            });
            // set css styles on thead and tbody
            this.ele.nativeElement.querySelector('thead').setAttribute('style', 'display: block');
            this.ele.nativeElement.querySelector('tbody').setAttribute('style', 'display: block; ' + 'overflow: auto;');
            // reduce width of last column by width of scrollbar
            const tbody = this.ele.nativeElement.querySelector('tbody');
            let scrollBarWidth = tbody.offsetWidth - tbody.clientWidth;
            if (scrollBarWidth > 0) {
                // for some reason trimming the width by 2px lines everything up better
                scrollBarWidth -= 2;
                const lastColumn = this.ele.nativeElement.querySelector('tbody tr:first-child td:last-child');
                lastColumn.style.width = lastColumn.offsetWidth - scrollBarWidth + 'px';
            }
        });
    }
}
