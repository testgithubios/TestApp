import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

import { SERVER_API_URL } from 'app/app.constants';
import { createRequestOption } from 'app/shared';
import { IPartNumberTranslator } from 'app/shared/model/vsd/part-number-translator.model';

type EntityResponseType = HttpResponse<IPartNumberTranslator>;
type EntityArrayResponseType = HttpResponse<IPartNumberTranslator[]>;

@Injectable()
export class TranslatorService {
    public resourceUrl = SERVER_API_URL + 'vsd/api/part-number-translators';
    public resourceSearchUrl = SERVER_API_URL + 'vsd/api/_search_custom/part-number-translators';

    constructor(private http: HttpClient) {}

    query(req?: any): Observable<EntityArrayResponseType> {
        const options = createRequestOption(req);
        return this.http.get<IPartNumberTranslator[]>(this.resourceUrl, { params: options, observe: 'response' });
    }

    search(req?: any): Observable<EntityArrayResponseType> {
        const options = createRequestOption(req);
        return this.http.get<IPartNumberTranslator[]>(this.resourceSearchUrl, { params: options, observe: 'response' });
    }
}
