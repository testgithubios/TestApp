export * from './vs-product-family.service';
export * from './vs-product-family.model';
