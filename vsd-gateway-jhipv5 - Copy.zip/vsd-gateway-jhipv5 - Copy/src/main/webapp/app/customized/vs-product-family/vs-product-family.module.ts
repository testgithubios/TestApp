import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { VsProductFamilyService } from './';
import { VsdGatewaySharedModule } from 'app/shared';

@NgModule({
    imports: [VsdGatewaySharedModule],
    declarations: [],
    entryComponents: [],
    providers: [VsProductFamilyService],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class VsdGatewayVsProductFamilyModule {}
