export interface IVsProductFamily {
    id?: number;
    refId?: number;
    name?: string;
}

export class VsProductFamily implements IVsProductFamily {
    constructor(public id?: number, public refId?: number, public name?: string) {}
}
