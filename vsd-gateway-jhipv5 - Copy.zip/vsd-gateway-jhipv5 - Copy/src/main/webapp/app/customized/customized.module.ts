import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { VsdGatewayVsDashboardModule } from './vs-dashboard/vs-dashboard.module';
import { VsdGatewayVsDashboardElementModule } from './vs-dashboard-element/vs-dashboard-element.module';
import { VsdGatewayVsDashboardTagModule } from './vs-dashboard-tag/vs-dashboard-tag.module';
import { VsdGatewayAppUserSettingModule } from './app-user-setting/app-user-setting.module';
import { VsdGatewayVsProductFamilyModule } from './vs-product-family/vs-product-family.module';
import { VsdGatewayVsTagFeatureModule } from 'app/customized/vs-tag-feature/vs-tag-feature.module';
import { ReaderMonitorModule } from 'app/customized/reader-monitor/reader-monitor.module';
import { VsdGatewayLeadTimeAnalysisModule } from 'app/customized/lead-time-analysis/lead-time-analysis.module';
import { VsdGatewayVsRtAnalysisModule } from 'app/customized/vs-rt-analysis/vs-rt-analysis.module';
import { VsdGatewayVsKpiViewModule } from './kpi-view/kpi-view.module';
import { VsdGatewaytranslatorModule } from 'app/customized/translator';
import { VsdGatewayLicenseModule } from 'app/customized/licenses/licenses.module';
import { CustomFeatureStatusModule } from 'app/customized/vs-feature-status/vs-feature-status.module';

@NgModule({
    // prettier-ignore
    imports: [
        VsdGatewayVsDashboardModule,
        VsdGatewayVsDashboardElementModule,
        VsdGatewayVsDashboardTagModule,
        VsdGatewayAppUserSettingModule,
        VsdGatewayVsProductFamilyModule,
        VsdGatewayVsTagFeatureModule,
        VsdGatewayVsRtAnalysisModule,
        ReaderMonitorModule,
        VsdGatewayVsKpiViewModule,
        VsdGatewayLeadTimeAnalysisModule,
        VsdGatewaytranslatorModule,
        VsdGatewayLicenseModule,
        CustomFeatureStatusModule
    ],
    declarations: [],
    entryComponents: [],
    providers: [],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class CustomizedModule {}
