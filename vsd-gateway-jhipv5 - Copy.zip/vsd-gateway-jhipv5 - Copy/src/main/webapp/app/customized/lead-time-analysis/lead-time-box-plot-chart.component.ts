import { Component, ViewEncapsulation, OnInit, ViewChild, ElementRef, Input, EventEmitter } from '@angular/core';
import * as d3 from 'd3';
import { COLOR_ARRAY } from 'app/customized/lead-time-analysis/color-array';
import { LeadTimeReportData } from 'app/customized/lead-time-analysis/lead-time-report-data.model';
import { VsLeadTimeLinkService } from 'app/customized/lead-time-analysis';

@Component({
    selector: 'jhi-lead-time-box-plot',
    templateUrl: 'lead-time-box-plot-chart.component.html',
    styleUrls: ['lead-time-box-plot-chart.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class LeadTimeBoxPlotComponent implements OnInit {
    // Get data from lead-time-charts after initializing
    @Input()
    dataInit: any;

    // Get data updated from filter
    @Input()
    boxPlotData: EventEmitter<any[]>;

    @ViewChild('boxPlot')
    private boxPlotContainer: ElementRef;
    private colors = COLOR_ARRAY;

    constructor() {}

    ngOnInit() {
        if (this.boxPlotData) {
            this.boxPlotData.subscribe(data => {
                this.renderBoxPlot(data);
            });
        }
        if (this.dataInit) {
            this.renderBoxPlot(this.dataInit);
        }
    }

    groupBy(array, key) {
        const groupedObject = array.reduce((rv, x) => {
            (rv[x[key]] = rv[x[key]] || []).push(x);
            return rv;
        }, {});
        return groupedObject;
    }

    aggregateData(objectGroupedByDisName) {
        const resultObject = [];
        Object.keys(objectGroupedByDisName).map(disNameKey => {
            const objectGroupedByBarName = this.groupBy(objectGroupedByDisName[disNameKey], 'barName');
            const barNames = Object.keys(objectGroupedByBarName);
            barNames.forEach(barNameKey => {
                const dataArrayByBarName = objectGroupedByBarName[barNameKey].map(ele => ele.dlz);
                const objectItem = {
                    disName: disNameKey,
                    barName: barNameKey,
                    data: dataArrayByBarName,
                    dur: objectGroupedByBarName[barNameKey][0]['dur']
                };
                resultObject.push(objectItem);
            });
        });
        return resultObject;
    }

    compare(a, b) {
        // order by disName and barName
        if (a.disName === b.disName) {
            // duration is only important when disName are the same
            const av = a.barName.substring(0, 5).split('.')[1] + a.barName.substring(0, 5).split('.')[0];
            const bv = b.barName.substring(0, 5).split('.')[1] + b.barName.substring(0, 5).split('.')[0];
            if (a.dur === 7 && b.dur === 7) {
                return av > bv ? 1 : -1;
            } else if (a.dur !== 7 && b.dur === 7) {
                return -1;
            } else if (a.dur === 7 && b.dur !== 7) {
                return 1;
            } else {
                return av > bv ? 1 : -1;
            }
        }
        return a.disName > b.disName ? 1 : -1;
    }

    renderBoxPlot(rawData: LeadTimeReportData[]) {
        // ***************AGGREGATE DATA***************** /
        rawData.sort((a, b) => this.compare(a, b));
        const objectGroupedByDisName = this.groupBy(rawData, 'disName');
        const aggregatedData = this.aggregateData(objectGroupedByDisName);

        // Fill color based of duration value
        const distinctDur = Array.from(new Set(aggregatedData.map(d => '' + d.dur)));
        const colors = this.colors.slice(0, distinctDur.length);
        const colorScale = d3
            .scaleOrdinal()
            .range(colors)
            .domain(distinctDur);

        // Sort data into ascending array to calculate box plot data
        let data_sorted = aggregatedData.map(d => {
            d.data.sort(d3.ascending);
            return d;
        });
        data_sorted = data_sorted.map(i => {
            const min_value = Math.min(...i.data);
            const max_value = Math.max(...i.data);
            const q1_value = d3.quantile(i.data, 0.25);
            const q2_value = d3.quantile(i.data, 0.5);
            const q3_value = d3.quantile(i.data, 0.75);
            const iqr_value = q3_value - q1_value;
            const obj = {
                ...i,
                q1: q1_value,
                q2: q2_value,
                q3: q3_value,
                iqr: iqr_value,
                lower_limit: q1_value - 1.5 * iqr_value < min_value ? min_value : q1_value - 1.5 * iqr_value,
                upper_limit: q3_value + 1.5 * iqr_value > max_value ? max_value : q3_value + 1.5 * iqr_value
            };
            return obj;
        });
        // ****************************************** /
        // set the dimensions and margins of the graph
        const boxPlotEle = this.boxPlotContainer.nativeElement;
        const w_container = boxPlotEle.offsetWidth;
        const h_container = boxPlotEle.offsetHeight;
        const margin = { top: 50, right: 20, bottom: 100, left: 35 };
        const width = w_container - margin.left - margin.right;
        const height = h_container - margin.top - margin.bottom;

        // append the svg object to the body of the page
        d3.select('#box-plot-chart > svg').remove();
        const svg = d3
            .select('#box-plot-chart')
            .append('svg')
            .attr('width', w_container)
            .attr('height', h_container);
        svg.append('text')
            .text('DLZ Boxplot')
            .attr('class', 'title')
            .attr('x', 20)
            .attr('y', 30);

        const chart = svg
            .append('g')
            .attr('class', 'chart-content')
            .attr('transform', 'translate(' + margin.left + ',' + margin.top + ')');

        // axis x
        const xScale = d3
            .scaleBand()
            .range([0, width])
            .domain(
                data_sorted.map((d: any) => {
                    return d.barName + ':' + d.disName;
                })
            )
            .paddingOuter(0)
            .paddingInner(0.05);

        let max_y_value = d3.max(rawData, (d: any) => {
            return d.dlz;
        });
        max_y_value = max_y_value === 0 ? 1 : max_y_value;
        // axis y
        const yScale = d3
            .scaleLinear()
            .range([height, 0])
            .domain([0, max_y_value]);

        const xAxis = chart
            .append('g')
            .attr('class', 'axis')
            .attr('transform', 'translate(0,' + height + ')')
            .call(d3.axisBottom(xScale).tickFormat(d => d.split(':')[0])) // Only get the time for label bandWidth
            .selectAll('text')
            .attr('x', -33)
            .attr('y', -3)
            .attr('transform', 'rotate(-90)');

        const yAxis = chart
            .append('g')
            .attr('class', 'axis')
            .call(d3.axisLeft(yScale).ticks(3))
            .selectAll('text')
            .attr('x', 0);

        // x-title
        chart
            .append('text')
            .text('Disponent / Zeitraum')
            .attr('class', 'x_title')
            .attr('x', width / 2 - margin.left)
            .attr('y', -30);
        // y-title
        chart
            .append('text')
            .text('DLZ')
            .attr('class', 'y_title')
            .attr('x', -(height / 2))
            .attr('y', -27)
            .attr('transform', 'rotate(-90)');

        // Create box plot
        const boxes = chart
            .selectAll()
            .data(data_sorted)
            .enter()
            .append('g')
            .attr('class', 'boxes');
        const upper_rect = boxes
            .append('rect')
            .attr('class', 'upper-rect')
            .attr('x', (d: any) => xScale(d.barName + ':' + d.disName))
            .attr('y', (d: any) => yScale(d.q3))
            .attr('width', xScale.bandwidth())
            .attr('height', (d: any) => yScale(d.q2) - yScale(d.q3))
            .on('mouseover', (d: any) => {
                tooltip
                    .transition()
                    .duration(100)
                    .style('opacity', 1)
                    .style('left', d3.event.pageX + 10 + 'px')
                    .style('top', d3.event.pageY + 10 + 'px')
                    .style('z-index', 9);
                tooltip.html(
                    `<table>
                    <tr>
                        <td>Upper Whisker:</td>
                        <td>${d.upper_limit}</td>
                    </tr>
                    <tr>
                        <td>Upper Hinge:</td>
                        <td>${d.q3}</td>
                    </tr>
                    <tr>
                        <td>Median:</td>
                         <td>${d.q2}</td>
                    </tr>
                    <tr>
                        <td>Lower Hinge:</td>
                        <td>${d.q1}</td>
                    </tr>
                    <tr>
                        <td>Lower Whisker:</td>
                        <td>${d.lower_limit}</td>
                    </tr>
                    </table>`
                );
            })
            .on('mouseout', d => {
                tooltip
                    .transition()
                    .duration(500)
                    .style('opacity', 0)
                    .style('z-index', -1);
            });
        const lower_rect = boxes
            .append('rect')
            .attr('class', 'lower-rect')
            .attr('x', (d: any) => xScale(d.barName + ':' + d.disName))
            .attr('y', (d: any) => yScale(d.q2))
            .attr('width', xScale.bandwidth())
            .attr('height', (d: any) => yScale(d.q1) - yScale(d.q2))
            .on('mouseover', (d: any) => {
                tooltip
                    .transition()
                    .duration(100)
                    .style('opacity', 1)
                    .style('left', d3.event.pageX + 10 + 'px')
                    .style('top', d3.event.pageY + 10 + 'px')
                    .style('z-index', 9);
                tooltip.html(
                    `<table>
                    <tr>
                        <td>Upper Whisker:</td>
                        <td>${d.upper_limit}</td>
                    </tr>
                    <tr>
                        <td>Upper Hinge:</td>
                        <td>${d.q3}</td>
                    </tr>
                    <tr>
                        <td>Median:</td>
                         <td>${d.q2}</td>
                    </tr>
                    <tr>
                        <td>Lower Hinge:</td>
                        <td>${d.q1}</td>
                    </tr>
                    <tr>
                        <td>Lower Whisker:</td>
                        <td>${d.lower_limit}</td>
                    </tr>
                    </table>`
                );
            })
            .on('mouseout', d => {
                tooltip
                    .transition()
                    .duration(500)
                    .style('opacity', 0)
                    .style('z-index', -1);
            });

        // Create min, max, median, hinge lines
        const lines = chart
            .selectAll()
            .data(data_sorted)
            .enter()
            .append('g')
            .attr('class', 'lines');

        const medians = lines
            .append('line')
            .attr('class', 'median')
            .attr('x1', (d: any) => xScale(d.barName + ':' + d.disName))
            .attr('x2', (d: any) => xScale(d.barName + ':' + d.disName) + xScale.bandwidth())
            .attr('y1', (d: any) => yScale(d.q2))
            .attr('y2', (d: any) => yScale(d.q2));

        const upper_whisker = lines
            .append('line')
            .attr('class', 'upper whisker')
            .attr('x1', (d: any) => xScale(d.barName + ':' + d.disName))
            .attr('x2', (d: any) => xScale(d.barName + ':' + d.disName) + xScale.bandwidth())
            .attr('y1', (d: any) => yScale(d.q3))
            .attr('y2', (d: any) => yScale(d.q3));
        const lower_whisker = lines
            .append('line')
            .attr('class', 'lower whisker')
            .attr('x1', (d: any) => xScale(d.barName + ':' + d.disName))
            .attr('x2', (d: any) => xScale(d.barName + ':' + d.disName) + xScale.bandwidth())
            .attr('y1', (d: any) => yScale(d.q1))
            .attr('y2', (d: any) => yScale(d.q1));

        const max = lines
            .append('line')
            .attr('class', 'max')
            .attr('x1', (d: any) => xScale(d.barName + ':' + d.disName))
            .attr('x2', (d: any) => xScale(d.barName + ':' + d.disName) + xScale.bandwidth())
            .attr('y1', (d: any) => yScale(d.upper_limit))
            .attr('y2', (d: any) => yScale(d.upper_limit));

        const min = lines
            .append('line')
            .attr('class', 'min')
            .attr('x1', (d: any) => xScale(d.barName + ':' + d.disName))
            .attr('x2', (d: any) => xScale(d.barName + ':' + d.disName) + xScale.bandwidth())
            .attr('y1', (d: any) => yScale(d.lower_limit))
            .attr('y2', (d: any) => yScale(d.lower_limit));

        const middle_line = lines
            .append('line')
            .attr('class', 'middle-line')
            .attr('x1', (d: any) => xScale(d.barName + ':' + d.disName) + xScale.bandwidth() / 2)
            .attr('x2', (d: any) => xScale(d.barName + ':' + d.disName) + xScale.bandwidth() / 2)
            .attr('y1', (d: any) => yScale(d.lower_limit))
            .attr('y2', (d: any) => yScale(d.upper_limit));

        const tooltip = d3
            .select('#box-plot-chart')
            .append('div')
            .attr('class', 'tooltip')
            .style('opacity', 0);

        chart
            .selectAll()
            .data(rawData)
            .enter()
            .append('g')
            .attr('class', 'points')
            .append('circle')
            .attr('class', 'point-value')
            .style('fill', (d: any) => '' + colorScale(d.dur))
            .attr('cx', (d: any) => xScale(d.barName + ':' + d.disName) + xScale.bandwidth() / 2)
            .attr('cy', (d: any) => yScale(d.dlz))
            .attr('r', 4)
            .on('mouseover', (d: any) => {
                tooltip
                    .transition()
                    .duration(100)
                    .style('opacity', 1)
                    .style('left', d3.event.pageX + 10 + 'px')
                    .style('top', d3.event.pageY + 10 + 'px')
                    .style('z-index', 9);
                tooltip.html(
                    `<table>
                    <tr>
                        <td>Zeitraum:</td>
                        <td>${d.barName}</td>
                    </tr>
                    <tr>
                        <td>Disponent:</td>
                        <td>${d.disName}</td>
                    </tr>
                    <tr>
                        <td>Tage:</td>
                            <td>${d.dur}</td>
                    </tr>
                    <tr>
                        <td>Ttnr:</td>
                        <td>${d.ttnr}</td>
                    </tr>
                    <tr>
                        <td>DLZ:</td>
                        <td>${d.dlz}</td>
                    </tr>
                    <tr>
                        <td>Durchshnittsbestand:</td>
                        <td>${d.durchschnittsbestand}</td>
                    </tr>
                    </table>
                    `
                );
            })
            .on('mouseout', d => {
                tooltip
                    .transition()
                    .duration(500)
                    .style('opacity', 0)
                    .style('z-index', -1);
            });

        // Create lines between disponent charts
        const distinctDisponent = Array.from(new Set(aggregatedData.map(d => d.disName)));
        const disponentScale = d3
            .scaleBand()
            .rangeRound([0, width])
            .domain(
                data_sorted.map((d: any) => {
                    return d.disName;
                })
            );

        const display_disponent = chart
            .append('g')
            .attr('class', 'axis')
            .attr('transform', 'translate(0,-2)')
            .call(d3.axisBottom(disponentScale))
            .selectAll('text')
            .attr('y', -12);

        chart
            .selectAll()
            .data(distinctDisponent)
            .enter()
            .append('g')
            .attr('class', 'walls')
            .append('line')
            .attr('x1', (d: any) => disponentScale(d) + disponentScale.bandwidth())
            .attr('x2', (d: any) => disponentScale(d) + disponentScale.bandwidth())
            .attr('y1', 0)
            .attr('y2', height);

        // add the Y gridlines
        chart
            .append('g')
            .attr('class', 'grid')
            .call(
                d3
                    .axisLeft(yScale)
                    .ticks(3)
                    .tickSize(-width)
                    .tickFormat(null)
                    .scale(yScale)
            );

        // Create duration color palette
        d3.select('#tage > svg').remove();
        const paletteHeight = 65 + ((distinctDur.length > 0 && distinctDur.length - 1) || 0) * 20;
        const tagePalette = d3
            .select('#tage')
            .append('svg')
            .attr('height', paletteHeight)
            .attr('width', '100%')
            .append('g')
            .attr('class', 'tage')
            .selectAll('g')
            .data(distinctDur.slice().reverse())
            .enter()
            .append('g')
            .attr('transform', (d, i) => {
                return 'translate(0,' + (i === 0 ? 30 : 30 + i * 20) + ')'; // Just for adjusting text line
            });

        // Add title of Palette
        d3.select('#tage > svg')
            .append('g')
            .attr('class', 'title')
            .append('text')
            .attr('class', 'title')
            .attr('x', 0)
            .attr('y', 20)
            .text('Tage');

        tagePalette
            .append('rect')
            .attr('x', 0)
            .attr('width', 19)
            .attr('height', 19)
            .style('fill', (d: any, i: any) => '' + colorScale(d));

        tagePalette
            .append('text')
            .attr('x', 30)
            .attr('y', 9.5)
            .text((d: any) => d);
    }
}
