import { OnInit, Component, EventEmitter, Input, ElementRef, ViewChild, ViewEncapsulation } from '@angular/core';
import * as d3 from 'd3';
import { COLOR_ARRAY } from 'app/customized/lead-time-analysis/color-array';

@Component({
    selector: 'jhi-lead-time-stacked-bar',
    templateUrl: './lead-time-stacked-bar.component.html',
    styleUrls: ['lead-time-stacked-bar.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class LeadTimeStackedBarComponent implements OnInit {
    @ViewChild('stackedBar')
    private stackedBarContainer: ElementRef;
    private w;
    private h;
    private aggregatedData: any;
    private colors = COLOR_ARRAY;
    private keys;

    // NO need to updated chart when filtering Disponent for now
    // Get data updated from filter
    // @Input()
    // stackedBarData: EventEmitter<any[]>;

    // Get data from lead-time-charts after initializing
    @Input()
    dataInit: any;

    constructor() {}

    ngOnInit() {
        // NO need to updated chart when filtering Disponent for now
        // if (this.stackedBarData) {
        //     this.stackedBarData.subscribe(data => {
        //         this.keys = Array.from(new Set(data.map(i => i.disName))); // ['13st', 'EDL', 'HCB', 'HCC', 'HCI', 'HCJ', 'HCK', 'HCL']
        //         this.aggregatedData = this.convert(this.groupBy(data, 'barName'));
        //         this.renderStackedChart(this.aggregatedData, this.keys);
        //     });
        // }

        if (this.dataInit) {
            this.keys = Array.from(new Set(this.dataInit.map(i => i.disName)));
            this.aggregatedData = this.convert(this.groupBy(this.dataInit, 'barName'));
            this.renderStackedChart(this.aggregatedData, this.keys);
        }
    }

    groupBy(xs, key) {
        const groupedObject = xs.reduce((rv, x) => {
            (rv[x[key]] = rv[x[key]] || []).push(x);
            return rv;
        }, {});
        return groupedObject;
    }

    convert(object) {
        // Create data for stacked bar
        return Object.keys(object).map(key => {
            const result = {};
            object[key].forEach(ele => {
                result[ele.disName] = ele.barVal;
            });
            result['barName'] = key;
            result['dur'] = object[key][0].dur;
            return result;
        });
    }

    private renderStackedChart(aggregatedData, keys) {
        const colors = this.colors.slice(0, keys.length);
        const stackedBarEle = this.stackedBarContainer.nativeElement;
        this.w = stackedBarEle.offsetWidth;
        this.h = stackedBarEle.offsetHeight;
        const margin = { top: 50, right: 20, bottom: 100, left: 35 };
        const width = this.w - margin.left - margin.right;
        const height = this.h - margin.top - margin.bottom;
        d3.select('#stacked-bar-chart').remove();
        const stackedSeries = d3.stack().keys(this.keys)(aggregatedData);

        const z = d3
            .scaleOrdinal()
            .range(colors)
            .domain(keys);

        // An example for domain of x : [01.03 - 31.03, 01.04 - 30.04]
        const x = d3
            .scaleBand()
            .rangeRound([0, width])
            .padding(0.05)
            .domain(
                aggregatedData.map((d: any) => {
                    return d.barName;
                })
            );
        let max_y_value = +d3.max(stackedSeries, (d_: any) => {
            return d3.max(d_, (d: any) => {
                return d[1];
            });
        });
        max_y_value = max_y_value === 0 ? 1 : max_y_value;
        const y = d3
            .scaleLinear()
            .range([height, 0])
            .domain([0, max_y_value]);

        const svg = d3
            .select(stackedBarEle)
            .append('svg')
            .attr('class', 'chart')
            .attr('id', 'stacked-bar-chart')
            .attr('width', this.w)
            .attr('height', this.h);

        svg.append('text')
            .text('Monatswerte')
            .attr('class', 'title')
            .attr('x', 20)
            .attr('y', 30);

        const chart = svg
            .append('g')
            .classed('chart-contents', true)
            .attr('transform', 'translate(' + margin.left + ',' + margin.top + ')');

        // add the Y gridlines
        chart
            .append('g')
            .attr('class', 'grid')
            .call(
                d3
                    .axisLeft(y)
                    .ticks(5)
                    .tickSize(-width)
                    .tickFormat(null)
                    .scale(y)
            );

        const layersBarArea = chart.append('g').classed('layers', true);
        const layersBar = layersBarArea
            .selectAll('.layer')
            .data(stackedSeries)
            .enter()
            .append('g')
            .classed('layer', true)
            .style('fill', (d: any, i: any) => {
                return '' + z(d);
            });

        d3.select('#color-palette > svg').remove();
        const paletteHeight = 65 + ((keys.length > 0 && keys.length - 1) || 0) * 20; // Height of color palette based of keys (which are disponents)
        const colorPalette = d3
            .select('#color-palette')
            .attr('height', paletteHeight)
            .append('svg')
            .attr('height', paletteHeight)
            .attr('width', '100%')
            .append('g')
            .attr('class', 'color-palette')
            .selectAll('g')
            .data(keys.slice().reverse())
            .enter()
            .append('g')
            .attr('transform', (d, i) => {
                return 'translate(0,' + (i === 0 ? 30 : 30 + i * 20) + ')'; // Just for adjusting text line
            });

        // Add title of Palette
        d3.select('#color-palette > svg')
            .append('g')
            .attr('class', 'title')
            .append('text')
            .attr('class', 'title')
            .attr('x', 0)
            .attr('y', 20)
            .text('Disponents');

        colorPalette
            .append('rect')
            .attr('x', 0)
            .attr('width', 19)
            .attr('height', 19)
            .style('fill', (d: any, i: any) => {
                return '' + z(d);
            });

        colorPalette
            .append('text')
            .attr('x', 30)
            .attr('y', 9.5)
            // .attr('dy', '0.32em')
            .text((d: any) => {
                return d;
            });

        const tooltip = d3
            .select('#stacked-bar')
            .append('div')
            .attr('class', 'tooltip')
            .style('opacity', 0);

        layersBar
            .selectAll('rect')
            .data((d: any) => {
                return d;
            })
            .enter()
            .append('rect')
            .attr('class', 'bar')
            .attr('y', (d: any) => {
                return y(d[1]);
            })
            .attr('x', (d: any, i: any) => {
                return x(d.data.barName);
            })
            .attr('width', x.bandwidth())
            .attr('height', (d: any, i: any) => {
                return y(d[0]) - y(d[1]);
            })
            .on('mouseover', (d: any) => {
                const val = (d[1] - d[0]).toFixed(2);
                const disName = Object.keys(d.data).find(key => +d.data[key] === +val);
                tooltip
                    .transition()
                    .duration(200)
                    .style('opacity', 1)
                    .style('left', d3.event.pageX + 10 + 'px')
                    .style('top', d3.event.pageY + 10 + 'px')
                    .style('z-index', 9);
                tooltip.html(
                    `<table>
                  <tr>
                    <td>Zeitraum:</td>
                    <td>${d.data.barName}</td>
                  </tr>
                  <tr>
                    <td>Disponent:</td>
                    <td>${disName}</td>
                  </tr>
                  <tr>
                    <td>Tage:</td>
                    <td>${d.data.dur}</td>
                  </tr>
                  <tr>
                    <td>Stufendurchschnitt:</td>
                    <td>${val}</td>
                  </tr>
                </table>`
                );
            })
            .on('mouseout', d => {
                tooltip
                    .transition()
                    .duration(500)
                    .style('opacity', 0)
                    .style('z-index', -1);
            });

        const xAxis = chart
            .append('g')
            .classed('x axis', true)
            .attr('transform', 'translate(0,' + height + ')')
            .call(d3.axisBottom(x))
            .selectAll('text')
            .attr('transform', 'translate(-12,3) rotate(-90)')
            .style('text-anchor', 'end')
            .style('font-size', 12)
            .style('fill', '#FFFFF');

        chart
            .append('text')
            .attr('y', -10) // Title on top
            .attr('x', width / 2)
            .classed('axis-title', true)
            .style('text-anchor', 'middle')
            .style('stroke', 'none')
            .text('Zeitraum');

        const yAxis = chart
            .append('g')
            .classed('y axis', true)
            .call(d3.axisLeft(y))
            .selectAll('text')
            .attr('transform', 'translate(5,0)'); // all text of y axis move to right 5px

        chart
            .append('text')
            .attr('transform', 'rotate(-90)')
            .attr('y', -25)
            .attr('x', 0 - height / 2)
            .style('text-anchor', 'middle')
            .style('stroke', 'none')
            .classed('axis-title', true)
            .text('Stufendurchschnitt');
    }
}
