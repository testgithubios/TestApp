import { SharedService } from './../../shared/shared-service';
import { VsDashboardTagService } from './../vs-dashboard-tag/vs-dashboard-tag.service';
import {
    Component,
    OnInit,
    Input,
    Output,
    EventEmitter,
    ViewChild,
    ElementRef,
    ViewEncapsulation,
    ComponentFactoryResolver
} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { IVsLeadTimeLink, VsLeadTimeLink } from './lead-time-analysis-link.model';
import { VsLeadTimeLinkService } from './lead-time-analysis-link.service';
import { VsTagFeatureService } from '../vs-tag-feature/vs-tag-feature.service';
import { VsTagFeature, IVsTagFeature } from '../vs-tag-feature/vs-tag-feature.model';
import { LEAD_TIME_FEATURE } from 'app/shared/constants/featurelink.constants';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { JhiAlertService, JhiParseLinks } from 'ng-jhipster';
import { AdDirective } from 'app/customized/vs-dashboard-tag/ad.directive';
import { AdComponent } from 'app/customized/vs-dashboard-tag/ad.component';
import { LeadTimeAdService } from 'app/customized/lead-time-analysis/lead-time-ad.service';
import { AdService } from 'app/customized/vs-dashboard-tag/ad.service';
import { LeadTimeReportData } from 'app/customized/lead-time-analysis/lead-time-report-data.model';

@Component({
    selector: 'jhi-lead-time-analysis',
    templateUrl: './lead-time-analysis.component.html',
    styleUrls: ['lead-time-analysis.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class LeadTimeAnalysisComponent implements OnInit {
    public haveIssue = false;
    public link = '';
    public dashboardName = '';
    private tagFeature: VsTagFeature;

    @Input()
    public data: any;

    public leadTimes: VsLeadTimeLink[] = [];

    // Params for loading LeadTimes
    private sizePerPage = 40;
    private page: number;
    public last: number;
    public totalItems;

    private valueStreamTagId: number;
    public showLeadTimes = false;
    public isSaving = false;

    public disponents: { disName: string; selected: boolean }[] = [];
    public barDatas: any[] = [];
    public isTableau = true;

    @Output()
    isDisplayLinkLeadTime = new EventEmitter<boolean>();

    @Output()
    chosenProcessNameLeadTime = new EventEmitter<string>();

    @ViewChild(AdDirective)
    adHost: AdDirective;
    viewContainerRef;

    private boxPlotRawData;
    constructor(
        private router: Router,
        private activatedRoute: ActivatedRoute,
        private vsDashboardTagService: VsDashboardTagService,
        private leadTimeAnalysisLinkService: VsLeadTimeLinkService,
        private tagFeatureService: VsTagFeatureService,
        private parseLinks: JhiParseLinks,
        private jhiAlertService: JhiAlertService,
        private _sharedService: SharedService,
        private componentFactoryResolver: ComponentFactoryResolver,
        private leadTimeAdService: LeadTimeAdService
    ) {
        _sharedService.changeEmitted$.subscribe(isShowLine => {
            if (isShowLine) {
                if (this.leadTimes.length === 0) {
                    this.loadLeadTimes((this.page = 0));
                }
                this._sharedService.emitChange(false);
            }
        });
    }

    ngOnInit() {
        // check for the exist of lead time setting
        this.valueStreamTagId = this.data.tagId;
        if (!this.valueStreamTagId) {
            this.haveIssue = true;
            return;
        }

        this.tagFeatureService.findByTagIdAndFeatureLink(this.valueStreamTagId, LEAD_TIME_FEATURE).subscribe(
            (res: HttpResponse<IVsTagFeature>) => {
                this.tagFeature = res.body;

                if (this.tagFeature.featureId != null) {
                    this.navigateLeadTime(this.tagFeature.featureId);
                } else {
                    this.isDisplayLinkLeadTime.emit(false);
                    this.loadLeadTimes((this.page = 0));
                }
            },
            (error: HttpErrorResponse) => {
                this.haveIssue = true;
            }
        );

        this.leadTimeAnalysisLinkService.getLeadTimeForBoxPlot().subscribe(res => {
            this.boxPlotRawData = res.body;
        });
    }

    navigateLeadTime(featureId) {
        this.showLeadTimes = false;
        this.leadTimes = [];
        this.leadTimeAnalysisLinkService.find(featureId).subscribe(
            (result: HttpResponse<IVsLeadTimeLink>) => {
                this.link = result.body.link;

                // charts
                this.leadTimeAnalysisLinkService.getLeadTimeForBarChart().subscribe((resultData: HttpResponse<LeadTimeReportData[]>) => {
                    // store it, use when user change filter options
                    this.barDatas = resultData.body;
                });

                this.dashboardName = result.body.dashboardName;
                // load LeadTimeTableauComponent at first
                this.loadComponent('LeadTimeTableauComponent', this.dashboardName, null, this.link);

                this.chosenProcessNameLeadTime.emit(result.body.name);
                this.isDisplayLinkLeadTime.emit(true);
            },
            (error: HttpErrorResponse) => {
                this.haveIssue = true;
            }
        );
    }

    onScrollLeadTime() {
        this.page = this.page + 1;
        this.loadLeadTimes(this.page);
    }

    loadLeadTimes(page: number) {
        this.showLeadTimes = true;
        this.leadTimeAnalysisLinkService
            .query({
                valueStreamName: this.data.valueStreamName,
                plantName: this.data.plantName,
                page: this.page,
                size: this.sizePerPage
            })
            .subscribe(
                (res: HttpResponse<VsLeadTimeLink[]>) => {
                    for (let i = 0; i < res.body.length; i++) {
                        this.leadTimes.push(res.body[i]);
                    }
                    this.last = this.parseLinks.parse(res.headers.get('link')).last;
                    this.totalItems = res.headers.get('X-Total-Count');
                },
                (res: HttpErrorResponse) => {
                    this.jhiAlertService.error(res.message, null, null);
                }
            );
    }

    chooseLeadTime(leadTime) {
        this.leadTimes = [];
        const tagFeature: IVsTagFeature = new VsTagFeature();
        tagFeature.featureId = leadTime.id;
        tagFeature.featureLink = LEAD_TIME_FEATURE;
        tagFeature.valueStreamTagId = this.valueStreamTagId;

        this.isSaving = true;
        this.tagFeatureService.createNewTagFeature(tagFeature).subscribe(
            (res: HttpResponse<IVsTagFeature>) => {
                this.navigateLeadTime(tagFeature.featureId);
                this.isSaving = false;
            },
            (res: HttpErrorResponse) => {
                this.jhiAlertService.error(res.message, null, null);
                this.isSaving = false;
            }
        );
    }

    changeVisualMode() {
        this.isTableau = !this.isTableau;
        if (this.isTableau === true) {
            this.loadComponent('LeadTimeTableauComponent', this.dashboardName, null, this.link);
        } else {
            this.loadComponent('LeadTimeChartsComponent', this.barDatas, this.boxPlotRawData, this.link);
        }
    }

    loadComponent(componentName, data1, data2, link) {
        const adItem = this.leadTimeAdService.getComponent(componentName, data1, data2, link);
        const componentFactory = this.componentFactoryResolver.resolveComponentFactory(adItem.component);
        this.viewContainerRef = this.adHost.viewContainerRef;
        this.viewContainerRef.clear();
        const componentRef = this.viewContainerRef.createComponent(componentFactory);
        (<AdComponent>componentRef.instance).data = adItem.data;
    }
}
