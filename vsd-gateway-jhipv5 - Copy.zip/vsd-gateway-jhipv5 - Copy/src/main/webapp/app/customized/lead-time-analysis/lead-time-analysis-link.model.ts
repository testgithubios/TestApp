export interface IVsLeadTimeLink {
    id?: number;
    name?: string;
    link?: string;
    dashboardName?: string;
    plantId?: number;
    valueStreamId?: number;
}

export class VsLeadTimeLink implements IVsLeadTimeLink {
    constructor(
        public id?: number,
        public name?: string,
        public link?: string,
        public dashboardName?: string,
        public plantId?: number,
        public valueStreamId?: number
    ) {}
}
