import { Injectable } from '@angular/core';
import { AdItem } from 'app/customized/vs-dashboard-tag/ad-item';
import { LeadTimeBarChartComponent } from 'app/customized/lead-time-analysis/lead-time-bar-chart.component';
import { LeadTimeStackedBarComponent } from 'app/customized/lead-time-analysis/lead-time-stacked-bar.component';
import { LeadTimeChartsComponent } from 'app/customized/lead-time-analysis/lead-time-charts.component';
import { LeadTimeTableauComponent } from 'app/customized/lead-time-analysis/lead-time-tableau.component';

@Injectable()
export class LeadTimeAdService {
    constructor() {}

    getComponent(componentName: string, data1: any, data2: any, linkName: string) {
        if (componentName === 'LeadTimeChartsComponent') {
            return new AdItem(LeadTimeChartsComponent, { leadTimeData: data1, rawBoxPlotData: data2, chosenLink: linkName });
        }
        if (componentName === 'LeadTimeTableauComponent') {
            return new AdItem(LeadTimeTableauComponent, { dashboardName: data1, link: linkName });
        }
    }
}
