import { IVsDashboardTag } from '../vs-dashboard-tag/vs-dashboard-tag.model';

export interface ILeadTimeReportData {
    disName?: string;
    avg?: number;
    barName?: string;
    barVal?: number;
    dur?: number;
    ttnr?: string;
    dlz?: string;
    durchschnittsbestand?: number;
}

export class LeadTimeReportData implements ILeadTimeReportData {
    constructor(
        public disName?: string,
        public avg?: number,
        public barName?: string,
        public barVal?: number,
        public dur?: number,
        public ttnr?: string,
        public dlz?: string,
        public durchschnittsbestand?: number
    ) {}
}
