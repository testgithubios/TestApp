import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

import { SERVER_API_URL } from 'app/app.constants';
import { createRequestOption } from 'app/shared';
import { IVsLeadTimeLink } from './lead-time-analysis-link.model';
import { LeadTimeReportData, ILeadTimeReportData } from 'app/customized/lead-time-analysis/lead-time-report-data.model';

type EntityResponseType = HttpResponse<IVsLeadTimeLink>;
type EntityArrayResponseType = HttpResponse<IVsLeadTimeLink[]>;

@Injectable()
export class VsLeadTimeLinkService {
    public resourceUrl = SERVER_API_URL + 'vsd/api/lead-time-links';
    public resourceSearchUrl = SERVER_API_URL + 'vsd/api/_search/lead-time-links';

    constructor(private http: HttpClient) {}

    find(id: number): Observable<EntityResponseType> {
        return this.http.get<IVsLeadTimeLink>(`${this.resourceUrl}/${id}`, { observe: 'response' });
    }

    query(req?: any): Observable<EntityArrayResponseType> {
        const options = createRequestOption(req);
        return this.http.get<IVsLeadTimeLink[]>(this.resourceUrl, { params: options, observe: 'response' });
    }

    getLeadTimeForBarChart(): Observable<HttpResponse<ILeadTimeReportData[]>> {
        return this.http.get<ILeadTimeReportData[]>('vsd/api/lead-time-reports-bar-chart', { observe: 'response' });
    }

    getLeadTimeForBoxPlot(): Observable<HttpResponse<ILeadTimeReportData[]>> {
        return this.http.get<ILeadTimeReportData[]>('vsd/api/lead-time-reports-box-plot', { observe: 'response' });
    }
}
