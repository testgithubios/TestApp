import { Component, Input, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
    selector: 'jhi-lead-time-tableau',
    templateUrl: './lead-time-tableau.component.html',
    encapsulation: ViewEncapsulation.None
})
export class LeadTimeTableauComponent implements OnInit, OnDestroy {
    @Input()
    data;

    public dashboardName: string;
    public link: string;

    constructor() {}

    ngOnInit() {
        this.dashboardName = this.data.dashboardName;
        this.link = this.data.link;

        const node = document.createElement('script');
        node.src = 'https://rb-ps-tableau.bosch.com/javascripts/api/viz_v1.js';
        node.type = 'text/javascript';
        node.async = false;
        node.charset = 'utf-8';
        document.getElementsByTagName('head')[0].appendChild(node);
    }

    ngOnDestroy() {
        const imports = document.getElementsByTagName('script');
        const head = document.getElementsByTagName('head')[0];
        for (let i = 0; i < imports.length; i++) {
            if ((<HTMLScriptElement>imports[i]).src === 'https://rb-ps-tableau.bosch.com/javascripts/api/viz_v1.js') {
                head.removeChild(imports[i]);
            }
        }
    }
}
