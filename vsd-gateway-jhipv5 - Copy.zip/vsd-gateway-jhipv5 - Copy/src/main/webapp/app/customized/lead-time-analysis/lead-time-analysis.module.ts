import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import {
    LeadTimeAnalysisComponent,
    VsLeadTimeLinkService,
    LeadTimeBarChartComponent,
    LeadTimeTableauComponent,
    LeadTimeAdService
} from './index';
import { VsdGatewaySharedModule } from 'app/shared';
import { MatInputModule, MatSliderModule, MatSlideToggleModule, MatAutocompleteModule } from '@angular/material';
import { VsdGatewaySharedDirectives } from 'app/shared/share-directives.module';
import { LeadTimeStackedBarComponent } from 'app/customized/lead-time-analysis/lead-time-stacked-bar.component';
import { LeadTimeChartsComponent } from 'app/customized/lead-time-analysis/lead-time-charts.component';
import { LeadTimeBoxPlotComponent } from 'app/customized/lead-time-analysis/lead-time-box-plot-chart.component';

@NgModule({
    imports: [
        VsdGatewaySharedModule,
        MatSliderModule,
        MatSlideToggleModule,
        MatInputModule,
        MatAutocompleteModule,
        VsdGatewaySharedDirectives
    ],
    declarations: [
        LeadTimeAnalysisComponent,
        LeadTimeChartsComponent,
        LeadTimeBarChartComponent,
        LeadTimeTableauComponent,
        LeadTimeStackedBarComponent,
        LeadTimeBoxPlotComponent
    ],
    entryComponents: [
        LeadTimeChartsComponent,
        LeadTimeBarChartComponent,
        LeadTimeStackedBarComponent,
        LeadTimeTableauComponent,
        LeadTimeBoxPlotComponent
    ],
    providers: [VsLeadTimeLinkService, LeadTimeAdService],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class VsdGatewayLeadTimeAnalysisModule {}
