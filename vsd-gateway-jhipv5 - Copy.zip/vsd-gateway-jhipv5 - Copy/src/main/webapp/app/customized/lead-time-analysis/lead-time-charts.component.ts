import { Component, OnInit, Input, ElementRef, EventEmitter, ViewEncapsulation } from '@angular/core';
import { VsLeadTimeLinkService } from 'app/customized/lead-time-analysis/lead-time-analysis-link.service';

@Component({
    selector: 'jhi-lead-time-charts',
    templateUrl: './lead-time-charts.component.html',
    styleUrls: ['lead-time-charts.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class LeadTimeChartsComponent implements OnInit {
    @Input()
    public data: any;

    private link: string;
    public leadTimeData: any;
    public disponents = [];
    public barDatasEmitter: EventEmitter<any[]> = new EventEmitter();
    public boxPlotDataEmitter: EventEmitter<any[]> = new EventEmitter();
    public chartDataInit: any;
    public boxPlotRawData: any;
    public boxPlotDataInit: any;

    constructor(private container: ElementRef, private leadTimeAnalysisLinkService: VsLeadTimeLinkService) {}

    ngOnInit() {
        this.link = this.data.chosenLink;
        this.leadTimeData = this.data.leadTimeData;
        this.boxPlotRawData = this.data.rawBoxPlotData;
        const disponentNames = Array.from(new Set(this.leadTimeData.map(d => d.disName)));
        const disponents = [];
        this.disponents = disponentNames.map(name => {
            const obj = { disName: name, selected: false };
            if (name === this.link) {
                obj.selected = true;
            }
            return obj;
        });

        this.chartDataInit = this.getFilteredData(this.leadTimeData);
        this.boxPlotDataInit = this.getFilteredData(this.boxPlotRawData);
    }

    getFilteredData(chartData) {
        const selecteds = this.disponents.filter(val => val.selected);
        return chartData.filter(data => {
            return selecteds.find(selected => {
                return data.disName === selected.disName;
            });
        });
    }

    renderChart() {
        this.barDatasEmitter.emit(this.getFilteredData(this.leadTimeData));
        this.boxPlotDataEmitter.emit(this.getFilteredData(this.boxPlotRawData));
    }
}
