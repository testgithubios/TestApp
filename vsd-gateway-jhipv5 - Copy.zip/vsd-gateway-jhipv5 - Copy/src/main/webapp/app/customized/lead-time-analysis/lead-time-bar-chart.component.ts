import { AfterViewInit, Component, EventEmitter, ElementRef, Input, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import * as d3 from 'd3';
import { COLOR_ARRAY } from 'app/customized/lead-time-analysis/color-array';

@Component({
    selector: 'jhi-lead-time-bar-chart',
    templateUrl: './lead-time-bar-chart.component.html',
    styleUrls: ['lead-time-bar-chart.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class LeadTimeBarChartComponent implements OnInit {
    @ViewChild('barchart')
    private barChartContainer: ElementRef;

    // Get data updated from filter
    @Input()
    barChartData: EventEmitter<any[]>;

    // Get data from lead-time-charts after initializing
    @Input()
    dataInit: any;

    private colors = COLOR_ARRAY;
    constructor() {}

    ngOnInit() {
        if (this.barChartData) {
            this.barChartData.subscribe(data => {
                this.renderBarChart(data);
            });
        }

        if (this.dataInit) {
            this.renderBarChart(this.dataInit);
        }
    }

    renderBarChart(barData: any[]) {
        d3.select('#svg-bar').remove();
        if (!barData || barData.length === 0) {
            return;
        }
        // initialize basic value
        const barChartElm = this.barChartContainer.nativeElement;
        const mrgTop = 100;
        const mrgBottom = 100;
        const mrgLeft = 35;
        const mrgRight = 20;
        const BOTTOM_HEIGHT = 70;
        const MRG_Y_LABEL = 20;
        const elementWidth = barChartElm.offsetWidth;
        const elementHeight = barChartElm.offsetHeight;
        const contentWidth = elementWidth - mrgLeft - mrgRight;
        const contentHeight = elementHeight - mrgTop - mrgBottom;
        const MAX_VAL = d3.max(barData, d => d.barVal) === 0 ? 1 : d3.max(barData, d => d.barVal);
        const DIS_ARR = Array.from(new Set(barData.map(d => d.disName)));

        const distinctDur = Array.from(new Set(barData.map(d => '' + d.dur)));
        const colors = this.colors.slice(0, distinctDur.length);
        const colorScale = d3
            .scaleOrdinal()
            .range(colors)
            .domain(distinctDur);

        const svg = d3
            .select(barChartElm)
            .append('svg')
            .attr('id', 'svg-bar')
            .attr('width', '100%')
            .attr('height', elementHeight);
        svg.append('text')
            .text('Mittelwertentwicklung')
            .attr('class', 'title')
            .attr('x', 20)
            .attr('y', 30);

        const tooltip = d3
            .select('#barchart')
            .append('div')
            .attr('class', 'tooltip')
            .style('opacity', 0);

        const dis_x_axis = d3
            .scaleBand()
            .rangeRound([0, contentWidth])
            .padding(0)
            .domain(
                barData.map(d => {
                    return d.disName;
                })
            );

        const x_axis = d3
            .scaleBand()
            .range([0, contentWidth])
            .paddingOuter(0)
            .paddingInner(0.25)
            .domain(
                barData.map(d => {
                    return d.disName + d.barName;
                })
            );

        const y_axis = d3
            .scaleLinear()
            .rangeRound([contentHeight, 0])
            .domain([0, MAX_VAL]);

        const x_axis_gr = d3
            .scaleLinear()
            .rangeRound([0, contentWidth])
            .domain([0, DIS_ARR.length]);

        const y_axis_gr = d3
            .scaleLinear()
            .rangeRound([contentHeight, 0])
            .domain([0, MAX_VAL]);

        const main_g = svg.append('g').attr('transform', 'translate(' + mrgLeft + ',' + mrgTop + ')');

        main_g
            .append('g')
            .attr('class', 'axis_top')
            .attr('transform', 'translate(-1,-20)')
            .call(d3.axisTop(dis_x_axis));

        const y_grid_data = Array.from(Array(DIS_ARR.length).keys());
        y_grid_data.shift();
        main_g
            .selectAll('.y_line')
            .data(y_grid_data)
            .enter()
            .append('line')
            .attr('class', 'y_line')
            .attr('x1', d => x_axis_gr(d))
            .attr('y1', -20)
            .attr('x2', d => x_axis_gr(d))
            .attr('y2', contentHeight);
        main_g
            // .selectAll('.rear_y_line')
            // .data([0, y_grid_data[y_grid_data.length - 1] + 1])
            // .enter()
            .append('line')
            .attr('class', 'rear_y_line')
            .attr('x1', 0)
            .attr('y1', -50)
            .attr('x2', 0)
            .attr('y2', contentHeight + BOTTOM_HEIGHT);
        main_g
            .append('line')
            .attr('class', 'rear_y_line')
            .attr('x1', contentWidth)
            .attr('y1', -50)
            .attr('x2', contentWidth)
            .attr('y2', contentHeight + BOTTOM_HEIGHT);

        const x_grid_data = Array.from(Array(Math.ceil(MAX_VAL / 10)).keys());
        main_g
            .selectAll('.x_line')
            .data(x_grid_data)
            .enter()
            .append('line')
            .attr('class', 'x_line')
            .attr('x1', 0)
            .attr('y1', d => y_axis_gr(d * 10))
            .attr('x2', contentWidth)
            .attr('y2', d => y_axis_gr(d * 10));
        main_g
            .selectAll('.y_label')
            .data(x_grid_data)
            .enter()
            .append('text')
            .text(d => d * 10)
            .attr('class', 'y_label')
            .attr('x', -MRG_Y_LABEL)
            .attr('y', d => y_axis_gr(d * 10) + 5);

        main_g
            .append('text')
            .text('Disponent / Zeitraum')
            .attr('class', 'x_title')
            .attr('x', contentWidth / 2 - mrgLeft)
            .attr('y', -50);

        main_g
            .append('text')
            .text('Stufendurchschnitt')
            .attr('class', 'y_title')
            .attr('x', -(contentHeight / 2 + 50))
            .attr('y', -22)
            .attr('transform', 'rotate(-90)');

        const barGroups = main_g
            .selectAll('.bar_group')
            .data(barData)
            .enter()
            .append('g');

        barGroups
            .append('rect')
            .attr('class', d => 'bar bar' + d.dur)
            .attr('x', d => x_axis(d.disName + d.barName))
            .attr('y', d => y_axis(d.barVal))
            .attr('width', x_axis.bandwidth())
            .attr('height', d => contentHeight - y_axis(d.barVal))
            .style('fill', (d: any) => {
                return '' + colorScale(d.dur);
            })
            .on('mouseover', d => {
                tooltip
                    .transition()
                    .duration(200)
                    .style('opacity', 1)
                    .style('left', d3.event.pageX + 10 + 'px')
                    .style('top', d3.event.pageY + 10 + 'px')
                    .style('z-index', 9);
                tooltip.html(
                    `<table>
                  <tr>
                    <td>Zeitraum:</td>
                    <td>${d.barName}</td>
                  </tr>
                  <tr>
                    <td>Disponent:</td>
                    <td>${d.disName}</td>
                  </tr>
                  <tr>
                    <td>Tage:</td>
                    <td>${d.dur}</td>
                  </tr>
                  <tr>
                    <td>Stufendurchschnitt:</td>
                    <td>${d.barVal}</td>
                  </tr>
                </table>`
                );
            })
            // .on('mousemove', d => {})
            .on('mouseout', d => {
                tooltip
                    .transition()
                    .duration(500)
                    .style('opacity', 0)
                    .style('z-index', -1);
            });

        barGroups
            .append('text')
            .text(d => d.barName)
            .attr('class', 'bt_label')
            .attr('x', -contentHeight - BOTTOM_HEIGHT)
            .attr('y', d => x_axis(d.disName + d.barName) + (x_axis.bandwidth() / 2 + 5))
            .attr('transform', 'rotate(-90)');
    }
}
