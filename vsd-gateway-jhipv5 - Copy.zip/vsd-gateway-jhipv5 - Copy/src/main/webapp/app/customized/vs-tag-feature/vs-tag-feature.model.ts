import { IVsDashboardTag } from 'app/customized/vs-dashboard-tag';

export interface IVsTagFeature {
    id?: number;
    featureId?: number;
    featureLink?: string;
    valueStreamTagId?: number;
}

export class VsTagFeature implements IVsTagFeature {
    constructor(public id?: number, public featureId?: number, public featureLink?: string, public valueStreamTagId?: number) {}
}
