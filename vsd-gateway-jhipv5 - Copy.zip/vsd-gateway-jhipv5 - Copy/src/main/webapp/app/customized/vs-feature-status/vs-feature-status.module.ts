import { NgModule } from '@angular/core';
import { VsFeatureStatusService } from 'app/customized/vs-feature-status/vs-feature-status.service';

@NgModule({
    imports: [],
    declarations: [],
    entryComponents: [],
    providers: [VsFeatureStatusService],
    schemas: []
})
export class CustomFeatureStatusModule {}
