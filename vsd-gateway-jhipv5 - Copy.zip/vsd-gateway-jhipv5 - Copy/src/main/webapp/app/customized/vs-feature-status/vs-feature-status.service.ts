import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { createRequestOption } from 'app/shared';
import { SERVER_API_URL } from 'app/app.constants';

@Injectable()
export class VsFeatureStatusService {
    public resourceUrl = SERVER_API_URL + 'vsd/api/feature-statuses/status';

    constructor(private http: HttpClient) {}

    getStatus(featureId: number, featureType: string): Observable<HttpResponse<string>> {
        const options = createRequestOption({ featureId, featureType });
        return this.http.get(this.resourceUrl, { responseType: 'text', params: options, observe: 'response' });
    }
}
