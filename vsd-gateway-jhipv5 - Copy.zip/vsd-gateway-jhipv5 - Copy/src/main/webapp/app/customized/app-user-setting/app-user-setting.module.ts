import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { AppUserSettingService, AppUserSettingRoute, UserAppSettingComponent } from './index';

import { NgSelectModule } from '@ng-select/ng-select';
import { MaterialModule } from './user-setting-material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { VsdGatewaySharedModule } from 'app/shared';

const ENTITY_STATES = [...AppUserSettingRoute];

@NgModule({
    imports: [
        VsdGatewaySharedModule,
        RouterModule.forRoot(ENTITY_STATES, { useHash: true }),
        NgSelectModule,
        MaterialModule,
        FormsModule,
        ReactiveFormsModule
    ],
    declarations: [UserAppSettingComponent],
    entryComponents: [],
    providers: [AppUserSettingService],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class VsdGatewayAppUserSettingModule {}
