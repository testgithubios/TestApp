import { ChangeDetectorRef, Component, OnInit, ViewEncapsulation } from '@angular/core';
import { JhiAlertService, JhiEventManager, JhiLanguageService } from 'ng-jhipster';

import { AppUserSetting, IAppUserSetting } from './app-user-setting.model';
import { AppUserSettingService } from './app-user-setting.service';

import { Router } from '@angular/router';
import { VsProductFamily, VsProductFamilyService } from '../vs-product-family';
import { debounceTime, distinctUntilChanged, map, switchMap } from 'rxjs/operators';

import { VsDashboardService } from '../vs-dashboard/vs-dashboard.service';
import { of, Subject } from 'rxjs';
import { EMAIL } from 'app/shared/constants/email.constants';
import { IPlant, Plant } from 'app/shared/model/vsd/plant.model';
import { JhiLanguageHelper, Principal } from 'app/core';
import { PlantService } from 'app/entities/vsd/plant';
import { HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { IProductFamily } from 'app/shared/model/vsd/product-family.model';

@Component({
    selector: 'jhi-app-user-setting',
    templateUrl: './user-app-setting.component.html',
    styleUrls: ['./user-app-setting.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class UserAppSettingComponent implements OnInit {
    error: string;
    success: string;
    settingsAccount: any;
    userSetting: AppUserSetting;
    plants: Plant[];
    emails: string = EMAIL;
    isSaving = false;
    userName: string;
    vsNames: string[];

    productFamilies: VsProductFamily[] = [];
    typingHandler$ = new Subject<string>();

    // workaround as ng-select does not allow free text
    tempTerm: any;
    public languages: any;

    constructor(
        private languageHelper: JhiLanguageHelper,
        private languageService: JhiLanguageService,
        private principal: Principal,
        private userSettingService: AppUserSettingService,
        private jhiAlertService: JhiAlertService,
        private plantService: PlantService,
        private eventManager: JhiEventManager,
        private router: Router,
        private productFamilyService: VsProductFamilyService,
        private vsDashboardService: VsDashboardService,
        private cd: ChangeDetectorRef
    ) {}

    ngOnInit() {
        this.languageHelper.getAll().then(languages => {
            this.languages = languages;
        });

        this.typingHandler$
            .pipe(
                distinctUntilChanged(),
                debounceTime(500),
                switchMap((term: string) => {
                    this.tempTerm = term;
                    return term && term.trim()
                        ? this.productFamilyService.filterByProductName({ query: 'name:*' + term.trim() + '*' }).pipe(map(res => res.body))
                        : of([]);
                })
            )
            .subscribe(
                (res: IProductFamily[]) => {
                    this.cd.markForCheck();
                    this.productFamilies = res;
                    // add a temp item so user can choose
                    if (this.tempTerm && this.tempTerm.trim()) {
                        this.productFamilies.push({ id: 1, refId: 1, name: this.tempTerm });
                    }
                },
                err => {
                    console.log(err);
                    this.productFamilies = [];
                }
            );

        this.principal.identity().then(account => {
            this.userName = account.login;
            this.settingsAccount = this.copyAccount(account);
            this.loadAllSettings();
        });
        this.plantService.query().subscribe(
            (res: HttpResponse<IPlant[]>) => {
                this.plants = res.body;
            },
            (res: HttpErrorResponse) => this.onError(res.message)
        );
        this.vsDashboardService.getAllVsName().subscribe((res: HttpResponse<string[]>) => {
            this.vsNames = res.body;
        });
    }

    save() {
        this.isSaving = true;
        if (this.userSetting.id) {
            this.userSettingService.update(this.userSetting).subscribe(res => {
                this.isSaving = false;
                this.eventManager.broadcast({ name: 'userSettingModification', content: 'update user settings' });
                this.router.navigate(['/vs-dashboard']);
            });
        } else {
            this.userSettingService.create(this.userSetting).subscribe(res => {
                this.isSaving = false;
                this.eventManager.broadcast({ name: 'userSettingModification', content: 'update user settings' });
                this.router.navigate(['/vs-dashboard']);
            });
        }
    }

    copyAccount(account) {
        return {
            activated: account.activated,
            email: account.email,
            firstName: account.firstName,
            langKey: account.langKey,
            lastName: account.lastName,
            login: account.login,
            imageUrl: account.imageUrl
        };
    }

    loadAllSettings() {
        this.userSettingService
            .findByUserName(this.settingsAccount.login)
            .subscribe(
                (res: HttpResponse<IAppUserSetting>) => this.onSuccess(res.body),
                (res: HttpErrorResponse) => this.onError(res.message)
            );
    }

    private onSuccess(data) {
        this.eventManager.broadcast({ name: 'userSettingModification', content: 'update user settings' });
        if (data) {
            this.userSetting = data;
            this.userSetting.email = this.settingsAccount.email;
        } else {
            this.userSetting = new AppUserSetting();
            this.userSetting.email = this.settingsAccount.email;
            this.userSetting.userName = this.settingsAccount.login;
        }
    }

    private onError(errorMessage: string) {
        console.log(errorMessage);
    }

    trackId(index: number, item: AppUserSetting) {
        return item.id;
    }

    trackPlantById(index: number, item: Plant) {
        return item.id;
    }
}
