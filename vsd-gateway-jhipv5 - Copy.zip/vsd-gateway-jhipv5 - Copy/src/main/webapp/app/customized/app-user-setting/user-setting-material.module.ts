import { NgModule } from '@angular/core';
import { MatButtonModule, MatDialogModule, MatInputModule, MatFormFieldModule, MatSelectModule } from '@angular/material';

@NgModule({
    exports: [MatButtonModule, MatDialogModule, MatInputModule, MatFormFieldModule, MatSelectModule]
})
export class MaterialModule {}
