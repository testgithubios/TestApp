export interface IAppUserSetting {
    id?: number;
    userName?: string;
    defaultPlant?: string;
    defaultProductFamily?: string;
    favoriteValueStream?: string;
    defaultLanguage?: string;
    email?: string;
}

export class AppUserSetting implements IAppUserSetting {
    constructor(
        public id?: number,
        public userName?: string,
        public defaultPlant?: string,
        public defaultProductFamily?: string,
        public favoriteValueStream?: string,
        public defaultLanguage?: string,
        public email?: string
    ) {}
}
