import { Routes } from '@angular/router';

import { UserAppSettingComponent } from './user-app-setting.component';
import { UserRouteAccessService } from 'app/core';

export const AppUserSettingRoute: Routes = [
    {
        path: 'user-app-setting',
        component: UserAppSettingComponent,
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdUserSetting.home.title'
        },
        canActivate: [UserRouteAccessService]
    }
];
