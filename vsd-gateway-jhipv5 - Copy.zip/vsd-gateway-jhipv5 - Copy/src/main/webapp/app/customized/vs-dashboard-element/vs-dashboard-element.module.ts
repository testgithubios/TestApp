import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { VsdGatewaySharedModule } from 'app/shared';
import { VsDashboardElementService } from './vs-dashboard-element.service';

const ENTITY_STATES = [];

@NgModule({
    imports: [VsdGatewaySharedModule, RouterModule.forRoot(ENTITY_STATES, { useHash: true })],
    declarations: [],
    entryComponents: [],
    providers: [VsDashboardElementService],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class VsdGatewayVsDashboardElementModule {}
