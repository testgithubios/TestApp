import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

import { SERVER_API_URL } from 'app/app.constants';
import { createRequestOption } from 'app/shared';
import { IVsDashboardElement } from './vs-dashboard-element.model';

type EntityResponseType = HttpResponse<IVsDashboardElement>;
type EntityArrayResponseType = HttpResponse<IVsDashboardElement[]>;

@Injectable()
export class VsDashboardElementService {
    public resourceUrl = SERVER_API_URL + 'vsd/api/value-stream-elements';
    public resourceSearchUrl = SERVER_API_URL + 'vsd/api/_search/value-stream-elements';

    constructor(private http: HttpClient) {}

    create(valueStreamElement: IVsDashboardElement): Observable<EntityResponseType> {
        return this.http.post<IVsDashboardElement>(this.resourceUrl, valueStreamElement, { observe: 'response' });
    }

    update(valueStreamElement: IVsDashboardElement): Observable<EntityResponseType> {
        return this.http.put<IVsDashboardElement>(this.resourceUrl, valueStreamElement, { observe: 'response' });
    }

    find(id: number): Observable<EntityResponseType> {
        return this.http.get<IVsDashboardElement>(`${this.resourceUrl}/${id}`, { observe: 'response' });
    }

    query(req?: any): Observable<EntityArrayResponseType> {
        const options = createRequestOption(req);
        return this.http.get<IVsDashboardElement[]>(this.resourceUrl, { params: options, observe: 'response' });
    }

    delete(id: number): Observable<HttpResponse<any>> {
        return this.http.delete<any>(`${this.resourceUrl}/${id}`, { observe: 'response' });
    }

    search(req?: any): Observable<EntityArrayResponseType> {
        const options = createRequestOption(req);
        return this.http.get<IVsDashboardElement[]>(this.resourceSearchUrl, { params: options, observe: 'response' });
    }

    getNames(): Observable<HttpResponse<string[]>> {
        const url = this.resourceUrl + '/names';
        return this.http.get<string[]>(url, { observe: 'response' });
    }
}
