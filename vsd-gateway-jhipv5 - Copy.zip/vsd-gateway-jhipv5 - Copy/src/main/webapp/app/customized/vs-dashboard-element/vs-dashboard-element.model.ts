import { IValueStreamElementLink } from '../vs-dashboard-element-link/vs-dashboard-element-link.model';
import { IVsDashboardTag } from '../vs-dashboard-tag/vs-dashboard-tag.model';

export interface IVsDashboardElement {
    id?: number;
    vsElementName?: string;
    valueStreamTags?: IVsDashboardTag[];
    valueStreamElementLinks?: IValueStreamElementLink[];
}

export class VsDashboardElement implements IVsDashboardElement {
    constructor(
        public id?: number,
        public vsElementName?: string,
        public valueStreamTags?: IVsDashboardTag[],
        public valueStreamElementLinks?: IValueStreamElementLink[]
    ) {}
}
