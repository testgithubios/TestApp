import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { LicensesRoute, LicensesComponent } from './index';
import { VsdGatewaySharedModule } from 'app/shared';

const ENTITY_STATES = [...LicensesRoute];

@NgModule({
    imports: [VsdGatewaySharedModule, RouterModule.forRoot(ENTITY_STATES, { useHash: true })],
    declarations: [LicensesComponent],
    entryComponents: [],
    providers: [],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class VsdGatewayLicenseModule {}
