import { Route, Routes } from '@angular/router';
import { LicensesComponent } from './licenses.component';
import { UserRouteAccessService } from 'app/core';

export const LicensesRoute: Routes = [
    {
        path: 'licenses',
        component: LicensesComponent,
        data: {
            authorities: [],
            pageTitle: 'license.title'
        },
        canActivate: [UserRouteAccessService]
    }
];
