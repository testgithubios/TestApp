import { Component, OnInit, AfterViewInit, Renderer, ElementRef } from '@angular/core';
import { NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { JhiLanguageService } from 'ng-jhipster';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
    selector: 'jhi-licenses',
    templateUrl: './licenses.component.html',
    styleUrls: ['licenses.scss']
})
export class LicensesComponent implements OnInit {
    licenseData: string;
    isShow = false;
    constructor(private router: Router, private http: HttpClient) {}

    ngOnInit() {
        this.loadLicensesDataFromTxt();
    }

    loadLicensesDataFromTxt() {
        this.http.get('licenses.txt', { responseType: 'text' }).subscribe(data => {
            console.log(data);
            this.licenseData = data;
            this.isShow = true;
        });
    }
}
