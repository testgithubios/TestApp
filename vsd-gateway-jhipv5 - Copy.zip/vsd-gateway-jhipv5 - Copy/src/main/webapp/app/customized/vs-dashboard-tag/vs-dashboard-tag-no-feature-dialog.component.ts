import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Component, OnInit, Inject, ViewEncapsulation, ViewChild, ComponentFactoryResolver } from '@angular/core';
import { Router } from '@angular/router';
import { VsDashboardTag, IVsDashboardTag } from './vs-dashboard-tag.model';
import { VsDashboardTagService } from './vs-dashboard-tag.service';
import { JhiAlertService, JhiParseLinks, JhiEventManager } from 'ng-jhipster';
import { VsTagFeature } from '../vs-tag-feature/vs-tag-feature.model';
import { VsTagFeatureService } from '../vs-tag-feature/vs-tag-feature.service';
import { Principal } from 'app/core';
import { JhiConfigurationService } from 'app/admin';
import { EMAIL_SNR, EMAIL_SUBJECT_NO_FEATURE } from 'app/shared/constants/email.constants';
import { HttpResponse } from '@angular/common/http';
import { VsDashboardElement } from 'app/customized/vs-dashboard-element/vs-dashboard-element.model';
import { NON_ELEMENTS, EAGER_LOAD, NON_LINKS, NON_FEATURES } from 'app/shared/constants/common.constants';

@Component({
    selector: 'jhi-vs-dashboard-tag-no-feature-dialog',
    templateUrl: './vs-dashboard-tag-no-feature-dialog.component.html',
    styleUrls: ['./vs-dashboard-tag-no-feature-dialog.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class VsDashboardTagNoFeatureDialogComponent implements OnInit {
    elementTypeName: string;
    tagName: string;
    menu: any;
    valueStreamTag: VsDashboardTag;
    vsElementName: string;

    email: string;
    subject: string;

    constructor(
        public dialogRef: MatDialogRef<VsDashboardTagNoFeatureDialogComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any,
        private principal: Principal,
        private router: Router,
        private jhiAlertService: JhiAlertService,
        private vsDashboardTagService: VsDashboardTagService,
        private parseLinks: JhiParseLinks,
        private eventManager: JhiEventManager,
        private configurationService: JhiConfigurationService
    ) {
        this.email = EMAIL_SNR;
        this.subject = EMAIL_SUBJECT_NO_FEATURE;
    }

    ngOnInit() {
        this.configurationService.getMenu().subscribe(menuprop => {
            this.menu = menuprop.body;
        });
        this.loadValueStreamTag(this.data.selectedTag.id);
    }

    closeDialog(): void {
        this.dialogRef.close();
    }

    loadValueStreamTag(id) {
        // eager load
        this.vsDashboardTagService
            .findOne(id, NON_ELEMENTS, NON_LINKS, NON_FEATURES, EAGER_LOAD)
            .subscribe((res: HttpResponse<IVsDashboardTag>) => {
                const valueStreamTag = res.body;
                this.valueStreamTag = valueStreamTag;
                this.tagName = valueStreamTag.tagName;
                const valueStreamElement: VsDashboardElement = valueStreamTag.valueStreamElements[0];
                this.elementTypeName = valueStreamElement.vsElementName;
                this.vsElementName = this.elementTypeName;
            });
    }
}
