import { SharedService } from './../../../shared/shared-service';
import { VsDashboardService } from './../../vs-dashboard/vs-dashboard.service';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { JhiAlertService, JhiEventManager } from 'ng-jhipster';
import { VsDashboardTagService } from '../vs-dashboard-tag.service';
import { DomSanitizer } from '@angular/platform-browser';
import { VsTagFeature } from '../../vs-tag-feature/vs-tag-feature.model';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { Line, ILine } from 'app/shared/model/vsd/line.model';
import { LineService } from 'app/entities/vsd/line';
import { OPERATOR_VIEW_FEATURE } from 'app/shared/constants/featurelink.constants';
import { LINE } from 'app/shared/constants/common.constants';
import { VsTagFeatureService, IVsTagFeature } from 'app/customized/vs-tag-feature';
import { VsFeatureStatusService } from 'app/customized/vs-feature-status/vs-feature-status.service';
import { EnvService } from 'app/env.service';

@Component({
    selector: 'jhi-operator-view-feature',
    templateUrl: './operator-view-feature.component.html',
    styleUrls: ['./operator-view-feature.component.scss']
})
export class OperatorViewFeatureComponent implements OnInit {
    public line: Line;
    public url: string;
    public isSaving = false;
    private envId: string;
    @Input()
    private data: any;
    private valueStreamTagId: number;
    public showLines = false;

    // Params for loading Lines
    public lines = [];
    private sizePerPage = 40;
    private size;
    private page: number;
    public last: number;
    public totalItems;

    @Output()
    operatorViewStatus = new EventEmitter<string>();

    @Output()
    isDisplayLinkOperator = new EventEmitter<boolean>();

    @Output()
    chosenLineNameOperator = new EventEmitter<string>();

    constructor(
        private activatedRoute: ActivatedRoute,
        private vsDashboardService: VsDashboardService,
        private vsDashboardTagService: VsDashboardTagService,
        private lineService: LineService,
        private jhiAlertService: JhiAlertService,
        public sanitizer: DomSanitizer,
        private tagFeatureService: VsTagFeatureService,
        private eventManager: JhiEventManager,
        private vsFeatureStatusService: VsFeatureStatusService,
        private _sharedService: SharedService,
        private envService: EnvService
    ) {
        _sharedService.changeEmitted$.subscribe(isShowLine => {
            if (isShowLine) {
                if (this.lines.length === 0) {
                    this.loadLines((this.page = 0), (this.size = this.sizePerPage));
                }
                this._sharedService.emitChange(false);
            }
        });
    }

    ngOnInit() {
        this.valueStreamTagId = this.data.tagId;
        this.load();
        this.envService.getDeploymentEnvironmentId().subscribe(res => {
            this.envId = res.body.substr(0, res.body.lastIndexOf(':'));
        });
    }

    load() {
        this.tagFeatureService
            .findByTagIdAndFeatureLink(this.valueStreamTagId, OPERATOR_VIEW_FEATURE)
            .subscribe((result: HttpResponse<IVsTagFeature>) => {
                const tagFeature: VsTagFeature = result.body;
                if (tagFeature != null && tagFeature.featureId != null) {
                    this.navigateOperatorView(tagFeature.featureId);
                } else {
                    if (this.lines.length === 0) {
                        this.loadLines((this.page = 0), (this.size = this.sizePerPage));
                    }
                    this.isDisplayLinkOperator.emit(false);
                }
            });
    }

    loadLines(pageParam, sizeParam) {
        this.showLines = true;
        this.lineService.query({ page: pageParam, size: sizeParam }).subscribe(
            (res: HttpResponse<Line[]>) => {
                this.lines = [...this.lines, ...res.body];
                this.totalItems = res.headers.get('X-Total-Count');
            },
            (res: HttpErrorResponse) => {
                this.jhiAlertService.error(res.message, null, null);
            }
        );
    }

    onScroll() {
        if (this.lines.length < this.totalItems) {
            this.loadLines(++this.page, this.size);
        }
    }

    navigateOperatorView(lineId) {
        this.lines = [];
        this.showLines = false;
        this.isDisplayLinkOperator.emit(true);
        this.lineService.find(lineId).subscribe((res: HttpResponse<ILine>) => {
            this.line = res.body;
            this.chosenLineNameOperator.emit(this.line.name);
            this.url = this.envId + '/#/station?lineId=' + this.line.lineId + '&embed=true';
        });
    }

    private sendStatusToTagFeatureDialog(status: string) {
        // Send status to the TagFeatureDialog
        this.operatorViewStatus.emit(status);
    }

    chooseLine(line) {
        this.lines = [];
        const tagFeature: IVsTagFeature = new VsTagFeature();
        tagFeature.featureId = line.id;
        tagFeature.valueStreamTagId = this.valueStreamTagId;
        tagFeature.featureLink = OPERATOR_VIEW_FEATURE;

        this.isSaving = true;
        this.tagFeatureService.createNewTagFeature(tagFeature).subscribe(
            (res: HttpResponse<IVsTagFeature>) => {
                this.navigateOperatorView(res.body.featureId);

                // Reload value-stream detail to see status updated
                this.eventManager.broadcast({ name: 'vsDashboardDetailModification', content: 'OK' });
                this.isSaving = false;

                // Load status to see updated status after chooseLine
                this.vsFeatureStatusService.getStatus(line.id, LINE).subscribe((statusRes: any) => {
                    this.sendStatusToTagFeatureDialog(statusRes.body.toLowerCase());
                });
            },
            (res: HttpErrorResponse) => {
                this.jhiAlertService.error(res.message, null, null);
                this.isSaving = false;
            }
        );
    }
}
