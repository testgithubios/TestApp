import { SharedService } from './../../shared/shared-service';
import { HeijunkaFeatureComponent } from './heijunka-board/heijunka-feature.component';
import { ALL_LINES, ALL_PROCESSES } from './../../shared/constants/common.constants';
import { KpiView } from './../../shared/model/vsd/kpi-view.model';
import { LeadTimeLink } from 'app/shared/model/vsd/lead-time-link.model';
import { IVsDashboard } from './../vs-dashboard/vs-dashboard.model';
import { VsRtAnalysisDetail } from './../vs-rt-analysis/vs-rt-analysis.model';

import { AdComponent } from './ad.component';
import { AdService } from './ad.service';
import { AdDirective } from './ad.directive';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Component, OnInit, Inject, ViewEncapsulation, ViewChild, ComponentFactoryResolver, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { VsDashboardTag, IVsDashboardTag } from './vs-dashboard-tag.model';
import { VsDashboardTagService } from './vs-dashboard-tag.service';
import { JhiAlertService, JhiParseLinks, JhiEventManager } from 'ng-jhipster';

import {
    HEIJUNKA_FEATURE,
    LEAD_TIME_FEATURE,
    READER_FEATURE,
    SNR,
    OPERATOR_VIEW_FEATURE,
    KPI_VIEW_FEATURE,
    RT_ANALYSIS,
    NO_PERMISSION
} from 'app/shared/constants/featurelink.constants';
import { VsTagFeature, IVsTagFeature } from '../vs-tag-feature/vs-tag-feature.model';
import { VsTagFeatureService } from '../vs-tag-feature/vs-tag-feature.service';
import { VsLeadTimeLink, VsLeadTimeLinkService } from 'app/customized/lead-time-analysis';
import { VsKpiView, VsKpiViewService } from 'app/customized/kpi-view';
import { Line, ILine } from 'app/shared/model/vsd/line.model';
import { Principal } from 'app/core';
import { LineService } from 'app/entities/vsd/line';
import { JhiConfigurationService } from 'app/admin';
import { VsDashboardElementLink } from '../vs-dashboard-element-link/vs-dashboard-element-link.model';
import { HttpResponse } from '@angular/common/http';
import { VsDashboardElement } from 'app/customized/vs-dashboard-element/vs-dashboard-element.model';
import { NON_ELEMENTS, NON_LINKS, NON_FEATURES, EAGER_LOAD, LINE, READER_NUMBER } from 'app/shared/constants/common.constants';
import { VsFeatureStatusService } from 'app/customized/vs-feature-status/vs-feature-status.service';

@Component({
    selector: 'jhi-vs-dashboard-tag-feature-dialog',
    templateUrl: './vs-dashboard-tag-feature-dialog.component.html',
    styleUrls: ['./vs-dashboard-tag-feature-dialog.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class VsDashboardTagFeatureDialogComponent implements OnInit {
    featuresConfig = {
        translator: { visible: false, locked: true },
        heijunka: { visible: false, locked: true },
        leadTimeAnalysis: { visible: false, locked: true },
        readerMonitor: { visible: false, locked: true },
        kpiView: { visible: false, locked: true },
        operatorView: { visible: false, locked: true },
        rtAnalysis: { visible: false, locked: true }
    };
    valueStreamTag: VsDashboardTag;
    tagFeatures: IVsTagFeature[];

    // For chosenFeature style
    public heijunkaFeatureName = HEIJUNKA_FEATURE;
    public operatorViewFeatureName = OPERATOR_VIEW_FEATURE;
    public kpiViewFeatureName = KPI_VIEW_FEATURE;
    public readerFeatureName = READER_FEATURE;
    public leadTimeFeatureName = LEAD_TIME_FEATURE;
    public rtAnalysisFeatureName = RT_ANALYSIS;
    public translatorFeatureName = SNR;

    // Update feature statuses
    heijunkaStatus;
    operatorViewStatus;
    readerMonitorStatus;
    isDisplayLink: boolean;

    last: number;
    totalItems;
    visibleFeatures: any;
    elementTypeName: string;
    menu: any;
    isLoadedFirstComponent = false;
    @ViewChild(AdDirective)
    adHost: AdDirective;

    isSaving = false;
    specificItem: string;
    allItem: string;

    chosenFeature: string;
    displayFeatureName: string;
    viewContainerRef;
    constructor(
        public dialogRef: MatDialogRef<VsDashboardTagFeatureDialogComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any,
        private principal: Principal,
        private router: Router,
        private jhiAlertService: JhiAlertService,
        private vsDashboardTagService: VsDashboardTagService,
        private lineService: LineService,
        private leadTimeService: VsLeadTimeLinkService,
        private kpiViewService: VsKpiViewService,
        private tagFeatureService: VsTagFeatureService,
        private parseLinks: JhiParseLinks,
        private eventManager: JhiEventManager,
        private configurationService: JhiConfigurationService,
        private componentFactoryResolver: ComponentFactoryResolver,
        private adService: AdService,
        private vsFeatureStatusService: VsFeatureStatusService,
        private _sharedService: SharedService
    ) {}

    ngOnInit() {
        this.configurationService.getMenu().subscribe(menuprop => {
            this.menu = menuprop.body;
            this.loadValueStreamTag(this.data.selectedTag.id);
        });
    }

    loadComponent(moduleName: string) {
        if (this.chosenFeature !== moduleName) {
            // Do not load feature if it is loaded already
            let adItem;
            switch (moduleName) {
                case LEAD_TIME_FEATURE: {
                    adItem = this.adService.getLeadTimeFeature(
                        this.data.selectedTag.id,
                        this.data.selectedValueStream.plantName,
                        this.data.selectedValueStream.valueStreamName
                    );
                    break;
                }
                default: {
                    adItem = this.adService.getAds(moduleName, this.data.selectedTag.id);
                    break;
                }
            }

            const componentFactory = this.componentFactoryResolver.resolveComponentFactory(adItem.component);

            this.viewContainerRef = this.adHost.viewContainerRef;
            this.viewContainerRef.clear();

            const componentRef = this.viewContainerRef.createComponent(componentFactory);
            (<AdComponent>componentRef.instance).data = adItem.data;

            switch (moduleName) {
                case RT_ANALYSIS: {
                    componentRef.instance.viewRTDetail.subscribe($event => {
                        this.viewContainerRef.clear();
                        this.loadRtAnalysisDetailComponent($event);
                    });
                    break;
                }
                case READER_FEATURE: {
                    componentRef.instance.readerMonitorStatus.subscribe($event => {
                        this.readerMonitorStatus = $event.toLowerCase();
                    });
                    break;
                }
                case HEIJUNKA_FEATURE: {
                    componentRef.instance.heijunkaStatus.subscribe($event => {
                        this.heijunkaStatus = $event.toLowerCase();
                    });
                    componentRef.instance.isDisplayLinkHeijunka.subscribe($event => {
                        this.isDisplayLink = $event;
                        this.allItem = ALL_LINES;
                    });
                    componentRef.instance.chosenLineNameHeijunka.subscribe($event => {
                        this.specificItem = $event;
                    });
                    break;
                }
                case OPERATOR_VIEW_FEATURE: {
                    componentRef.instance.operatorViewStatus.subscribe($event => {
                        this.operatorViewStatus = $event.toLowerCase();
                    });
                    componentRef.instance.isDisplayLinkOperator.subscribe($event => {
                        this.isDisplayLink = $event;
                        this.allItem = ALL_LINES;
                    });
                    componentRef.instance.chosenLineNameOperator.subscribe($event => {
                        this.specificItem = $event;
                    });
                    break;
                }
                case KPI_VIEW_FEATURE: {
                    componentRef.instance.isDisplayLinkKpiView.subscribe($event => {
                        this.isDisplayLink = $event;
                        this.allItem = ALL_PROCESSES;
                    });
                    componentRef.instance.chosenProcessNameKpiView.subscribe($event => {
                        this.specificItem = $event;
                    });
                    break;
                }
                case LEAD_TIME_FEATURE: {
                    componentRef.instance.isDisplayLinkLeadTime.subscribe($event => {
                        this.isDisplayLink = $event;
                        this.allItem = ALL_PROCESSES;
                    });
                    componentRef.instance.chosenProcessNameLeadTime.subscribe($event => {
                        this.specificItem = $event;
                    });
                    break;
                }
                default: {
                    break;
                }
            }

            this.chosenFeature = moduleName;
        }
    }

    loadRtAnalysisDetailComponent(viewInfo: VsRtAnalysisDetail[]) {
        const adItem = this.adService.getRtAnalysisDetail(viewInfo);
        const componentFactory = this.componentFactoryResolver.resolveComponentFactory(adItem.component);

        this.viewContainerRef = this.adHost.viewContainerRef;
        // this.viewContainerRef.clear(); This causes jerky scroll bar when switching from readerMonitor to rtAnalysis

        const componentRef = this.viewContainerRef.createComponent(componentFactory);
        (<AdComponent>componentRef.instance).data = adItem.data;

        componentRef.instance.backToRtAnalysisPage.subscribe($event => {
            this.rtAnalysisNavigation();
        });
    }

    clearComponent() {
        const viewContainerRef = this.adHost.viewContainerRef;
        viewContainerRef.clear();
    }

    loadFeatureConfig(visibleFeatures) {
        for (let i = 0; i < visibleFeatures.length; i++) {
            const vsEleLink = Object.assign(new VsDashboardElementLink(), visibleFeatures[i]);

            if (vsEleLink.featureLink === HEIJUNKA_FEATURE && this.menu && this.menu.enable_procon) {
                console.log('Heijunka');
                this.featuresConfig.heijunka.visible = true;
                const tagFeature: IVsTagFeature = this.tagFeatures
                    ? this.tagFeatures.find(tf => tf.featureLink === HEIJUNKA_FEATURE)
                    : null;
                if (tagFeature) {
                    this.vsFeatureStatusService.getStatus(tagFeature.featureId, LINE).subscribe((res: any) => {
                        this.heijunkaStatus = res.body.toLowerCase();
                    });
                }
                this.principal.hasAnyAuthority(['ROLE_ADMIN', 'ROLE_PROCESS_BOX']).then(response => {
                    this.featuresConfig.heijunka.locked = !response;
                    if (this.featuresConfig.heijunka.locked === false && this.isLoadedFirstComponent === false) {
                        this.heijunkaNavigation();
                        this.isLoadedFirstComponent = true;
                    }
                });
            }
            if (vsEleLink.featureLink === KPI_VIEW_FEATURE) {
                this.featuresConfig.kpiView.visible = true;
                this.principal.hasAnyAuthority(['ROLE_ADMIN', 'ROLE_PROCESS_BOX', 'ROLE_DATA_BOX']).then(response => {
                    this.featuresConfig.kpiView.locked = !response;
                    if (this.featuresConfig.kpiView.locked === false && this.isLoadedFirstComponent === false) {
                        this.kpiViewNavigation();
                        this.isLoadedFirstComponent = true;
                    }
                });
            }
            if (vsEleLink.featureLink === LEAD_TIME_FEATURE) {
                this.featuresConfig.leadTimeAnalysis.visible = true;
                this.principal.hasAnyAuthority(['ROLE_ADMIN', 'ROLE_LEAD_TIME']).then(response => {
                    this.featuresConfig.leadTimeAnalysis.locked = !response;
                    if (this.featuresConfig.leadTimeAnalysis.locked === false && this.isLoadedFirstComponent === false) {
                        this.leadTimeNavigation();
                        this.isLoadedFirstComponent = true;
                    }
                });
            }
            if (vsEleLink.featureLink === OPERATOR_VIEW_FEATURE && this.menu && this.menu.enable_procon) {
                this.featuresConfig.operatorView.visible = true;
                const tagFeature: IVsTagFeature = this.tagFeatures
                    ? this.tagFeatures.find(tf => tf.featureLink === OPERATOR_VIEW_FEATURE)
                    : null;
                if (tagFeature) {
                    this.vsFeatureStatusService.getStatus(tagFeature.featureId, LINE).subscribe((res: any) => {
                        this.operatorViewStatus = res.body.toLowerCase();
                    });
                }

                this.principal.hasAnyAuthority(['ROLE_ADMIN', 'ROLE_PROCESS_BOX']).then(response => {
                    this.featuresConfig.operatorView.locked = !response;
                    if (this.featuresConfig.operatorView.locked === false && this.isLoadedFirstComponent === false) {
                        this.operatorViewNavigation();
                        this.isLoadedFirstComponent = true;
                    }
                });
            }
            if (vsEleLink.featureLink === SNR) {
                this.featuresConfig.translator.visible = true;
                this.principal.hasAnyAuthority(['ROLE_ADMIN', 'ROLE_SNR_TRANSLATOR']).then(response => {
                    this.featuresConfig.translator.locked = !response;
                    if (this.featuresConfig.translator.locked === false && this.isLoadedFirstComponent === false) {
                        this.translatorNavigation();
                        this.isLoadedFirstComponent = true;
                    }
                });
            }
            if (vsEleLink.featureLink === READER_FEATURE) {
                this.featuresConfig.readerMonitor.visible = true;
                this.principal.hasAnyAuthority(['ROLE_ADMIN', 'ROLE_RFID_READER_MONITOR']).then(response => {
                    this.featuresConfig.readerMonitor.locked = !response;
                    if (this.featuresConfig.readerMonitor.locked === false && this.isLoadedFirstComponent === false) {
                        this.readerMonitorNavigation();
                        this.isLoadedFirstComponent = true;
                    }
                });
            }
            if (vsEleLink.featureLink === RT_ANALYSIS) {
                this.featuresConfig.rtAnalysis.visible = true;
                this.principal.hasAnyAuthority(['ROLE_ADMIN', 'ROLE_RT_ANALYSIS']).then(response => {
                    this.featuresConfig.rtAnalysis.locked = !response;
                    if (this.featuresConfig.rtAnalysis.locked === false && this.isLoadedFirstComponent === false) {
                        this.rtAnalysisNavigation();
                        this.isLoadedFirstComponent = true;
                    }
                });
            }
        }

        setTimeout(() => {
            if (!this.isLoadedFirstComponent) {
                this.loadComponent(NO_PERMISSION);
            }
        }, 300);
    }

    closeDialog(): void {
        this.dialogRef.close();
    }

    loadValueStreamTag(id) {
        // eager load
        this.vsDashboardTagService
            .findOne(id, NON_ELEMENTS, NON_LINKS, NON_FEATURES, EAGER_LOAD)
            .subscribe((res: HttpResponse<IVsDashboardTag>) => {
                this.valueStreamTag = res.body;
                this.tagFeatures = this.valueStreamTag.tagFeatures;
                const valueStreamElement: VsDashboardElement = res.body.valueStreamElements[0];
                this.visibleFeatures = valueStreamElement.valueStreamElementLinks;
                this.elementTypeName = valueStreamElement.vsElementName;

                // Sort feature alphabetically to load first component properly
                this.visibleFeatures.sort((a, b) => {
                    return a.featureLink < b.featureLink ? -1 : a.featureLink > b.featureLink ? 1 : 0;
                });
                this.loadFeatureConfig(this.visibleFeatures);
            });
    }

    heijunkaNavigation() {
        if (this.featuresConfig.heijunka.locked === false) {
            this.loadComponent(HEIJUNKA_FEATURE);
            this.displayFeatureName = 'Heijunka';
        }
    }

    operatorViewNavigation() {
        if (this.featuresConfig.operatorView.locked === false) {
            this.displayFeatureName = 'Operator View';
            this.loadComponent(OPERATOR_VIEW_FEATURE);
        }
    }

    leadTimeNavigation() {
        if (this.featuresConfig.leadTimeAnalysis.locked === false) {
            this.displayFeatureName = 'Lead Time';
            this.loadComponent(LEAD_TIME_FEATURE);
        }
    }
    kpiViewNavigation() {
        if (this.featuresConfig.kpiView.locked === false) {
            this.displayFeatureName = 'KPI View';
            this.loadComponent(KPI_VIEW_FEATURE);
        }
    }

    translatorNavigation() {
        if (this.featuresConfig.translator.locked === false) {
            this.displayFeatureName = 'Part Number Translator';
            this.loadComponent(SNR);
        }
    }

    readerMonitorNavigate() {
        if (this.featuresConfig.readerMonitor.locked === false) {
            this.displayFeatureName = 'Reader Monitor';
            this.loadComponent(READER_FEATURE);
        }
    }

    readerMonitorNavigation() {
        if (this.featuresConfig.readerMonitor.locked === false) {
            this.tagFeatureService
                .findByTagIdAndFeatureLink(this.valueStreamTag.id, READER_FEATURE)
                .subscribe((result: HttpResponse<IVsTagFeature>) => {
                    const tagFeature = result.body;
                    if (tagFeature != null && tagFeature.featureId != null) {
                        this.readerMonitorNavigate();
                    } else {
                        const readerFeature: IVsTagFeature = new VsTagFeature();
                        readerFeature.featureLink = READER_FEATURE;
                        readerFeature.valueStreamTagId = this.valueStreamTag.id;
                        if (!this.isSaving) {
                            this.isSaving = true;
                            this.tagFeatureService.createNewTagFeature(readerFeature).subscribe((res: HttpResponse<IVsTagFeature>) => {
                                this.readerMonitorNavigate();
                                this.isSaving = true;
                            });
                        }
                    }
                });
        }
    }

    rtAnalysisNavigation() {
        if (this.featuresConfig.rtAnalysis.locked === false) {
            this.loadComponent(RT_ANALYSIS);
            this.displayFeatureName = 'RT - Analysis';
        }
    }

    chooseAgain(allItem, chosenFeature) {
        this.isDisplayLink = false;
        this._sharedService.emitChange(true);
    }
}
