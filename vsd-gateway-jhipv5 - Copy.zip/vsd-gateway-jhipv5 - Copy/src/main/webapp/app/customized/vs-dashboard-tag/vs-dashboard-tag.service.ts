import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

import { SERVER_API_URL } from 'app/app.constants';
import { createRequestOption } from 'app/shared';
import { IVsDashboardTag } from './vs-dashboard-tag.model';

type EntityResponseType = HttpResponse<IVsDashboardTag>;
type EntityArrayResponseType = HttpResponse<IVsDashboardTag[]>;

@Injectable()
export class VsDashboardTagService {
    public resourceUrl = SERVER_API_URL + 'vsd/api/value-stream-tags';
    public resourceSearchUrl = SERVER_API_URL + 'vsd/api/_search/value-stream-tags';

    constructor(private http: HttpClient) {}

    create(valueStreamTag: IVsDashboardTag): Observable<EntityResponseType> {
        return this.http.post<IVsDashboardTag>(this.resourceUrl, valueStreamTag, { observe: 'response' });
    }

    update(valueStreamTag: IVsDashboardTag): Observable<EntityResponseType> {
        return this.http.put<IVsDashboardTag>(this.resourceUrl, valueStreamTag, { observe: 'response' });
    }

    findOne(
        id: number,
        loadElements?: boolean,
        loadLinks?: boolean,
        loadFeatures?: boolean,
        eagerLoad?: boolean
    ): Observable<EntityResponseType> {
        const options = createRequestOption({
            loadElements,
            loadLinks,
            loadFeatures,
            eagerLoad
        });
        return this.http.get<IVsDashboardTag>(`${this.resourceUrl}/${id}`, { params: options, observe: 'response' });
    }

    query(req?: any): Observable<EntityArrayResponseType> {
        const options = createRequestOption(req);
        return this.http.get<IVsDashboardTag[]>(this.resourceUrl, { params: options, observe: 'response' });
    }

    delete(id: number): Observable<HttpResponse<any>> {
        return this.http.delete<any>(`${this.resourceUrl}/${id}`, { observe: 'response' });
    }

    search(req?: any): Observable<EntityArrayResponseType> {
        const options = createRequestOption(req);
        return this.http.get<IVsDashboardTag[]>(this.resourceSearchUrl, { params: options, observe: 'response' });
    }

    getNames(id: number): Observable<HttpResponse<string[]>> {
        const url = this.resourceUrl + '/names/' + id;
        return this.http.get<string[]>(url, { observe: 'response' });
    }

    createFeaturedTag(valueStreamTag: IVsDashboardTag): Observable<EntityResponseType> {
        const url = this.resourceUrl + '/new-featured-tag';
        return this.http.post<IVsDashboardTag>(url, valueStreamTag, { observe: 'response' });
    }

    setStatus(valueStreamName: string, valueStreamTagName: string, status: String): Observable<EntityResponseType> {
        const options = createRequestOption({
            valueStreamName: [valueStreamName],
            valueStreamTagName: [valueStreamTagName],
            status: [status]
        });
        const url = this.resourceUrl + '/update-status';
        return this.http.get<IVsDashboardTag>(url, { params: options, observe: 'response' });
    }
}
