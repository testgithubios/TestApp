import { Routes } from '@angular/router';
import { VsDashboardTagDeletePopupComponent } from './vs-dashboard-tag-delete-dialog.component';
import { UserRouteAccessService } from 'app/core';

export const vsDashboardTagPopupRoute: Routes = [
    {
        path: 'vs-dashboard-tag/:id/delete',
        component: VsDashboardTagDeletePopupComponent,
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdValueStreamTag.home.title'
        },
        canActivate: [UserRouteAccessService],
        outlet: 'popup'
    }
];
