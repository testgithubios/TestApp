import { VsDashboardService } from './../../vs-dashboard/vs-dashboard.service';
import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { VsDashboard } from '../../vs-dashboard';
import { JhiAlertService } from 'ng-jhipster';
import { VsDashboardTagService } from '../vs-dashboard-tag.service';
import { VsDashboardTag } from '../vs-dashboard-tag.model';
import { DomSanitizer } from '@angular/platform-browser';
import { VsTagFeature } from '../../vs-tag-feature/vs-tag-feature.model';
import { EMAIL_SNR, EMAIL_SUBJECT_NO_PERMISSION } from 'app/shared/constants/email.constants';

@Component({
    selector: 'jhi-no-permission-feature',
    templateUrl: './no-permission-feature.component.html',
    styleUrls: ['./no-permission-feature.component.scss']
})
export class NoPermissionFeatureComponent implements OnInit {
    email: string;
    subject: string;
    constructor(private activatedRoute: ActivatedRoute, private jhiAlertService: JhiAlertService, public sanitizer: DomSanitizer) {}

    ngOnInit() {
        this.email = EMAIL_SNR;
        this.subject = EMAIL_SUBJECT_NO_PERMISSION;
    }
}
