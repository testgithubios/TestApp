import { MatDialogRef, MAT_DIALOG_DATA, ErrorStateMatcher } from '@angular/material';
import { Component, OnInit, Inject, ViewEncapsulation } from '@angular/core';
import { JhiEventManager, JhiAlertService } from 'ng-jhipster';
import { VsDashboard, IVsDashboard } from '../vs-dashboard/vs-dashboard.model';
import { VsDashboardService } from '../vs-dashboard/vs-dashboard.service';
import { VsDashboardElementService } from '../vs-dashboard-element/vs-dashboard-element.service';
import { VsDashboardTag, IVsDashboardTag } from './vs-dashboard-tag.model';
import * as d3 from 'd3';
import { FormControl, Validators, ValidatorFn, AbstractControl, ValidationErrors } from '@angular/forms';
import { VsDashboardTagService } from './vs-dashboard-tag.service';
import { VsDashboardTagEditFlagService } from './vs-dashboard-tag-edit-flag-service';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { VsDashboardElement } from 'app/customized/vs-dashboard-element/vs-dashboard-element.model';

export class MyErrorStateMatcher implements ErrorStateMatcher {
    isErrorState(control: FormControl | null): boolean {
        return !!(control && control.invalid && control.dirty);
    }
}

@Component({
    selector: 'jhi-vs-dashboard-tag-dialog',
    templateUrl: './vs-dashboard-tag-dialog.component.html',
    styleUrls: ['./vs-dashboard-tag-dialog.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class VsDashboardTagDialogComponent implements OnInit {
    valueStream: VsDashboard;
    selectedEle: FormControl;
    tagName: FormControl;
    allElementNames;
    private allTagNames: any;
    matcher;
    isSaving: boolean;
    constructor(
        private jhiAlertService: JhiAlertService,
        private eventManager: JhiEventManager,
        private valueStreamService: VsDashboardService,
        private valueStreamTagService: VsDashboardTagService,
        private valueStreamElementService: VsDashboardElementService,
        private vsDashboardTagEditFlagService: VsDashboardTagEditFlagService,
        public dialogRef: MatDialogRef<VsDashboardTagDialogComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any
    ) {
        this.isSaving = false;
        dialogRef.disableClose = true;
        this.selectedEle = new FormControl('', [Validators.required]);
        this.tagName = new FormControl('', [Validators.required, this.checkDuplicatedName()]);
        this.matcher = new MyErrorStateMatcher();
    }

    ngOnInit() {
        this.valueStreamService.find(this.data.valueStreamId).subscribe((res: HttpResponse<IVsDashboard>) => {
            this.valueStream = res.body;
        });
        this.valueStreamTagService.getNames(this.data.valueStreamId).subscribe((res: HttpResponse<string[]>) => {
            if (res.status === 200) {
                this.allTagNames = res.body;
            }
        });
        this.valueStreamElementService.getNames().subscribe((res: HttpResponse<string[]>) => {
            if (res.status === 200) {
                this.allElementNames = res.body;
            }
        });
    }

    checkDuplicatedName(): ValidatorFn {
        return (c: AbstractControl): ValidationErrors | null => {
            return this.allTagNames && this.allTagNames.indexOf(c.value.trim().toLowerCase()) > -1 ? { tagNameExists: true } : null;
        };
    }

    closeDialog(): void {
        this.dialogRef.close();
    }

    private subscribeToSaveResponse(result: Observable<HttpResponse<IVsDashboardTag>>) {
        result.subscribe(
            (res: HttpResponse<IVsDashboardTag>) => {
                this.onSaveSuccess(res);
            },
            (res: HttpErrorResponse) => {
                this.onError(res.message);
            }
        );
    }

    private onSaveSuccess(result: any) {
        this.isSaving = false;
        this.eventManager.broadcast({ name: 'vsDashboardDetailModification', content: 'OK' });
        this.closeDialog();
        this.vsDashboardTagEditFlagService.changeEditFlag(false);
    }

    private onError(errorMessage: any) {
        this.isSaving = false;
        console.log(errorMessage);
        // Hide the alerts
        // this.jhiAlertService.error(errorMessage, null, null);
    }

    cancel() {
        this.closeDialog();
        d3.select('#tag-holder-group > #group_temp').remove();
    }

    createFeaturedTag(valueStreamTag: VsDashboardTag) {
        this.subscribeToSaveResponse(this.valueStreamTagService.createFeaturedTag(valueStreamTag));
    }

    save(): void {
        this.isSaving = true;
        const element = new VsDashboardElement();
        element.vsElementName = this.selectedEle.value;

        const createdTag: VsDashboardTag = this.data.valueStreamTag;
        createdTag.tagName = this.tagName.value;

        createdTag.valueStreamId = this.valueStream.id;

        createdTag.valueStreamElements = new Array();
        createdTag.valueStreamElements.push(element);

        this.createFeaturedTag(createdTag);
    }
}
