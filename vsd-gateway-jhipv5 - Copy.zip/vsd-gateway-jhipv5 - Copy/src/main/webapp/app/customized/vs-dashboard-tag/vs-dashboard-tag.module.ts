import { NoPermissionFeatureComponent } from './no-permission/no-permission-feature.component';
import { VsRtAnalysisDetailComponent } from './../vs-rt-analysis/vs-rt-analysis-detail.component';
import { KpiViewComponent } from './../kpi-view/kpi-view.component';
import { LeadTimeAnalysisComponent } from './../lead-time-analysis/lead-time-analysis.component';
import { CommonModule } from '@angular/common';
import { NgSelectModule } from '@ng-select/ng-select';
import { ReaderMonitorMaterial } from './../reader-monitor/reader-monitor.material.module';
import { AdService } from './ad.service';
import { VsRtAnalysisComponent } from '../vs-rt-analysis/vs-rt-analysis.component';
import { ReaderMonitorComponent } from '../reader-monitor/reader-monitor.component';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';
import { MaterialModule } from './vs-dashboard-tag-material.module';
import {
    VsDashboardTagService,
    VsDashboardTagPopupService,
    VsDashboardTagDialogComponent,
    VsDashboardTagFeatureDialogComponent,
    VsDashboardTagDeletePopupComponent,
    VsDashboardTagDeleteDialogComponent
} from './';
import { SafeHtml } from './vs-dashboard.pipe';
import { vsDashboardTagPopupRoute } from './vs-dashboard-tag.route';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { VsDashboardTagEditFlagService } from './vs-dashboard-tag-edit-flag-service';
import { HeijunkaFeatureComponent } from './heijunka-board/heijunka-feature.component';
import { OperatorViewFeatureComponent } from './operator-view/operator-view-feature.component';
import { VsTagFeatureService } from '../vs-tag-feature/vs-tag-feature.service';
import { VsdGatewaySharedModule } from 'app/shared';
import { SharedService } from 'app/shared/shared-service';
import { VsdGatewaySharedDirectives } from 'app/shared/share-directives.module';

@NgModule({
    imports: [
        VsdGatewaySharedModule,
        RouterModule.forRoot(vsDashboardTagPopupRoute, { useHash: true }),
        MaterialModule,
        NgSelectModule,
        FormsModule,
        ReactiveFormsModule,
        ReaderMonitorMaterial,
        CommonModule,
        VsdGatewaySharedDirectives
    ],
    declarations: [
        VsDashboardTagDialogComponent,
        VsDashboardTagFeatureDialogComponent,
        VsDashboardTagDeleteDialogComponent,
        VsDashboardTagDeletePopupComponent,
        SafeHtml,
        HeijunkaFeatureComponent,
        OperatorViewFeatureComponent,
        NoPermissionFeatureComponent
    ],
    entryComponents: [
        VsDashboardTagDialogComponent,
        VsDashboardTagFeatureDialogComponent,
        VsDashboardTagDeleteDialogComponent,
        VsDashboardTagDeletePopupComponent,
        VsRtAnalysisComponent,
        ReaderMonitorComponent,
        HeijunkaFeatureComponent,
        OperatorViewFeatureComponent,
        LeadTimeAnalysisComponent,
        KpiViewComponent,
        VsRtAnalysisDetailComponent,
        NoPermissionFeatureComponent
    ],
    providers: [
        VsDashboardTagService,
        VsDashboardTagPopupService,
        VsDashboardTagEditFlagService,
        VsTagFeatureService,
        AdService,
        SharedService
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class VsdGatewayVsDashboardTagModule {}
