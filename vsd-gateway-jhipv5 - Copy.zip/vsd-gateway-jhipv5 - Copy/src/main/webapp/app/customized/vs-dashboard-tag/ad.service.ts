import { NoPermissionFeatureComponent } from './no-permission/no-permission-feature.component';
import { VsRtAnalysisDetailComponent } from './../vs-rt-analysis/vs-rt-analysis-detail.component';
import { LeadTimeAnalysisComponent } from './../lead-time-analysis/lead-time-analysis.component';
import { OperatorViewFeatureComponent } from './operator-view/operator-view-feature.component';
import { HeijunkaFeatureComponent } from './heijunka-board/heijunka-feature.component';
import { KpiViewComponent } from './../kpi-view/kpi-view.component';
import { TranslatorComponent } from './../translator/translator.component';
import { VsRtAnalysisComponent } from './../vs-rt-analysis/vs-rt-analysis.component';
import { ReaderMonitorComponent } from './../reader-monitor/reader-monitor.component';
import { Injectable } from '@angular/core';
import { AdItem } from './ad-item';
import {
    KPI_VIEW_FEATURE,
    LEAD_TIME_FEATURE,
    READER_FEATURE,
    HEIJUNKA_FEATURE,
    OPERATOR_VIEW_FEATURE,
    SNR,
    RT_ANALYSIS,
    NO_PERMISSION
} from 'app/shared/constants/featurelink.constants';
import { VsRtAnalysis, VsRtAnalysisDetail } from 'app/customized/vs-rt-analysis/vs-rt-analysis.model';

@Injectable()
export class AdService {
    getAds(moduleName: string, valueStreamTag: string) {
        switch (moduleName) {
            case KPI_VIEW_FEATURE:
                return new AdItem(KpiViewComponent, { tagId: valueStreamTag });
            case READER_FEATURE:
                return new AdItem(ReaderMonitorComponent, { tagId: valueStreamTag });
            case HEIJUNKA_FEATURE:
                return new AdItem(HeijunkaFeatureComponent, { tagId: valueStreamTag });
            case OPERATOR_VIEW_FEATURE:
                return new AdItem(OperatorViewFeatureComponent, { tagId: valueStreamTag });
            case SNR:
                return new AdItem(TranslatorComponent, { tagId: valueStreamTag });
            case RT_ANALYSIS:
                return new AdItem(VsRtAnalysisComponent, { tagId: valueStreamTag });
            case NO_PERMISSION:
                return new AdItem(NoPermissionFeatureComponent, { tagId: valueStreamTag });
            default:
                return new AdItem(null, null);
        }
    }

    getRtAnalysisDetail(rtAnalysisArr: VsRtAnalysisDetail[]) {
        return new AdItem(VsRtAnalysisDetailComponent, { rtAnalysisArr });
    }

    getLeadTimeFeature(valueStreamTag: string, plantName: string, valueStreamName: string) {
        return new AdItem(LeadTimeAnalysisComponent, { tagId: valueStreamTag, plantName, valueStreamName });
    }
}
