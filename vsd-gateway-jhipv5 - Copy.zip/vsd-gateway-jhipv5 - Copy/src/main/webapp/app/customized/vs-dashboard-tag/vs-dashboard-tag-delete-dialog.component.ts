import { Component, OnInit, OnDestroy, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

import { VsDashboardTagService } from './vs-dashboard-tag.service';
import { JhiEventManager } from 'ng-jhipster';
import { VsDashboardTag, IVsDashboardTag } from '.';
import { ActivatedRoute } from '@angular/router';
import { VsDashboardTagPopupService } from './vs-dashboard-tag-popup.service';
import { VsDashboardTagEditFlagService } from './vs-dashboard-tag-edit-flag-service';
import { HttpResponse } from '@angular/common/http';
import { LOAD_ELEMENTS } from 'app/shared/constants/common.constants';

@Component({
    selector: 'jhi-vs-dashboard-tag-delete-dialog',
    templateUrl: './vs-dashboard-tag-delete-dialog.component.html',
    styleUrls: ['vs-dashboard-tag-delete-dialog.component.scss']
})
export class VsDashboardTagDeleteDialogComponent implements OnInit {
    valueStreamTag: VsDashboardTag;

    constructor(
        public dialogRef: MatDialogRef<VsDashboardTagDeleteDialogComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any,
        private valueStreamTagService: VsDashboardTagService,
        private eventManager: JhiEventManager,
        private vsDashboardTagEditFlagService: VsDashboardTagEditFlagService
    ) {
        dialogRef.disableClose = true;
    }

    clear() {
        this.dialogRef.close();
    }

    ngOnInit(): void {
        // FetchedElements
        this.valueStreamTagService.findOne(this.data, LOAD_ELEMENTS).subscribe((res: HttpResponse<IVsDashboardTag>) => {
            this.valueStreamTag = res.body;
        });
    }

    confirmDelete() {
        this.valueStreamTagService.delete(this.valueStreamTag.id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'vsDashboardDetailModification',
                content: 'Deleted an valueStreamTag'
            });
            if (response.status === 200) {
                this.dialogRef.close();
                this.vsDashboardTagEditFlagService.changeEditFlag(false);
            }
        });
    }
}

@Component({
    selector: 'jhi-vs-dashboard-tag-delete-popup',
    template: ''
})
export class VsDashboardTagDeletePopupComponent implements OnInit, OnDestroy {
    routeSub: any;

    constructor(private route: ActivatedRoute, private valueStreamTagPopupService: VsDashboardTagPopupService) {}

    ngOnInit() {
        // this.routeSub = this.route.params.subscribe((params) => {
        //     this.valueStreamTagPopupService
        //         .open(VsDashboardTagDeleteDialogComponent as Component, params['id']);
        // });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
