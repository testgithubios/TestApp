import { IVsTagFeature } from '../vs-tag-feature/vs-tag-feature.model';
import { IVsDashboardElement } from '../vs-dashboard-element/vs-dashboard-element.model';
import { IVsDashboard } from 'app/customized/vs-dashboard';

export interface IVsDashboardTag {
    id?: number;
    x?: number;
    y?: number;
    width?: number;
    height?: number;
    tagName?: string;
    status?: string;
    statusDesc?: string;
    valueStreamId?: number;
    valueStreamValueStreamName?: string;
    valueStreamElements?: IVsDashboardElement[];
    tagFeatures?: IVsTagFeature[];
}

export enum Status {
    RED = 'RED',
    GREEN = 'GREEN',
    YELLOW = 'YELLOW'
}

export class VsDashboardTag implements IVsDashboardTag {
    constructor(
        public id?: number,
        public x?: number,
        public y?: number,
        public width?: number,
        public height?: number,
        public tagName?: string,
        public status?: string,
        public statusDesc?: string,
        public valueStreamId?: number,
        public valueStreamValueStreamName?: string,
        public valueStreamElements?: IVsDashboardElement[],
        public tagFeatures?: IVsTagFeature[]
    ) {}
}
