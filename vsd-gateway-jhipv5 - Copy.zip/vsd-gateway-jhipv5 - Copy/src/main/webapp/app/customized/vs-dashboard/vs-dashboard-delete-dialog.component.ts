import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { JhiEventManager, JhiAlertService } from 'ng-jhipster';

import { IVsDashboard, VsDashboard } from './vs-dashboard.model';
import { VsDashboardService } from './vs-dashboard.service';
import { HttpErrorResponse, HttpResponse } from '@angular/common/http';

@Component({
    selector: 'jhi-vs-dashboard-delete-dialog',
    templateUrl: './vs-dashboard-delete-dialog.component.html',
    styleUrls: ['vs-dashboard-delete-dialog.component.scss']
})
export class VsDashboardDeleteDialogComponent implements OnInit {
    valueStream: VsDashboard;

    constructor(
        public dialogRef: MatDialogRef<VsDashboardDeleteDialogComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any,
        private eventManager: JhiEventManager,
        private vsDashboardService: VsDashboardService,
        private jhiAlertService: JhiAlertService
    ) {
        dialogRef.disableClose = true;
    }

    clear() {
        this.dialogRef.close();
    }

    ngOnInit() {
        this.load(this.data);
    }

    load(valueStreamId) {
        this.vsDashboardService.find(valueStreamId).subscribe(
            (res: HttpResponse<IVsDashboard>) => {
                this.valueStream = res.body;
            },
            (res: HttpErrorResponse) => this.onError(res.message)
        );
    }

    private onError(errorMessage: string) {
        console.log(errorMessage);
        // Hide the alerts
        // this.jhiAlertService.error(errorMessage, null, null);
    }

    confirmDelete() {
        this.vsDashboardService.delete(this.valueStream.id).subscribe(
            (res: any) => {
                this.eventManager.broadcast({
                    name: 'vsDashboardListModification',
                    content: 'Deleted an valueStream'
                });

                this.dialogRef.close();
            },
            (res: HttpErrorResponse) => this.onError(res.message)
        );
    }
}
