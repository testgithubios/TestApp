import { Component, OnInit, OnDestroy } from '@angular/core';
import { JhiEventManager, JhiPaginationUtil, JhiAlertService, JhiParseLinks } from 'ng-jhipster';

import { ITEMS_PER_PAGE } from 'app/shared';
import { VsDashboardService } from './vs-dashboard.service';
import { IVsDashboard, VsDashboard } from './vs-dashboard.model';

import { ActivatedRoute, Router } from '@angular/router';
import { AppUserSetting, AppUserSettingService, IAppUserSetting } from '../app-user-setting';
import { MatDialog } from '@angular/material';
import { VsDashboardDialogComponent } from './vs-dashboard-dialog.component';
import { VsDashboardDeleteDialogComponent } from './vs-dashboard-delete-dialog.component';
import { Subscription } from 'rxjs'; // replace for import { Subscription } from 'rxjs/Rx';
import { HttpErrorResponse, HttpResponse } from '@angular/common/http';

import { Principal } from '../../core';
import { PaginationConfig } from '../../blocks/config/uib-pagination.config';

@Component({
    selector: 'jhi-vs-dashboard',
    templateUrl: './vs-dashboard.component.html',
    styleUrls: ['./vs-dashboard.component.scss']
})
export class VsDashboardComponent implements OnInit, OnDestroy {
    valueStreams: VsDashboard[];
    currentAccount: any;
    error: any;
    success: any;
    eventSubscriber: Subscription;
    currentSearch: string;
    routeData: any;
    links: any;
    totalItems: any;
    queryCount: any;
    itemsPerPage: any;
    page: any;
    private size;
    predicate: any;
    reverse: any;
    private userSetting: AppUserSetting;
    allowRedirect: string;
    last: number;
    healthyStatus: number;
    warningStatus: number;
    failureStatus: number;
    isGoToDetail = true;

    constructor(
        private vsDashboardService: VsDashboardService,
        private principal: Principal,
        private activatedRoute: ActivatedRoute,
        private router: Router,
        private jhiAlertService: JhiAlertService,
        private eventManager: JhiEventManager,
        private paginationUtil: JhiPaginationUtil,
        private paginationConfig: PaginationConfig,
        private userSettingService: AppUserSettingService,
        public dialog: MatDialog,
        private parseLinks: JhiParseLinks
    ) {
        this.itemsPerPage = ITEMS_PER_PAGE;
        this.page = 0;
        this.currentSearch = activatedRoute.snapshot.params['search'] ? activatedRoute.snapshot.params['search'] : '';
        this.predicate = 'id';
        this.reverse = true;
    }

    loadAll() {
        this.page = 0;
        if (this.currentSearch) {
            this.vsDashboardService
                .search({
                    plantId: this.userSetting.defaultPlant,
                    productFamily: this.userSetting.defaultProductFamily,
                    page: this.page,
                    query: this.currentSearch,
                    size: this.itemsPerPage,
                    sort: this.sort()
                })
                .subscribe(
                    (res: HttpResponse<IVsDashboard[]>) => this.onSuccess(res.body, res.headers),
                    (res: HttpErrorResponse) => this.onError(res.message)
                );
            return;
        }
        this.vsDashboardService
            .query({
                plantId: this.userSetting.defaultPlant,
                productFamily: this.userSetting.defaultProductFamily,
                page: this.page,
                size: this.itemsPerPage,
                sort: this.sort()
            })
            .subscribe(
                (res: HttpResponse<IVsDashboard[]>) => this.onSuccess(res.body, res.headers),
                (res: HttpErrorResponse) => this.onError(res.message)
            );

        this.isGoToDetail = true;
    }

    loadPage(page: number) {
        this.vsDashboardService
            .query({
                page: this.page,
                size: this.itemsPerPage,
                sort: this.sort()
            })
            .subscribe(
                (res: HttpResponse<IVsDashboard[]>) => {
                    for (let i = 0; i < res.body.length; i++) {
                        this.valueStreams.push(res.body[i]);
                    }
                    this.last = this.parseLinks.parse(res.headers.get('link')).last;
                    this.totalItems = res.headers.get('X-Total-Count');
                },
                (res: HttpErrorResponse) => {
                    console.log(res.message);
                    this.onError(res.error);
                }
            );
    }

    transition() {
        this.router.navigate(['/vs-dashboard'], {
            queryParams: {
                page: this.page,
                size: this.itemsPerPage,
                search: this.currentSearch,
                sort: this.predicate + ',' + (this.reverse ? 'asc' : 'desc')
            }
        });
        this.loadAll();
    }

    clear() {
        this.page = 0;
        this.currentSearch = '';
        this.router.navigate([
            '/vs-dashboard',
            {
                page: this.page,
                sort: this.predicate + ',' + (this.reverse ? 'asc' : 'desc')
            }
        ]);
        this.loadAll();
    }

    search(query) {
        if (!query) {
            return this.clear();
        }
        this.page = 0;
        this.currentSearch = query;
        this.router.navigate([
            '/vs-dashboard',
            {
                search: this.currentSearch,
                page: this.page,
                sort: this.predicate + ',' + (this.reverse ? 'asc' : 'desc')
            }
        ]);
        this.loadAll();
    }

    ngOnInit() {
        this.principal.identity().then(account => {
            this.currentAccount = account;
            this.loadAllSettings();
        });
        this.registerChangeInVsDashboard();

        // just data for display temporary
        this.healthyStatus = 5;
        this.warningStatus = 6;
        this.failureStatus = 2;
    }

    onScroll() {
        this.page = this.page + 1;
        this.loadPage(this.page);
    }

    ngOnDestroy() {
        this.eventManager.destroy(this.eventSubscriber);
    }

    trackId(index: number, item: VsDashboard) {
        return item.id;
    }

    registerChangeInVsDashboard() {
        this.eventSubscriber = this.eventManager.subscribe('vsDashboardListModification', response => this.loadAll());
    }

    sort() {
        const result = [this.predicate + ',' + (this.reverse ? 'asc' : 'desc')];
        if (this.predicate !== 'id') {
            result.push('id');
        }
        return result;
    }

    private onSuccess(data, headers) {
        this.totalItems = headers.get('X-Total-Count');
        this.queryCount = this.totalItems;
        // this.page = pagingParams.page;
        this.valueStreams = data;
    }

    goToDetail(valueStreamId: number) {
        if (this.isGoToDetail) {
            this.router.navigate(['vs-dashboard-detail', { id: valueStreamId }]);
        }
    }

    private onError(errorMessage: string) {
        console.log(errorMessage);
    }

    loadAllSettings() {
        this.userSettingService.findByUserName(this.currentAccount.login).subscribe(
            (res: HttpResponse<IAppUserSetting>) => {
                // if no setting, navigate to setting page
                if (res.body === null) {
                    this.router.navigate(['/user-app-setting']);
                } else {
                    this.userSetting = res.body;
                }
                this.loadAll();
            },
            (res: HttpErrorResponse) => this.onError(res.message)
        );
    }

    openDialog(valueStreamId: number) {
        this.isGoToDetail = false;
        const dialogRef = this.dialog.open(VsDashboardDialogComponent, {
            data: valueStreamId
        });
        dialogRef.afterClosed().subscribe(result => {
            this.isGoToDetail = true;
        });
    }

    openConfirmDeleteDialog(valueStreamId: number) {
        this.isGoToDetail = false;
        const dialogRef = this.dialog.open(VsDashboardDeleteDialogComponent, {
            data: valueStreamId,
            position: { top: '150px' }
        });
        dialogRef.afterClosed().subscribe(result => {
            this.isGoToDetail = true;
        });
    }
}
