import { IVsDashboardTag } from '../vs-dashboard-tag/vs-dashboard-tag.model';

export interface IVsDashboard {
    id?: number;
    valueStreamName?: string;
    valueStreamImage?: string;
    productFamily?: string;
    plantId?: number;
    plantPlantId?: string;
    valueStreamTags?: IVsDashboardTag[];
    image?: any;
    imageContentType?: string;
    healthyStatus?: string;
    warningStatus?: string;
    failureStatus?: string;
}

export class VsDashboard implements IVsDashboard {
    constructor(
        public id?: number,
        public valueStreamName?: string,
        public valueStreamImage?: string,
        public productFamily?: string,
        public plantPlantId?: string,
        public plantId?: number,
        public valueStreamTags?: IVsDashboardTag[],
        public image?: any,
        public imageContentType?: string,
        public healthyStatus?: string,
        public warningStatus?: string,
        public failureStatus?: string
    ) {}
}
