import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Component, OnInit, Inject, ElementRef, ChangeDetectorRef, ViewEncapsulation } from '@angular/core';

import { JhiEventManager, JhiAlertService, JhiDataUtils } from 'ng-jhipster';
import { IVsDashboard, VsDashboard } from './vs-dashboard.model';
import { VsDashboardService } from './vs-dashboard.service';

import { debounceTime, distinctUntilChanged, switchMap, map } from 'rxjs/operators';
import { HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { EMAIL } from 'app/shared/constants/email.constants';
import { Principal } from 'app/core';
import { Observable, of, Subject } from 'rxjs';
import { VsProductFamily, VsProductFamilyService } from 'app/customized/vs-product-family';
import { IPlant, Plant } from 'app/shared/model/vsd/plant.model';
import { IProductFamily } from 'app/shared/model/vsd/product-family.model';
import { PlantService } from 'app/entities/vsd/plant';
import { AppUserSettingService, IAppUserSetting } from 'app/customized/app-user-setting';
import { LOAD_IMG } from 'app/shared/constants/common.constants';

@Component({
    selector: 'jhi-vs-dashboard-dialog',
    templateUrl: './vs-dashboard-dialog.component.html',
    styleUrls: ['vs-dashboard-dialog.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class VsDashboardDialogComponent implements OnInit {
    valueStream: VsDashboard;
    isSaving: boolean;

    plants: Plant[];
    productFamilies: VsProductFamily[] = [];
    fileExtensionError: boolean;
    fileExtensionMessage: string;
    currentAccount: any;
    mail: string = EMAIL;
    imgFileName = '';
    defaultPlant: string;
    typingHandler$ = new Subject<string>();
    valueStreamId: any;
    // workaround as ng-select does not allow free text
    tempTerm: string;
    orginalName: string; // Display the currentName of valueStream before updating
    hideRequired = true;
    constructor(
        private dataUtils: JhiDataUtils,
        private jhiAlertService: JhiAlertService,
        private userSettingService: AppUserSettingService,
        private eventManager: JhiEventManager,
        private plantService: PlantService,
        private principal: Principal,
        private elementRef: ElementRef,
        private vsDashboardService: VsDashboardService,
        public dialogRef: MatDialogRef<VsDashboardDialogComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any,
        private productFamilyService: VsProductFamilyService,
        private cd: ChangeDetectorRef
    ) {
        dialogRef.disableClose = true;
    }

    ngOnInit() {
        this.typingHandler$
            .pipe(
                distinctUntilChanged(),
                debounceTime(500),
                switchMap((term: string) => {
                    this.tempTerm = term;
                    return term && term.trim()
                        ? this.productFamilyService.filterByProductName({ query: 'name:*' + term.trim() + '*' }).pipe(map(res => res.body))
                        : of([]);
                })
            )
            .subscribe(
                (res: IProductFamily[]) => {
                    this.cd.markForCheck();
                    this.productFamilies = res;
                    // add a temp item so user can choose
                    if (this.tempTerm && this.tempTerm.trim()) {
                        this.productFamilies.push({ id: 1, refId: 1, name: this.tempTerm });
                    }
                },
                err => {
                    this.productFamilies = [];
                }
            );

        this.isSaving = false;
        this.plantService.query().subscribe(
            (res: HttpResponse<IPlant[]>) => {
                this.plants = res.body;
            },
            (res: HttpErrorResponse) => this.onError(res.message)
        );

        this.principal.identity().then(account => {
            this.currentAccount = account;
            this.valueStreamId = this.data;
            if (this.valueStreamId === null) {
                // load default setting if create new
                this.valueStream = new VsDashboard();
                this.loadAllSettings();
            } else {
                this.vsDashboardService.find(this.data, LOAD_IMG).subscribe((res: HttpResponse<IVsDashboard>) => {
                    this.valueStream = res.body;
                    this.orginalName = this.valueStream.valueStreamName;
                    this.productFamilies = [{ id: 1, refId: 1, name: this.valueStream.productFamily }];
                });
            }
        });
    }

    loadAllSettings() {
        this.userSettingService.findByUserName(this.currentAccount.login).subscribe(
            (res: HttpResponse<IAppUserSetting>) => {
                const userSetting = res.body;
                this.defaultPlant = userSetting ? userSetting.defaultPlant : null;
                this.valueStream.productFamily = userSetting ? userSetting.defaultProductFamily : null;
                this.productFamilies = [{ id: 1, refId: 1, name: this.valueStream.productFamily }];
                if (this.defaultPlant) {
                    this.plantService.query({ plantId: [this.defaultPlant], page: 0, size: 1 }).subscribe(
                        (response: HttpResponse<IPlant[]>) => {
                            this.valueStream.plantId = response.body.length > 0 ? response.body[0].id : null;
                        },
                        (response: HttpErrorResponse) => this.onError(response.message)
                    );
                }
            },
            (res: HttpErrorResponse) => this.onError(res.message)
        );
    }

    private onSaveSuccess(result: VsDashboard) {
        this.eventManager.broadcast({ name: 'vsDashboardListModification', content: 'OK' });
        this.isSaving = false;
        this.dialogRef.close();
    }

    private onSaveError() {
        this.isSaving = false;
    }

    private onError(errorMessage: any) {
        console.log(errorMessage);
    }

    clearInputImage(field: string, fieldContentType: string, idInput: string) {
        this.dataUtils.clearInputImage(this.valueStream, this.elementRef, field, fieldContentType, idInput);
        this.imgFileName = '';
    }

    setFileData(event, entity, field, isImage) {
        const file = event.target.files[0];
        if (file != null) {
            const imageName = file.name;
            const allowedExtensions = ['jpg', 'jpeg', 'png', 'bmp', 'gif'];
            const fileExtension = imageName.split('.').pop();
            if (allowedExtensions.indexOf(fileExtension.toLowerCase()) > -1) {
                this.fileExtensionError = false;
                this.fileExtensionMessage = '';
                entity.valueStreamImage = event.currentTarget.value;
                this.dataUtils.setFileData(event, entity, field, isImage);
            } else {
                this.fileExtensionMessage = 'Only photos *.jpg, *.jpeg, *.png, *.bmp, *.gif allowed.';
                this.fileExtensionError = true;
            }
            this.imgFileName = file.name;
        }
    }

    byteSize(field) {
        return this.dataUtils.byteSize(field);
    }

    cancel() {
        this.dialogRef.close();
    }

    private subscribeToSaveResponse(result: Observable<HttpResponse<IVsDashboard>>) {
        result.subscribe(
            (res: HttpResponse<IVsDashboard>) => this.onSaveSuccess(res.body),
            (res: HttpErrorResponse) => {
                this.onSaveError();
            }
        );
    }

    save() {
        this.isSaving = true;
        if (this.valueStream.id !== undefined) {
            this.subscribeToSaveResponse(this.vsDashboardService.update(this.valueStream));
        } else {
            this.subscribeToSaveResponse(this.vsDashboardService.create(this.valueStream));
        }
    }
}
