import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { JhiEventManager, JhiDataUtils, JhiAlertService } from 'ng-jhipster';
import { MatDialog } from '@angular/material';
import { Router } from '@angular/router';

import { IVsDashboard, VsDashboard } from './vs-dashboard.model';
import { VsDashboardService } from './vs-dashboard.service';
import { VsDashboardTag, Status, IVsDashboardTag } from '../vs-dashboard-tag/vs-dashboard-tag.model';
import * as d3 from 'd3';
import { Subscription } from 'rxjs';
import { Principal } from 'app/core';
import { VsDashboardElement } from '../vs-dashboard-element/vs-dashboard-element.model';
import { VsDashboardElementService } from '../vs-dashboard-element/vs-dashboard-element.service';
import { VsDashboardTagService } from '../vs-dashboard-tag/vs-dashboard-tag.service';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { VsDashboardTagEditFlagService } from 'app/customized/vs-dashboard-tag/vs-dashboard-tag-edit-flag-service';
import {
    VsDashboardTagFeatureDialogComponent,
    VsDashboardTagNoFeatureDialogComponent,
    VsDashboardTagDeleteDialogComponent,
    VsDashboardTagDialogComponent
} from 'app/customized/vs-dashboard-tag';
import { LOAD_ELEMENTS, LOAD_LINKS, LOAD_IMG, LOAD_TAGS } from 'app/shared/constants/common.constants';

@Component({
    selector: 'jhi-vs-dashboard-detail',
    templateUrl: './vs-dashboard-detail.component.html',
    styleUrls: ['vs-dashboard-detail.component.scss']
})
export class VsDashboardDetailComponent implements OnInit, OnDestroy {
    private subscription: Subscription;
    private eventSubscriber: Subscription;
    private scaleStep = 0.05;
    private scaleMax = 5;
    private scaleMin = 1; // In case the image is bigger than the screen, scaleMin: number scale to fit screen, scaleMin < 1
    private scaleNrFitScreen; // number scale to fit screen
    scaleNumber = 1;
    valueStreamElements: VsDashboardElement[];
    valueStream: VsDashboard;

    msg: string;
    imgWidth: number;
    imgHeight: number;
    enableEditFlag = false;
    strokeDashStyle = '';
    tagColor = '#78BE20';

    private zoomInstance;
    private translate = { x: 0, y: 0 };

    private dimensionExpand = 30; // Width and Height of the image will be added <dimensionExpand> to expand the dragging & drawing area
    paddingExpand = this.dimensionExpand / 2; // The dragging & drawing area will be expanded vertically (half of height addition)
    // and horizontally (half of width addition)
    paddingExpand_X = -1 * this.paddingExpand;
    paddingExpand_Y = -1 * this.paddingExpand;
    imgWidthAddedPadding: number;
    imgHeightAddedPadding: number;
    imgloaded = false;
    valueStreamTag: VsDashboardTag;
    valueStreamElement: VsDashboardElement;
    vsElementName: string;

    private touchedDragAndResize = false; // This Flag turns true when users drag or resize the tags
    private touchedRects: any; // This records adjusted rectangles;

    hoverRect;
    enableToolTip; // Use for disable tooltip while dragging and zooming
    constructor(
        private eventManager: JhiEventManager,
        private jhiAlertService: JhiAlertService,
        private dataUtils: JhiDataUtils,
        private valueStreamService: VsDashboardService,
        private route: ActivatedRoute,
        public dialog: MatDialog,
        private valueStreamElementService: VsDashboardElementService,
        private vsDashboardTagService: VsDashboardTagService,
        private router: Router,
        private vsDashboardTagEditFlagService: VsDashboardTagEditFlagService
    ) {
        this.touchedRects = new Object();
    }

    mouseEnter(rect) {
        this.hoverRect = rect;
        d3.select('#tooltip')
            .attr('x', (rect.x + rect.width) * this.scaleNumber)
            .attr('y', rect.y * this.scaleNumber)
            .attr('width', 194)
            .attr('height', '100%')
            .style('opacity', 1);
    }

    mouseLeave() {
        d3.select('#tooltip')
            .attr('x', 0)
            .attr('y', 0)
            .attr('width', 0)
            .attr('height', 0)
            .style('opacity', 0);
        this.hoverRect = null; // Need to remove div id='msg' from html to prevent overlap rects
    }

    ngOnInit() {
        this.subscription = this.route.params.subscribe(params => {
            this.load(params['id']);
        });
        this.registerChangeInValueStreams();
        this.resgiterChangeWhenFinishTagging();
    }

    resgiterChangeWhenFinishTagging() {
        this.vsDashboardTagEditFlagService.editFlagStream.subscribe((res: any) => {
            this.disableEdit();
            d3.select('#tag-holder-group > #group_temp').remove();
        });
    }

    hasElementLink(elements: VsDashboardElement[]) {
        const ele = elements.filter(
            (element: VsDashboardElement) => element.valueStreamElementLinks !== null && element.valueStreamElementLinks.length > 0
        );
        return ele.length > 0 ? true : false;
    }
    openTag(rect) {
        if (!this.enableEditFlag) {
            // Load element and links
            this.vsDashboardTagService.findOne(rect.id, LOAD_ELEMENTS, LOAD_LINKS).subscribe((res: HttpResponse<IVsDashboardTag>) => {
                this.valueStreamTag = res.body;
                this.valueStreamElement = this.valueStreamTag.valueStreamElements[0];
                if (!this.valueStreamElement) {
                    this.jhiAlertService.error('error.element.not.found', null, null);
                    return;
                }
                const tag = { id: rect.id, tagName: rect.tagName };
                if (this.valueStreamTag.valueStreamElements && this.hasElementLink(this.valueStreamTag.valueStreamElements) === true) {
                    const valueStream = {
                        id: this.valueStream.id,
                        valueStreamName: this.valueStream.valueStreamName,
                        plantName: this.valueStream.plantPlantId
                    };
                    const dialogRef = this.dialog.open(VsDashboardTagFeatureDialogComponent, {
                        width: '98vw',
                        data: { selectedTag: tag, selectedValueStream: valueStream }
                    });
                } else {
                    const dialogRef = this.dialog.open(VsDashboardTagNoFeatureDialogComponent, {
                        height: '600px',
                        data: { selectedTag: tag }
                    });
                }
            });
        }
    }

    openDialog(input_dialog, valueStreamId, valueStreamTag) {
        return input_dialog.open(VsDashboardTagDialogComponent, {
            data: {
                valueStreamId,
                valueStreamTag
            }
        });
    }

    // Back to the size at the beginning
    // Incase the original size of image bigger than screen size the svg min size is smaller than its original size
    svgResize() {
        d3.select('#svg-container > svg')
            .style('width', this.scaleNrFitScreen * this.imgWidthAddedPadding + 'px')
            .style('height', this.scaleNrFitScreen * this.imgHeightAddedPadding + 'px');
    }

    // Modify svg width and height based of the scale number of zooming
    modifySvgDim() {
        d3.select('#svg-container > svg')
            .style('width', this.scaleNumber * this.imgWidthAddedPadding + 'px')
            .style('height', this.scaleNumber * this.imgHeightAddedPadding + 'px');
    }

    // when user click EDIT, reset image translate back to zero and scale to original size
    translateReset(groupContainer) {
        this.scaleNumber = 1;
        this.translate = { x: 0, y: 0 };
        const zoomIdentity = d3.zoomIdentity.translate(0, 0).scale(1);
        this.zoomInstance.transform(groupContainer, zoomIdentity);
        this.modifySvgDim();
    }

    // Reset button implementation
    // set image scaled to scaleMin and translate backs to 0
    backToBeginningState() {
        const groupContainer = d3.select('#svg-container > svg > g');
        this.scaleNumber = this.scaleNrFitScreen;
        this.translate = { x: 0, y: 0 };
        groupContainer.attr('transform', 'translate(0,0)scale(' + this.scaleNrFitScreen + ')');

        this.svgResize();
    }

    // Disable zoom and resize image to the original size
    zoomReset(groupContainer) {
        groupContainer.on('mousedown.drag', null);
        groupContainer.attr('transform', null);
        groupContainer.on('.zoom', null);

        this.translateReset(groupContainer);
    }

    zoom() {
        if (this.enableEditFlag === false) {
            const groupContainer = d3.select('#svg-container > svg > g');
            const self = this;
            groupContainer.call(
                d3.drag().on('drag', function() {
                    if (document.getElementById('body-container')) {
                        const bodyContainerHeight = document.getElementById('body-container').offsetHeight;
                        const bodyContainerWidth = document.getElementById('body-container').offsetWidth;

                        // Allow user to move the image when the image is bigger than the screen size
                        if (
                            self.scaleNumber * self.imgHeightAddedPadding > bodyContainerHeight &&
                            self.scaleNumber * self.imgWidthAddedPadding > bodyContainerWidth
                        ) {
                            const e = d3.event;
                            self.translate.x += e.dx;
                            self.translate.y += e.dy;
                            groupContainer.attr(
                                'transform',
                                'translate(' + self.translate.x + ',' + self.translate.y + ')scale(' + self.scaleNumber + ')'
                            );
                        }
                    }
                })
            );
            this.zoomInstance = d3
                .zoom()
                .on('zoom', () => {
                    self.enableToolTip = false;
                    if (d3.event.sourceEvent && d3.event.sourceEvent.type === 'wheel') {
                        if (d3.event.sourceEvent.deltaY < 0) {
                            // Mouse wheel up direction
                            this.scaleNumber = this.scaleNumber + this.scaleStep;
                            this.scaleNumber = this.scaleNumber < this.scaleMax ? this.scaleNumber : this.scaleMax;
                            groupContainer.attr(
                                'transform',
                                'translate(' + this.translate.x + ',' + this.translate.y + ')scale(' + this.scaleNumber + ')'
                            );
                        } else {
                            // Mouse wheel down direction
                            this.scaleNumber = this.scaleNumber - this.scaleStep;
                            this.scaleNumber = this.scaleNumber > this.scaleMin ? this.scaleNumber : this.scaleMin;
                            groupContainer.attr(
                                'transform',
                                'translate(' + this.translate.x + ',' + this.translate.y + ')scale(' + this.scaleNumber + ')'
                            );
                        }
                        d3.event.transform.k = this.scaleNumber;
                        this.modifySvgDim();
                    }
                })
                .on('end', () => {
                    self.enableToolTip = true;
                });
            groupContainer.call(this.zoomInstance).on('dblclick.zoom', null);
        }
    }

    zoomIn() {
        const groupContainer = d3.select('#svg-container > svg > g');
        this.scaleNumber = this.scaleNumber + this.scaleStep;
        this.scaleNumber = this.scaleNumber < this.scaleMax ? this.scaleNumber : this.scaleMax;
        if (this.translate) {
            groupContainer.attr(
                'transform',
                'translate(' + this.translate.x + ',' + this.translate.y + ') scale(' + this.scaleNumber + ')'
            );
        } else {
            groupContainer.attr('transform', 'translate(0,0) scale(' + this.scaleNumber + ')');
        }
        this.modifySvgDim();
    }

    zoomOut() {
        const groupContainer = d3.select('#svg-container > svg > g');
        this.scaleNumber = this.scaleNumber - this.scaleStep;
        this.scaleNumber = this.scaleNumber > this.scaleMin ? this.scaleNumber : this.scaleMin;
        if (this.translate) {
            groupContainer.attr(
                'transform',
                'translate(' + this.translate.x + ',' + this.translate.y + ') scale(' + this.scaleNumber + ')'
            );
        } else {
            groupContainer.attr('transform', 'translate(0,0) scale(' + this.scaleNumber + ')');
        }
        this.modifySvgDim();
    }

    disableEdit() {
        // remove the border around image when out of edit mode
        d3.select('#rect-for-padding').style('stroke', null);
        this.enableEditFlag = false;
        this.strokeDashStyle = '';

        // set time out for animation
        setTimeout(() => {
            this.msg = null;
        }, 200);

        d3.select('#svg-container > svg > g')
            .on('mousedown', null)
            .on('mouseup', null);
        // Enable zoom function when stop editing
        this.zoom();
        this.disableDrag();
        this.updateValueStream(this.valueStream);

        this.backToBeginningState();
    }

    disableDrag() {
        d3.selectAll('.tag-holder > rect').on('mousedown.drag', null);
        d3.selectAll('.tag-holder > circle').on('mousedown.drag', null);
    }

    enableDragAndResize() {
        // Prevent overlap mouseover event of svg in enableEdit method
        d3.selectAll('.tag-holder > foreignObject').call(d3.drag().on('drag', function() {}));

        const rectEle = d3.selectAll('.tag-holder > .rect-tag');
        const circleEle1 = d3.selectAll('.tag-holder > .c1');
        const circleEle2 = d3.selectAll('.tag-holder > .c2');
        const circleEle3 = d3.selectAll('.tag-holder > .c3');
        const circleEle4 = d3.selectAll('.tag-holder > .c4');

        rectEle.call(
            d3
                .drag()
                .on('start', startedDragRect)
                .on('drag', onDragRect)
                .on('end', endDragRect)
        );
        let rectId, rectData; // Use to get essential rectangle data from view for dragging
        let rectItem; // Use to record changing data and overwrite it in valuestreamtags list
        const imgWidth = this.imgWidth;
        const imgHeight = this.imgHeight;
        const self = this;

        function startedDragRect() {
            self.enableToolTip = false;
            rectId = +d3.select(this).attr('id');
            const rectDataX = +d3.select(this).attr('x');
            const rectDataY = +d3.select(this).attr('y');
            const rectDataWidth = +d3.select(this).attr('width');
            const rectDataHeight = +d3.select(this).attr('height');

            rectData = [{ x: rectDataX, y: rectDataY }, { x: rectDataX + rectDataWidth, y: rectDataY + rectDataHeight }];
            rectItem = self.valueStream.valueStreamTags.find(item => item.id === rectId);
        }
        function onDragRect() {
            const e = d3.event;
            if (rectData[1].x + e.dx < imgWidth + self.paddingExpand && rectData[0].x + e.dx > 0 - self.paddingExpand) {
                d3.select(this).attr('x', (rectData[0].x += e.dx));
                rectData[1].x += e.dx;
            }
            if (rectData[1].y + e.dy < imgHeight + self.paddingExpand && rectData[0].y + e.dy > 0 - self.paddingExpand) {
                d3.select(this).attr('y', (rectData[0].y += e.dy));
                rectData[1].y += e.dy;
            }
            updateRect();
        }

        function endDragRect() {
            self.enableToolTip = true;
            self.touchedDragAndResize = true;
            self.touchedRects[rectItem.id] = rectItem;
        }

        circleEle1.call(
            d3
                .drag()
                .on('start', startedDragCircle)
                .on('drag', onDragC1)
                .on('end', endDragRect)
        );
        circleEle2.call(
            d3
                .drag()
                .on('start', startedDragCircle)
                .on('drag', onDragC2)
                .on('end', endDragRect)
        );
        circleEle3.call(
            d3
                .drag()
                .on('start', startedDragCircle)
                .on('drag', onDragC3)
                .on('end', endDragRect)
        );
        circleEle4.call(
            d3
                .drag()
                .on('start', startedDragCircle)
                .on('drag', onDragC4)
                .on('end', endDragRect)
        );

        function startedDragCircle() {
            self.enableToolTip = false;
            rectId = +d3
                .select(this)
                .attr('id')
                .split('-')[0];
            const rect = d3.select("rect[id='" + rectId + "']");
            const rectDataX = +rect.attr('x');
            const rectDataY = +rect.attr('y');
            const rectDataWidth = +rect.attr('width');
            const rectDataHeight = +rect.attr('height');
            rectData = [{ x: rectDataX, y: rectDataY }, { x: rectDataX + rectDataWidth, y: rectDataY + rectDataHeight }];
            rectItem = self.valueStream.valueStreamTags.find(item => item.id === rectId);
        }

        function onDragC1() {
            setPosition(d3.select(this), d3.event.dx, d3.event.dy);
            updateRect();
        }

        function onDragC2() {
            setPosition(d3.select(this), d3.event.dx, d3.event.dy);
            updateRect();
        }

        function onDragC3() {
            setPosition(d3.select(this), d3.event.dx, d3.event.dy);
            updateRect();
        }

        function onDragC4() {
            setPosition(d3.select(this), d3.event.dx, d3.event.dy);
            updateRect();
        }

        // counter-clockwise order: c0, c1, c2, c3.
        function getPositionOrder(circleElement) {
            if (+circleElement.attr('cx') === rectData[0].x) {
                return +circleElement.attr('cy') === rectData[0].y ? 0 : 1;
            } else {
                return +circleElement.attr('cy') === rectData[1].y ? 2 : 3;
            }
        }

        function setPosition(element, eventX, eventY) {
            const order = getPositionOrder(element);
            if (order === 0) {
                if (
                    +element.attr('cx') + eventX > 0 - self.paddingExpand &&
                    +element.attr('cx') + +element.attr('width') + eventX < imgWidth + self.paddingExpand
                ) {
                    element.attr('cx', (rectData[0].x += eventX));
                }
                if (
                    +element.attr('cy') + eventY > 0 - self.paddingExpand &&
                    +element.attr('cy') + +element.attr('height') + eventY < imgHeight + self.paddingExpand
                ) {
                    element.attr('cy', (rectData[0].y += eventY));
                }
            }
            if (order === 1) {
                if (
                    +element.attr('cx') + eventX > 0 - self.paddingExpand &&
                    +element.attr('cx') + +element.attr('width') + eventX < imgWidth + self.paddingExpand
                ) {
                    element.attr('cx', (rectData[0].x += eventX));
                }
                if (+element.attr('cy') + eventY > 0 && +element.attr('cy') + eventY < imgHeight + self.paddingExpand) {
                    element.attr('cy', (rectData[1].y += eventY));
                }
            }
            if (order === 2) {
                if (+element.attr('cx') + eventX > 0 - self.paddingExpand && +element.attr('cx') + eventX < imgWidth + self.paddingExpand) {
                    element.attr('cx', (rectData[1].x += eventX));
                }
                if (
                    +element.attr('cy') + eventY > 0 - self.paddingExpand &&
                    +element.attr('cy') + eventY < imgHeight + self.paddingExpand
                ) {
                    element.attr('cy', (rectData[1].y += eventY));
                }
            }
            if (order === 3) {
                if (+element.attr('cx') + eventX > 0 - self.paddingExpand && +element.attr('cx') + eventX < imgWidth + self.paddingExpand) {
                    element.attr('cx', (rectData[1].x += eventX));
                }
                if (
                    +element.attr('cy') + eventY > 0 - self.paddingExpand &&
                    +element.attr('cy') + eventY + +element.attr('width') < imgHeight + self.paddingExpand
                ) {
                    element.attr('cy', (rectData[0].y += eventY));
                }
            }
        }

        function updateRect() {
            const rect = d3.select("rect[id='" + rectId + "']");
            rect.attr('x', rectData[1].x - rectData[0].x > 0 ? rectData[0].x : rectData[1].x)
                .attr('y', rectData[1].y - rectData[0].y > 0 ? rectData[0].y : rectData[1].y)
                .attr('width', Math.abs(rectData[1].x - rectData[0].x))
                .attr('height', Math.abs(rectData[1].y - rectData[0].y));

            rectItem.x = +rect.attr('x');
            rectItem.y = +rect.attr('y');
            rectItem.width = +rect.attr('width');
            rectItem.height = +rect.attr('height');
            d3.select("circle[id='" + rectId + '-c1' + "']")
                .attr('cx', rectData[0].x)
                .attr('cy', rectData[0].y);
            d3.select("circle[id='" + rectId + '-c2' + "']")
                .attr('cx', rectData[0].x)
                .attr('cy', rectData[1].y);
            d3.select("circle[id='" + rectId + '-c3' + "']")
                .attr('cx', rectData[1].x)
                .attr('cy', rectData[1].y);
            d3.select("circle[id='" + rectId + '-c4' + "']")
                .attr('cx', rectData[1].x)
                .attr('cy', rectData[0].y);

            d3.select("foreignObject[id='" + rectId + '-deleteBtn' + "']")
                .attr('x', +rect.attr('x') + +rect.attr('width') - 14)
                .attr('y', +rect.attr('y') - 14);
        }
    }

    enableEdit() {
        this.msg = 'You are in Edit mode. Please drag in the picture to add a New Tag';
        this.enableEditFlag = true;
        this.strokeDashStyle = '10,4';

        let rect, start;
        const self = this;
        const color = this.tagColor;

        const groupContainer = d3.select('#svg-container > svg > g');

        // Disable zoom and resize image to the original size
        this.zoomReset(groupContainer);

        groupContainer.on('mousedown', mousedown).on('mouseup', mouseup);
        let group;
        function mousedown() {
            start = d3.mouse(this);
            group = d3
                .select('#tag-holder-group')
                .append('g')
                .attr('class', 'tag-holder')
                .attr('id', 'group_temp');
            rect = group
                .append('rect')
                .attr('x', start[0])
                .attr('y', start[1])
                .attr('height', 0)
                .attr('width', 0)
                .attr('class', 'rect_temp')
                .style('stroke', color)
                .style('fill', 'rgb(0,0,0,0)')
                .style('stroke-width', '3px')
                .style('stroke-dasharray', '10,4');
            groupContainer.on('mousemove', mousemove);
        }

        function mousemove() {
            const end = d3.mouse(this);
            rect.attr('width', Math.abs(end[0] - start[0])).attr('height', Math.abs(end[1] - start[1]));

            if (end[0] < start[0]) {
                rect.attr('x', end[0]);
            }

            if (end[1] < start[1]) {
                rect.attr('y', end[1]);
            }
        }

        function mouseup() {
            groupContainer.on('mousemove', null);
            if (rect) {
                const valueStreamTag: VsDashboardTag = new VsDashboardTag();
                valueStreamTag.x = +rect.attr('x');
                valueStreamTag.y = +rect.attr('y');
                valueStreamTag.width = +rect.attr('width');
                valueStreamTag.height = +rect.attr('height');
                valueStreamTag.status = Status.GREEN;

                const group_temp = d3.select('#group_temp');
                if (!group_temp.empty() && valueStreamTag.width > 5 && valueStreamTag.height > 5) {
                    const dialogRef = self.openDialog(self.dialog, self.valueStream.id, valueStreamTag);
                } else {
                    d3.selectAll('#group_temp').remove();
                    self.enableDragAndResize();
                }
            }
        }
        this.enableDragAndResize();
    }

    private onError(errorMessage) {
        console.log(errorMessage);
        // Hide alerts
        // this.jhiAlertService.error(errorMessage, null, null);
    }

    deleteTag(rectId) {
        const dialogRef = this.dialog.open(VsDashboardTagDeleteDialogComponent, { data: rectId });
    }

    updateTag(tag) {
        this.vsDashboardTagService.update(tag).subscribe(
            (res: HttpResponse<IVsDashboardTag>) => {
                console.log('updated tag successfully');
            },
            (res: HttpErrorResponse) => {
                this.onError(res.message);
            }
        );
    }

    updateValueStream(valueStream) {
        if (this.touchedDragAndResize) {
            const updatedRects = Object.keys(this.touchedRects).map(key => this.touchedRects[key]);
            this.touchedRects = new Object(); // reset value to record new rects next time
            updatedRects.forEach(rect => {
                this.updateTag(rect);
            });
        }
        this.touchedDragAndResize = false;
    }

    loadedImage() {
        this.imgloaded = true;
    }

    reRenderTag() {
        // In case, a user uploads new picture that smaller than the old one, re-render the out-of-image boxes to the border of the new image.
        this.valueStream.valueStreamTags.forEach((tag: VsDashboardTag, index) => {
            const vsDashboardTag: VsDashboardTag = tag;
            let changedTagFlag = false;
            if (tag.x + tag.width > this.imgWidth) {
                vsDashboardTag.x = this.imgWidth - tag.width;
                changedTagFlag = true;
            }
            if (tag.y + tag.height > this.imgHeight) {
                vsDashboardTag.y = this.imgHeight - tag.height;
                changedTagFlag = true;
            }
            if (changedTagFlag) {
                this.vsDashboardTagService.update(vsDashboardTag).subscribe(
                    (res: HttpResponse<IVsDashboardTag>) => {
                        this.valueStream.valueStreamTags[index] = vsDashboardTag;
                    },
                    (res: HttpErrorResponse) => {
                        console.log('Could not save the re-render value stream tag');
                    }
                );
            }
        });
    }

    // Zooming in or out the image to match the height of screen
    displayImage() {
        if (!this.enableEditFlag) {
            const bodyContainerWidth = document.getElementById('body-container').offsetWidth;
            let i;
            if (this.imgWidth > bodyContainerWidth) {
                // In case the image is bigger than screen size the smaller size could be less than 1 to fit the screen
                for (i = 1; i * this.imgWidth > bodyContainerWidth - 200; i -= 0.00125) {}
                this.scaleMin = i;
            } else {
                for (i = 1; i * this.imgWidth < bodyContainerWidth - 200; i += 0.00125) {}
            }
            this.scaleNrFitScreen = i;
            d3.select('#svg-container > svg > g').attr('transform', 'translate(0,0) scale(' + i + ')');
            this.scaleNumber = i;
            this.modifySvgDim();
        }
    }

    load(id) {
        this.valueStreamService.find(id, LOAD_IMG, LOAD_TAGS).subscribe(
            (res: HttpResponse<IVsDashboard>) => {
                this.valueStream = res.body;
                const img = new Image();
                img.onload = () => {
                    this.imgWidth = img.width;
                    this.imgHeight = img.height;

                    // Add 'padding' to expand the dragging and drawing area based on the original image
                    this.imgWidthAddedPadding = this.imgWidth + this.dimensionExpand;
                    this.imgHeightAddedPadding = this.imgHeight + this.dimensionExpand;

                    // Zooming in or out the image to match the height of screen
                    this.displayImage();

                    // Load zoom function after the image is loaded
                    this.zoom();
                    this.reRenderTag();
                    this.enableToolTip = true;
                };
                img.src = 'data:' + this.valueStream.imageContentType + ';base64,' + this.valueStream.image;
            },
            (res: any) => {
                // TODO
                if (res.status === 404) {
                    this.onErrorLoadingPage('error.url.not.found');
                }
            }
        );
    }

    private onErrorLoadingPage(error) {
        this.valueStream = null;
        this.jhiAlertService.error(error, null, null);
    }

    byteSize(field) {
        return this.dataUtils.byteSize(field);
    }

    openFile(contentType, field) {
        return this.dataUtils.openFile(contentType, field);
    }

    previousState() {
        window.history.back();
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
        this.eventManager.destroy(this.eventSubscriber);
    }

    registerChangeInValueStreams() {
        this.eventSubscriber = this.eventManager.subscribe('vsDashboardDetailModification', response => this.load(this.valueStream.id));
    }
}
