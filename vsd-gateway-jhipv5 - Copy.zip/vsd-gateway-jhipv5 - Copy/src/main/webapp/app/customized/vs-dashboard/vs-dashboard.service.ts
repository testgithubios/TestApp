import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

import { SERVER_API_URL } from 'app/app.constants';
import { createRequestOption } from 'app/shared';

import { IVsDashboard } from './vs-dashboard.model';
import { map } from 'rxjs/operators';

type EntityResponseType = HttpResponse<IVsDashboard>;
type EntityArrayResponseType = HttpResponse<IVsDashboard[]>;

@Injectable()
export class VsDashboardService {
    public resourceUrl = SERVER_API_URL + 'vsd/api/value-streams';
    private resourceUrlIgnoreImage = SERVER_API_URL + 'vsd/api/value-streams-ignore-image';
    public resourceSearchUrl = SERVER_API_URL + 'vsd/api/_search/value-streams-ignore-image';

    private currentValueStreamName = '';
    constructor(private http: HttpClient) {}

    create(valueStream: IVsDashboard): Observable<EntityResponseType> {
        return this.http.post<IVsDashboard>(this.resourceUrl, valueStream, { observe: 'response' });
    }

    update(valueStream: IVsDashboard): Observable<EntityResponseType> {
        return this.http.put<IVsDashboard>(`${this.resourceUrl}/${this.currentValueStreamName}`, valueStream, { observe: 'response' });
    }

    find(id: number, loadImage?: boolean, loadTags?: boolean): Observable<EntityResponseType> {
        const options = createRequestOption({ loadImage, loadTags });
        return this.http.get<IVsDashboard>(`${this.resourceUrl}/${id}`, { params: options, observe: 'response' }).pipe(
            map(res => {
                this.currentValueStreamName = (res.body as IVsDashboard).valueStreamName;
                return res;
            })
        );
    }

    getAllVsName(): Observable<HttpResponse<string[]>> {
        const url = this.resourceUrl + '/all-names';
        return this.http.get<string[]>(url, { observe: 'response' });
    }

    query(req?: any, dashboardLoad?: boolean): Observable<EntityArrayResponseType> {
        const options = createRequestOption(req);
        return this.http.get<IVsDashboard[]>(this.resourceUrl + '-minimally', { params: options, observe: 'response' });
    }

    delete(id: number): Observable<HttpResponse<any>> {
        return this.http.delete<any>(`${this.resourceUrl}/${id}`, { observe: 'response' });
    }

    search(req?: any): Observable<EntityArrayResponseType> {
        const options = createRequestOption(req);
        return this.http.get<IVsDashboard[]>(this.resourceSearchUrl, { params: options, observe: 'response' });
    }
}
