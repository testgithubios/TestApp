import { Routes, Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

import { VsDashboardComponent } from './';
import { Injectable } from '@angular/core';
import { JhiPaginationUtil } from 'ng-jhipster';
import { VsDashboardDetailComponent } from './vs-dashboard-detail.component';
import { UserRouteAccessService } from '../../core';

@Injectable()
export class VSDashboardResolvePagingParams implements Resolve<any> {
    constructor(private paginationUtil: JhiPaginationUtil) {}

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        const page = route.queryParams['page'] ? route.queryParams['page'] : '1';
        const sort = route.queryParams['sort'] ? route.queryParams['sort'] : 'id,asc';
        return {
            page: this.paginationUtil.parsePage(page),
            predicate: this.paginationUtil.parsePredicate(sort),
            ascending: this.paginationUtil.parseAscending(sort)
        };
    }
}

export const VS_DASHBOARD_ROUTE: Routes = [
    {
        path: '',
        redirectTo: '/vs-dashboard',
        pathMatch: 'full'
    },
    {
        path: 'vs-dashboard',
        component: VsDashboardComponent,
        resolve: {
            pagingParams: VSDashboardResolvePagingParams
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdValueStream.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'vs-dashboard-detail',
        component: VsDashboardDetailComponent,
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'vsdGatewayApp.vsdValueStream.home.title'
        },
        canActivate: [UserRouteAccessService]
    }
];
