import { VsDashboardTagNoFeatureDialogComponent } from './../vs-dashboard-tag/vs-dashboard-tag-no-feature-dialog.component';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import {
    VS_DASHBOARD_ROUTE,
    VsDashboardComponent,
    VSDashboardResolvePagingParams,
    VsDashboardService,
    VsDashboardDetailComponent,
    VsDashboardDialogComponent
} from './';
import { ScrollTableDirective } from './scroll-table.directive';
import { MaterialModule } from './vs-dashboard-material.module';
import { NgSelectModule } from '@ng-select/ng-select';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { VsDashboardDeleteDialogComponent } from './vs-dashboard-delete-dialog.component';
import { VsdGatewaySharedModule } from '../../shared';

const ENTITY_STATES = [...VS_DASHBOARD_ROUTE];

@NgModule({
    imports: [
        VsdGatewaySharedModule,
        RouterModule.forRoot(ENTITY_STATES, { useHash: true }),
        MaterialModule,
        NgSelectModule,
        FormsModule,
        ReactiveFormsModule
    ],
    declarations: [
        VsDashboardComponent,
        ScrollTableDirective,
        VsDashboardDetailComponent,
        VsDashboardDialogComponent,
        VsDashboardDeleteDialogComponent,
        VsDashboardTagNoFeatureDialogComponent
    ],
    entryComponents: [VsDashboardDialogComponent, VsDashboardDeleteDialogComponent, VsDashboardTagNoFeatureDialogComponent],
    providers: [VsDashboardService, VSDashboardResolvePagingParams],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class VsdGatewayVsDashboardModule {}
