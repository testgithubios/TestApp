/**
 * JPA domain objects.
 */
package com.bosch.procon.domain;
