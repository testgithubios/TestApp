package com.bosch.procon.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "menu", ignoreUnknownFields = false)
public class MenuProperties {
    private boolean enable_procon;
    private boolean enable_vsd;

    public boolean isEnable_procon() {
        return enable_procon;
    }
    public void setEnable_procon(boolean enable_procon) {
        this.enable_procon = enable_procon;
    }
    public boolean isEnable_vsd() {
        return enable_vsd;
    }
    public void setEnable_vsd(boolean enable_vsd) {
        this.enable_vsd = enable_vsd;
    }
}
