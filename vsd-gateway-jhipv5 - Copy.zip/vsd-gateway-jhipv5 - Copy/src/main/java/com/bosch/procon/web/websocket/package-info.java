/**
 * WebSocket services, using Spring Websocket.
 */
package com.bosch.procon.web.websocket;
