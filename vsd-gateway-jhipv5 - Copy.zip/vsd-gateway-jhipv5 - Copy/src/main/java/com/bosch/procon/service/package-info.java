/**
 * Service layer beans.
 */
package com.bosch.procon.service;
