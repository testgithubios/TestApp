/**
 * Data Access Objects used by WebSocket services.
 */
package com.bosch.procon.web.websocket.dto;
