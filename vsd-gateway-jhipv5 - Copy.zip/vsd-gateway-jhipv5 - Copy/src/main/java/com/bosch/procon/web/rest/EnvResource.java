package com.bosch.procon.web.rest;

import com.bosch.procon.service.EnvService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.codahale.metrics.annotation.Timed;

@RestController
@RequestMapping("/api")
public class EnvResource {
    private final EnvService envService;

    public EnvResource(EnvService envService){
        this.envService = envService;
    }

    @GetMapping("/env-id")
    @Timed
    public ResponseEntity<String> getEnvId(){
        String envId = envService.getDeploymentEnvironmentId();
        return ResponseEntity.ok(envId);
    }
}
