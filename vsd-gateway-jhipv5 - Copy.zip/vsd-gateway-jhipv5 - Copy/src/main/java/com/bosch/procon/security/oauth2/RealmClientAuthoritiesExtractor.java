package com.bosch.procon.security.oauth2;

import org.springframework.boot.autoconfigure.security.oauth2.resource.AuthoritiesExtractor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class RealmClientAuthoritiesExtractor implements AuthoritiesExtractor {

    private final String realmRoles;

    private final String clientRoles;

    public RealmClientAuthoritiesExtractor(String realmRoles, String clientRoles) {
        this.realmRoles = realmRoles;
        this.clientRoles = clientRoles;
    }

    @Override
    public List<GrantedAuthority> extractAuthorities(Map<String, Object> map) {
        List<String> realmRolesList = (List<String>) map.get(realmRoles);
        if (realmRolesList == null) {
            return null;
        }
        List<GrantedAuthority> roles = realmRolesList
            .stream()
            .map(SimpleGrantedAuthority::new)
            .collect(Collectors.toList());

        // client roles
        List<String> clientRolesSet = (List<String>) map.get(clientRoles);
        if (clientRolesSet != null) {
            for (String s: clientRolesSet) {
                roles.add(new SimpleGrantedAuthority(s));
            }
        }

        return roles.stream().distinct().collect(Collectors.toList());
    }
}
