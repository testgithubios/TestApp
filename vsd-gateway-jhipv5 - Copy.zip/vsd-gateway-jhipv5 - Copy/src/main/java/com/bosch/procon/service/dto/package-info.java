/**
 * Data Transfer Objects.
 */
package com.bosch.procon.service.dto;
