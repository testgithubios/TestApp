package com.bosch.procon.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class EnvService {

    private final Logger log = LoggerFactory.getLogger(EnvService.class);

    @Value(value = "${DEPLOYMENT_ENVIRONMENT_ID:http://127.0.0.1:8080}")
    private String deploymentEnvironmentId;

    public EnvService(){
    }

    public String getDeploymentEnvironmentId() {
        return deploymentEnvironmentId;
    }
}
