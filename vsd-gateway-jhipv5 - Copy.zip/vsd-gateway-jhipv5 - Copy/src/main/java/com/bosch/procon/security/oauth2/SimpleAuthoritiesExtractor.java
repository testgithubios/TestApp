package com.bosch.procon.security.oauth2;

import com.bosch.procon.config.ApplicationProperties;
import org.springframework.boot.autoconfigure.security.oauth2.resource.AuthoritiesExtractor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static java.util.stream.Collectors.toList;

public class SimpleAuthoritiesExtractor implements AuthoritiesExtractor {

    private final String oauth2AuthoritiesAttribute;

    private final String oauth2RealmIdAttribute;

    private final ApplicationProperties applicationProperties;

    public SimpleAuthoritiesExtractor(String oauth2AuthoritiesAttribute,
                                      String oauth2RealmIdAttribute,
                                      ApplicationProperties applicationProperties) {
        this.oauth2AuthoritiesAttribute = oauth2AuthoritiesAttribute;
        this.oauth2RealmIdAttribute = oauth2RealmIdAttribute;
        this.applicationProperties = applicationProperties;
    }

    /**
     * By default, Plant = HOP1 and realm = PS
     * */

    @Override
    public List<GrantedAuthority> extractAuthorities(Map<String, Object> map) {
        // get roles base on current realm and plant
        String realmId = String.valueOf(map.getOrDefault(oauth2RealmIdAttribute, "PS"));
        String plantId = applicationProperties.getPlantId();
        return Optional.ofNullable((List<String>) map.get(oauth2AuthoritiesAttribute))
            .filter(it -> !it.isEmpty())
            .orElse(Collections.emptyList())
            .stream()
            .map(s -> extractRoleName(s, realmId, plantId))
            .distinct()
            .map(SimpleGrantedAuthority::new)
            .collect(toList());
    }

    /**
     * realmId_plantId_roleName or normal role format.
     * @return the same string if not in defined format, or role
     * */
    public static String extractRoleName(String realmRole, String realmId, String plantId) {
        if (realmRole.startsWith("ROLE_")) {
            return realmRole;
        }
        if (realmRole.startsWith(realmId + "_")) {
            realmRole = realmRole.substring(realmId.length() + 1);
            if (realmRole.startsWith(plantId + "_")) {
                realmRole = realmRole.substring(plantId.length() + 1);
                if (!realmRole.trim().isEmpty()) {
                    return "ROLE_" + realmRole.trim();
                }
            }
        }
        return realmRole;
    }
}
