/**
 * Spring Data Elasticsearch repositories.
 */
package com.bosch.procon.repository.search;
