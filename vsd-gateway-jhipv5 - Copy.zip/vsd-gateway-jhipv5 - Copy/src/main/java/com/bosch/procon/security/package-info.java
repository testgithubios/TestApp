/**
 * Spring Security configuration.
 */
package com.bosch.procon.security;
