package com.bosch.procon.config;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.lang.annotation.Annotation;

/**
 * Created by  Duyen.PhamThiCam@vn.bosch.com on 21/03/2019.
 */
@Component
@Endpoint(id = "menu-endpoint")
public class MenuEndPoint{

    @Autowired
    private Environment env;

    @ReadOperation
    public MenuProperties getMenuProperties(){
        MenuProperties menuProperties = new MenuProperties();
        menuProperties.setEnable_vsd(Boolean.valueOf(env.getProperty("menu.enable_vsd")));
        menuProperties.setEnable_procon(Boolean.valueOf(env.getProperty("menu.enable_procon")));
        return menuProperties;
    }
}
