/**
 * Spring Data JPA repositories.
 */
package com.bosch.procon.repository;
